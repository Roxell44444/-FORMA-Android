# FORMA 1.1.0 para Android (proyecto APK)

Este directorio contiene el contenedor Android nativo (WebView) que empaqueta la aplicación web FORMA 1.1.0 dentro de un APK instalable.

## Funciones Android
- Actividad nativa con icono/nombre de app (nombre FORMA).
- WebView con origen HTTPS local seguro (`appassets.androidplatform.net`).
- Permiso de cámara en tiempo de ejecución para el escáner.
- Selector de archivos para importar imágenes desde el dispositivo.
- Almacenamiento DOM/localStorage persistente en el WebView.
- Enlaces externos HTTPS se abren fuera de la aplicación.

## Compilar el APK
Se necesita Android SDK API 35, JDK 17 y Gradle 8.9. En un equipo con Android SDK:

```bash
cd android
gradle assembleDebug
```

El APK de depuración queda en `app/build/outputs/apk/debug/app-debug.apk`.

## Compilación en GitHub Actions
El workflow `.github/workflows/build-apk.yml` compila automáticamente un APK de depuración y lo publica como artefacto de la ejecución. Sube el proyecto a un repositorio GitHub y ejecuta Actions → Build FORMA Android APK → Run workflow. Descarga el artefacto `FORMA-1.1.0-debug-apk`.

## Importante
Este entorno de generación no dispone de Android SDK ni acceso de red a los repositorios de Google/Gradle, así que aquí no se puede compilar ni firmar el binario APK. El workflow sí está preparado para realizar la compilación en GitHub Actions. El APK de depuración sirve para instalar y probar; para Google Play se debe crear una firma de lanzamiento propia y proteger la clave.
