import { calculateBMI, calculateEnergyEstimate, estimateBodyFatHybrid, estimatePediatricBodyFatRFM, estimateAppendicularMuscle, estimatePhotoAssistedComposition, calculateMacroGuide, calculateCompositionEstimate, classifyBMI, calculateMacroTargets } from './core/metrics.js';
import { createPoseLandmarker, detectPoseInImage, drawPoseOverlay } from './scanner/pose.js';
import { estimateTwoViewAnthropometry } from './scanner/anthropometry.js';
import { compareScanToTape } from './scanner/validation.js';
import { validateFoodEntry, calculateFoodTotals, validateExerciseEntry, dailyFoodEntries, dailyExerciseEntries, validateActivityEntry, dailyActivityEntries } from './core/diary.js';
import { normalizeBackup } from './core/backup.js';
import { ageCapabilities } from './core/age.js';

const STORAGE_KEY = 'forma.prototype.v1';
const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
const today = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`; };
const VIEW_KEYS = ['front', 'side', 'back', 'side2'];
let capturedUrls = Object.fromEntries(VIEW_KEYS.map(key => [key, null]));
const poseResults = Object.fromEntries(VIEW_KEYS.map(key => [key, null]));
let scanBusy = false;
let state = loadState();

function loadState() {
  try {
    const parsed = JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}');
    return { profile: parsed.profile || null, scanResult: parsed.scanResult || null, scanValidations: Array.isArray(parsed.scanValidations) ? parsed.scanValidations : [], logs: Array.isArray(parsed.logs) ? parsed.logs : [], completedWorkouts: Array.isArray(parsed.completedWorkouts) ? parsed.completedWorkouts : [], foodEntries: Array.isArray(parsed.foodEntries) ? parsed.foodEntries : [], exerciseEntries: Array.isArray(parsed.exerciseEntries) ? parsed.exerciseEntries : [], activityEntries: Array.isArray(parsed.activityEntries) ? parsed.activityEntries : [] };
  } catch { return { profile: null, scanResult: null, scanValidations: [], logs: [], completedWorkouts: [], foodEntries: [], exerciseEntries: [], activityEntries: [] }; }
}
function saveState() { try { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); return true; } catch (error) { toast('No se pudieron guardar los datos. Exporta una copia y libera espacio del dispositivo.'); console.error('FORMA storage error', error); return false; } }
function fmt(value, digits = 0) { return Number(value).toLocaleString('es-ES', { maximumFractionDigits: digits, minimumFractionDigits: digits }); }
function dateFmt(date) { return new Date(`${date}T12:00:00`).toLocaleDateString('es-ES', { day: '2-digit', month: 'short', year: 'numeric' }); }
function escapeHTML(value = '') { return String(value).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }
function toast(message) { const el = $('#toast'); el.textContent = message; el.classList.add('show'); window.setTimeout(() => el.classList.remove('show'), 2600); }
function idForEntry() { return globalThis.crypto?.randomUUID?.() || `forma-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`; }

function go(view) {
  $$('.view').forEach(el => el.classList.toggle('active', el.id === `view-${view}`));
  $$('.nav-item, .mobile-nav-item').forEach(el => el.classList.toggle('active', el.dataset.view === view));
  const labels = { inicio: 'Resumen', evaluacion: 'Evaluación', escaner: 'Escáner corporal', plan: 'Mi plan', dieta: 'Mi dieta', progreso: 'Progreso', diario: 'Diario personal', coach: 'Entrenador' };
  $('#page-context').textContent = labels[view] || 'Resumen';
  window.location.hash = view;
  if (view === 'plan') renderPlan();
  if (view === 'dieta') renderDiet();
  if (view === 'progreso') renderHistory();
  if (view === 'diario') renderDiary();
  if (view === 'inicio') renderDashboard();
  window.scrollTo({ top: 0, behavior: 'smooth' });
}
$$('[data-view]').forEach(button => button.addEventListener('click', () => go(button.dataset.view)));
$$('[data-go]').forEach(button => button.addEventListener('click', () => go(button.dataset.go)));


function profileBodyFatDetails(profile) {
  if (!profile) return null;
  if (profile.age < 18) {
    if (profile.guardianConfirmed !== true) return null;
    const estimate = estimatePediatricBodyFatRFM({ age: profile.age, equation: profile.equation, heightCm: profile.height, waistCm: profile.waist, measureMethod: profile.measureMethod });
    return estimate ? { percent: estimate.percent, low: estimate.percent, high: estimate.percent, count: 1, methods: [{ name: estimate.method, value: estimate.percent }], spreadIsConfidenceInterval: false, confidenceLabel: estimate.note, pediatric: true, studyRmsePercentagePoints: estimate.studyRmsePercentagePoints } : null;
  }
  return estimateBodyFatHybrid({
    equation: profile.equation, age: profile.age, weightKg: profile.weight, heightCm: profile.height,
    waistCm: profile.waist, neckCm: profile.neck, hipCm: profile.hip, measureMethod: profile.measureMethod
  });
}

function profileBodyFat(profile) { return profileBodyFatDetails(profile)?.percent ?? null; }

function profileAppendicularMuscle(profile) {
  if (!profile) return null;
  return estimateAppendicularMuscle({
    equation: profile.equation, age: profile.age, weightKg: profile.weight, heightCm: profile.height,
    waistCm: profile.waist, calfLeftCm: profile.calfLeft, calfRightCm: profile.calfRight,
    measureMethod: profile.measureMethod
  });
}

function setFieldsDisabled(root, disabled) {
  if (!root) return;
  root.querySelectorAll('input, select, textarea').forEach(field => { field.disabled = disabled; });
}

function clearCapturedPhotosForMinor() {
  VIEW_KEYS.forEach(kind => {
    captureSequence[kind] = (captureSequence[kind] || 0) + 1;
    if (capturedUrls[kind]) URL.revokeObjectURL(capturedUrls[kind]);
    capturedUrls[kind] = null; poseResults[kind] = null;
    const slot = $(`#slot-${kind}`);
    if (slot) { $('img', slot).removeAttribute('src'); $('img', slot).classList.add('hidden'); $('.capture-outline', slot).classList.remove('hidden'); const canvas=$('canvas',slot); const ctx=canvas.getContext('2d'); if(ctx)ctx.clearRect(0,0,canvas.width,canvas.height); canvas.classList.remove('visible'); $('input',slot).value=''; }
  });
  state.scanResult = null;
  saveState();
  renderScanResult();
}

function applyAgeModeUi(age) {
  if (!Number.isFinite(age) || age < 0 || age > 130) return;
  const caps = ageCapabilities(age);
  const minor = caps.isMinor;
  const guardianRow = $('#guardian-consent-row');
  guardianRow.classList.toggle('hidden', !minor);
  guardianRow.querySelector('input').required = minor;
  $('#circumference-panel').classList.toggle('hidden', minor);
  const pediatricTapeEnabled = age >= 8 && age < 18;
  $('#pediatric-rfm-panel').classList.toggle('hidden', !pediatricTapeEnabled);
  setFieldsDisabled($('#pediatric-rfm-panel'), !pediatricTapeEnabled);
  $('#adult-goals-panel').classList.toggle('hidden', minor);
  $('#adult-safety-panel').classList.toggle('hidden', minor);
  setFieldsDisabled($('#circumference-panel'), minor);
  setFieldsDisabled($('#adult-goals-panel'), minor);
  setFieldsDisabled($('#adult-safety-panel'), minor);
  $('#equation-field').classList.toggle('hidden', minor && !pediatricTapeEnabled);
  $('#equation-field').firstChild.textContent = minor ? 'Sexo de referencia (RFM pediátrica)' : 'Sexo de referencia para ecuaciones';
  $('#equation-field select').disabled = minor && !pediatricTapeEnabled;
  $('#equation-field select').required = false;
  $('#height-label').firstChild.textContent = age < 2 ? 'Longitud recostado/a (cm)' : 'Estatura (cm)';
  $('#age-mode-note').textContent = minor
    ? (age < 2 ? 'Modo lactante: registra longitud y peso solo como datos de seguimiento con tutor. Esta versión no interpreta percentiles ni calcula composición corporal.' : age < 5 ? 'Modo infantil: registra datos bajo supervisión del tutor. No aplicamos IMC adulto, porcentajes de grasa/músculo ni objetivos dietéticos.' : age < 8 ? 'Modo crecimiento: entre 5 y 7 años no hay una ecuación de grasa incorporada. Se evita extrapolar fórmulas no validadas para esta edad.' : 'Modo crecimiento: para 8–14 y 15–17 existe una ecuación RFM pediátrica/adolescente publicada, pero solo se habilita con cintura medida con cinta y referencia sexual del estudio. Es una estimación exploratoria, no un diagnóstico.')
    : 'Las ecuaciones adultas disponibles cubren grasa corporal entre 18–80 años; gasto Mifflin entre 19–78; músculo apendicular usa una ecuación estudiada desde los 40 años.';
  $('#minor-scan-notice').classList.toggle('hidden', !minor);
  $('#scan-grid').classList.toggle('hidden', minor);
  setFieldsDisabled($('#scan-grid'), minor);
  $('#adult-scan-results').classList.toggle('hidden', minor);
  $('#minor-progress-notice').classList.toggle('hidden', !minor);
  $('#adult-progress-layout').classList.toggle('hidden', minor);
  $('#minor-diary-notice').classList.toggle('hidden', !minor);
  $('#minor-activity-panel').classList.toggle('hidden', !minor);
  ['adult-diary-layout','adult-diary-summary','adult-diary-history'].forEach(id => $(`#${id}`).classList.toggle('hidden', minor));
  $('#adult-progress-panel').classList.toggle('hidden', minor);
  $('#dashboard-scan-task').disabled = minor;
  $('#dashboard-scan-task').closest('.task-item').classList.toggle('hidden', minor);
  $('#dash-bmi-card').classList.toggle('hidden', minor);
  $('#dash-waist-card').classList.toggle('hidden', minor);
  if (minor && (state.scanResult || VIEW_KEYS.some(key => capturedUrls[key]))) clearCapturedPhotosForMinor();
}

function profileMetrics(profile) {
  const capabilities = ageCapabilities(profile.age);
  const bmi = capabilities.isMinor ? null : calculateBMI(profile.weight, profile.height);
  const energy = capabilities.mifflinEnergy && profile.safety === 'no' ? calculateEnergyEstimate({ weightKg: profile.weight, heightCm: profile.height, age: profile.age, equation: profile.equation, activity: profile.activity }) : null;
  const bodyFat = profileBodyFatDetails(profile);
  const appendicularMuscle = profileAppendicularMuscle(profile);
  return { bmi, energy, bodyFat, appendicularMuscle };
}

function renderDashboard() {
  const p = state.profile;
  $('#avatar-initial').textContent = p?.name?.[0]?.toUpperCase() || 'U';
  $('#welcome-title').textContent = p ? `Bienvenido/a${p.name ? `, ${p.name}` : ''}. Vamos paso a paso.` : 'Tu progreso empieza con datos reales.';
  $('#welcome-subtitle').textContent = p ? 'Tu punto de partida está guardado. Registra cambios en condiciones similares y observa tendencias.' : 'Completa tu evaluación para preparar un plan orientativo y hacer seguimiento.';
  $('#dash-weight').innerHTML = p ? `${fmt(p.weight, 1)} <small>kg</small>` : '— <small>kg</small>';
  $('#dash-waist').innerHTML = p?.waist ? `${fmt(p.waist, 1)} <small>cm</small>` : '— <small>cm</small>';
  applyAgeModeUi(p?.age);
  if (p) {
    const { bmi } = profileMetrics(p);
    const adult = p.age >= 18;
    $('#dash-bmi').textContent = adult ? (p.safety === 'no' && bmi !== null ? fmt(bmi, 1) : '—') : 'Modo crecimiento';
    $('#dash-weight-foot').textContent = adult ? 'Dato introducido por ti' : 'Dato registrado bajo supervisión';
    $('#dash-bmi-card').querySelector('.metric-foot').textContent = adult ? (p.safety === 'no' ? 'Indicador de cribado; no mide grasa' : 'No mostrado por contexto de seguridad') : 'No se aplican rangos de IMC adultos';
    $('#dash-waist').innerHTML = adult && p.waist ? `${fmt(p.waist, 1)} <small>cm</small>` : '— <small>cm</small>';
  } else {
    $('#dash-bmi').textContent = '—';
    $('#dash-weight-foot').textContent = 'Añade tu evaluación';
    $('#dash-waist').innerHTML = '— <small>cm</small>';
  }
  const firstDate = state.logs[0]?.date || p?.createdAt?.slice(0, 10);
  const days = firstDate ? Math.max(1, Math.floor((Date.now() - new Date(`${firstDate}T12:00:00`).getTime()) / 86400000) + 1) : 0;
  $('#dash-days').innerHTML = `${days} <small>días</small>`;
  const entries = [...state.logs].filter(x => x.weight).sort((a,b) => a.date.localeCompare(b.date));
  if (entries.length >= 2) {
    $('#empty-progress').classList.add('hidden');
    const first = entries[0], last = entries[entries.length - 1];
    const diff = last.weight - first.weight;
    $('#progress-summary').classList.remove('hidden');
    $('#progress-summary').innerHTML = `<div class="trend-number">${diff > 0 ? '+' : ''}${fmt(diff,1)} <small>kg</small></div><p class="muted">Cambio entre ${escapeHTML(dateFmt(first.date))} y ${escapeHTML(dateFmt(last.date))}. El peso aislado no describe por sí solo la composición corporal.</p><div class="mini-bars">${entries.slice(-10).map((x,i)=>`<span style="height:${Math.max(18,Math.min(100,55 + (x.weight-last.weight)*6))}%" title="${escapeHTML(x.date)}: ${fmt(x.weight,1)} kg"></span>`).join('')}</div>`;
  } else {
    $('#empty-progress').classList.remove('hidden');
    $('#progress-summary').classList.add('hidden');
  }
}

$('#profile-form').addEventListener('submit', event => {
  event.preventDefault();
  const form = new FormData(event.currentTarget);
  const age = Number(form.get('age'));
  const isMinor = Number.isFinite(age) && age < 18;
  const profile = {
    age, height: Number(form.get('height')), weight: Number(form.get('weight')),
    equation: form.get('equation') || 'range',
    waist: isMinor ? (age >= 8 && form.get('pediatricWaist') ? Number(form.get('pediatricWaist')) : null) : (form.get('waist') ? Number(form.get('waist')) : null),
    neck: !isMinor && form.get('neck') ? Number(form.get('neck')) : null, hip: !isMinor && form.get('hip') ? Number(form.get('hip')) : null,
    chest: !isMinor && form.get('chest') ? Number(form.get('chest')) : null,
    armLeft: !isMinor && form.get('armLeft') ? Number(form.get('armLeft')) : null, armRight: !isMinor && form.get('armRight') ? Number(form.get('armRight')) : null,
    forearmLeft: !isMinor && form.get('forearmLeft') ? Number(form.get('forearmLeft')) : null, forearmRight: !isMinor && form.get('forearmRight') ? Number(form.get('forearmRight')) : null,
    thighLeft: !isMinor && form.get('thighLeft') ? Number(form.get('thighLeft')) : null, thighRight: !isMinor && form.get('thighRight') ? Number(form.get('thighRight')) : null,
    calfLeft: !isMinor && form.get('calfLeft') ? Number(form.get('calfLeft')) : null, calfRight: !isMinor && form.get('calfRight') ? Number(form.get('calfRight')) : null,
    measureMethod: isMinor ? (age >= 8 && form.get('pediatricWaist') ? 'tape' : 'other') : (form.get('measureMethod') || 'other'),
    activity: isMinor ? 1.2 : Number(form.get('activity') || 1.2), goal: isMinor ? 'maintain' : (form.get('goal') || 'maintain'),
    experience: isMinor ? 'beginner' : (form.get('experience') || 'beginner'), sessions: isMinor ? 2 : Number(form.get('sessions') || 2),
    equipment: isMinor ? 'home' : (form.get('equipment') || 'home'), diet: isMinor ? '' : String(form.get('diet') || '').trim(),
    safety: isMinor ? 'unsure' : (form.get('safety') || 'unsure'), guardianConfirmed: isMinor ? form.get('guardianConfirmed') === 'on' : false,
    createdAt: state.profile?.createdAt || `${today()}T12:00:00`
  };
  if (!Number.isFinite(age) || age < 0 || age > 130 || profile.height < 40 || profile.height > 230 || profile.weight < 2 || profile.weight > 300) {
    $('#form-message').textContent = 'Revisa los datos: edad 0–130 años, longitud/estatura 40–230 cm y peso 2–300 kg.';
    return;
  }
  if (isMinor && !profile.guardianConfirmed) {
    $('#form-message').textContent = 'Para guardar un perfil menor de 18 años, un padre, madre o tutor debe confirmar la supervisión.';
    return;
  }
  if (!isMinor && profile.goal === 'fatloss' && age >= 18 && calculateBMI(profile.weight, profile.height) < 18.5) {
    $('#form-message').textContent = 'Con un IMC inferior a 18,5 no habilitamos un objetivo automático de pérdida de peso. Consulta con un profesional.';
    return;
  }
  if (isMinor) clearCapturedPhotosForMinor();
  state.profile = profile;
  saveState();
  $('#form-message').textContent = 'Evaluación guardada en este dispositivo.';
  renderDashboard();
  if (poseResults.front && poseResults.side) runBodyScan();
  toast('Evaluación guardada.');
  go('plan');
});

function populateForm() {
  const p = state.profile; if (!p) { applyAgeModeUi(30); return; }
  const form = $('#profile-form');
  Object.entries(p).forEach(([key,value]) => { const field = form.elements.namedItem(key); if (field && value !== null && value !== undefined && field.type !== 'checkbox') field.value = value; if(field && field.type === 'checkbox') field.checked = value === true; });
  applyAgeModeUi(p.age);
}
$('#profile-form').elements.age.addEventListener('input', event => applyAgeModeUi(Number(event.currentTarget.value)));


// Camera capture stays in memory. Pose analysis is optional, local inference only.
let captureSequence = Object.fromEntries(VIEW_KEYS.map(key => [key, 0]));
const poseConsent = $('#pose-consent');

function poseStatusClass(status) {
  return status === 'ready' ? 'ready' : status === 'review' ? 'review' : 'rejected';
}

function renderPoseFeedback(kind, analysis) {
  const node = $(`#pose-${kind}`);
  node.className = `pose-feedback ${poseStatusClass(analysis.status)}`;
  const notes = [...analysis.reasons, ...analysis.warnings];
  const message = notes.length ? notes.map(escapeHTML).join(' ') : 'Puntos principales visibles y sin alertas de encuadre.';
  node.innerHTML = `<strong>${escapeHTML(analysis.title)}</strong><small>Calidad de captura: ${analysis.score}/100 · No es precisión de composición corporal.</small><small>${message}</small>`;
}

function drawFeedback(kind, landmarks) {
  const slot = $(`#slot-${kind}`);
  const image = $('img', slot);
  const canvas = $('canvas', slot);
  if (landmarks) {
    const result = poseResults[kind];
    drawPoseOverlay(canvas, image, landmarks, result?.personMask || null);
    canvas.classList.add('visible');
  } else {
    const ctx = canvas.getContext('2d');
    if (ctx) ctx.clearRect(0, 0, canvas.width, canvas.height);
    canvas.classList.remove('visible');
  }
}

function updatePosePairSummary() {
  const node = $('#pose-pair-summary');
  const front = poseResults.front;
  const side = poseResults.side;
  if (!poseConsent.checked) {
    node.textContent = 'La revisión automática está desactivada. Las capturas permanecen solo en memoria y no se analizan.';
    return;
  }
  if (!front && !side) {
    node.textContent = 'Activa la revisión y captura la vista frontal y al menos un perfil. Las vistas posterior y del otro perfil son opcionales.';
    return;
  }
  if (!front || !side) {
    node.textContent = `Vista ${front ? 'frontal' : 'de perfil'} revisada. Falta la vista ${front ? 'de perfil' : 'frontal'} obligatoria. Las otras dos vistas son complementarias.`;
    return;
  }
  const required = [front, side];
  if (required.some(item => item.status === 'rejected')) {
    node.textContent = 'La vista frontal o el perfil principal necesita repetirse. Corrige las indicaciones antes de continuar.';
    return;
  }
  const optionalCount = ['back', 'side2'].filter(key => poseResults[key]?.status !== 'rejected' && poseResults[key]?.personMask && poseResults[key]?.orientation === (key === 'back' ? 'front-likely' : 'side-likely')).length;
  node.textContent = optionalCount
    ? `Base válida y ${optionalCount} vista(s) complementaria(s) revisada(s). Se usarán como contraste para reducir la dependencia de una sola captura. La estimación sigue siendo experimental.`
    : 'Base válida con frontal y perfil. Puedes añadir la vista posterior y el perfil contrario para comprobar consistencia; no son obligatorios.';
  runBodyScan();
}

async function runBodyScan() {
  if (state.profile && state.profile.age < 18) return;
  if (scanBusy || !poseResults.front || !poseResults.side || !capturedUrls.front || !capturedUrls.side) return;
  if (poseResults.front.status === 'rejected' || poseResults.side.status === 'rejected') return;
  if (!state.profile?.height) {
    $('#pose-pair-summary').textContent = 'Las dos vistas están detectadas. Completa primero tu altura en Evaluación para calibrar la escala aproximada.';
    return;
  }
  if (poseResults.front.orientation !== 'front-likely' || poseResults.side.orientation !== 'side-likely') {
    $('#pose-pair-summary').textContent = 'No voy a calcular anchuras porque no puedo confirmar una vista frontal y otra lateral. Repite las fotos con el cuerpo de frente y después girado de perfil.';
    $('#capture-status').textContent = 'Orientación de las vistas insuficiente para una estimación geométrica.';
    return;
  }
  if (!poseResults.front.personMask || !poseResults.side.personMask) {
    $('#pose-pair-summary').textContent = 'El detector encontró la postura, pero no generó una máscara corporal fiable en ambas vistas. Comprueba que la versión del modelo esté cargada y vuelve a capturar.';
    $('#capture-status').textContent = 'No hay máscara de segmentación por persona. Puedes continuar con medidas manuales.';
    return;
  }
  scanBusy = true;
  $('#capture-status').textContent = 'Analizando vistas frontal y lateral; las vistas adicionales se usan para contrastar anchuras y profundidades.';
  try {
    const result = estimateTwoViewAnthropometry({
      frontMask: poseResults.front.personMask,
      sideMask: poseResults.side.personMask,
      frontLandmarks: poseResults.front.landmarks,
      sideLandmarks: poseResults.side.landmarks,
      backMask: poseResults.back?.status !== 'rejected' && poseResults.back?.orientation === 'front-likely' ? poseResults.back?.personMask : null,
      backLandmarks: poseResults.back?.status !== 'rejected' && poseResults.back?.orientation === 'front-likely' ? poseResults.back?.landmarks : null,
      side2Mask: poseResults.side2?.status !== 'rejected' && poseResults.side2?.orientation === 'side-likely' ? poseResults.side2?.personMask : null,
      side2Landmarks: poseResults.side2?.status !== 'rejected' && poseResults.side2?.orientation === 'side-likely' ? poseResults.side2?.landmarks : null,
      heightCm: Number(state.profile.height)
    });
    const composition = estimatePhotoAssistedComposition({ profile: state.profile, measurements: result.measurements, captureQuality: result.captureQuality });
    const muscleSupplement = profileAppendicularMuscle(state.profile);
    state.scanResult = { ...result, composition, muscleSupplement, createdAt: new Date().toISOString() };
    saveState();
    renderScanResult();
    $('#capture-status').textContent = composition ? 'Estimación exploratoria de composición corporal generada en este dispositivo. Las fotos siguen solo en memoria.' : 'Se midió la silueta, pero no se pudo generar una estimación de composición con estos datos o esta calidad de captura.';
    $('#pose-pair-summary').textContent = composition ? 'Escaneo completado: se muestran estimación de grasa, masa grasa, masa libre de grasa e índices derivados. La adaptación de RFM a perímetros fotográficos es experimental; el escáner no cuantifica directamente músculo.' : 'Geometría de silueta calculada; revisa el perfil, la edad y la consistencia de escala para habilitar la estimación exploratoria de composición.';
  } catch (error) {
    state.scanResult = null;
    $('#capture-status').textContent = `No se pudo completar la estimación: ${error.message} Puedes continuar con medidas manuales.`;
    $('#pose-pair-summary').textContent = 'La postura se detectó, pero la segmentación no produjo medidas fiables. Ajusta la luz, el fondo y la distancia, o utiliza una cinta métrica.';
    renderScanResult();
  } finally { scanBusy = false; }
}

function renderScanResult() {
  const root = $('#scan-result');
  if (!root) return;
  const result = state.scanResult;
  if (!result) {
    root.innerHTML = '<p class="muted">Aún no hay un resultado. Necesitas una vista frontal, otra lateral, máscaras corporales válidas y tu altura, peso y edad en el perfil.</p>';
    return;
  }
  const m = result.measurements;
  const rows = [['Pecho', m.chest], ['Cintura', m.waist], ['Cadera', m.hip]];
  const c = result.composition;
  const percentText = c ? (c.bodyFatPercent === null ? `${fmt(c.bodyFatLow,1)}–${fmt(c.bodyFatHigh,1)}%` : `≈ ${fmt(c.bodyFatPercent,1)}%`) : 'No disponible';
  const fatMassText = c ? (c.fatMassKg === null ? `${fmt(c.fatMassLowKg,1)}–${fmt(c.fatMassHighKg,1)} kg` : `${fmt(c.fatMassKg,1)} kg`) : '—';
  const leanMassText = c ? (c.fatFreeMassKg === null ? `${fmt(c.fatFreeMassLowKg,1)}–${fmt(c.fatFreeMassHighKg,1)} kg` : `${fmt(c.fatFreeMassKg,1)} kg`) : '—';
  const fmiText = c ? (c.fatMassIndex === null ? `${fmt(c.fatMassIndexLow,1)}–${fmt(c.fatMassIndexHigh,1)}` : fmt(c.fatMassIndex,1)) : '—';
  const ffmiText = c ? (c.fatFreeMassIndex === null ? `${fmt(c.fatFreeMassIndexLow,1)}–${fmt(c.fatFreeMassIndexHigh,1)}` : fmt(c.fatFreeMassIndex,1)) : '—';
  const methodText = c ? c.methods.map(item => `${item.name} (${item.reference === 'male' ? 'ref. masculina' : 'ref. femenina'}): ${fmt(item.value,1)}%`).join(' · ') : '';
  const compositionMarkup = c ? `<section class="scan-composition"><div class="scan-composition-heading"><div><div class="eyebrow">RESULTADO DEL ESCÁNER</div><h3>Composición corporal aproximada</h3></div><span class="scan-estimate-badge">EXPERIMENTAL</span></div><div class="scan-composition-grid"><article class="scan-composition-card scan-composition-primary"><small>GRASA CORPORAL ESTIMADA</small><strong>${percentText}</strong><span>${c.bodyFatPercent === null ? 'Rango entre referencias sexuales; FORMA no elige una por ti.' : 'Estimación combinada a partir del perfil y la cintura extraída de las fotos.'}</span></article><article class="scan-composition-card"><small>MASA GRASA ESTIMADA</small><strong>${fatMassText}</strong><span>Derivada del porcentaje estimado y tu peso registrado.</span></article><article class="scan-composition-card"><small>MASA LIBRE DE GRASA</small><strong>${leanMassText}</strong><span>Incluye músculo, agua, huesos y órganos; no equivale a músculo.</span></article><article class="scan-composition-card"><small>IMC DE REFERENCIA</small><strong>${fmt(c.bmi,1)}</strong><span>Se calcula con peso y altura del perfil; no mide grasa por sí solo.</span></article><article class="scan-composition-card"><small>ÍNDICE DE MASA GRASA · FMI</small><strong>${fmiText}</strong><span>kg de grasa estimada por m² de altura.</span></article><article class="scan-composition-card"><small>ÍNDICE DE MASA MAGRA · FFMI</small><strong>${ffmiText}</strong><span>kg de masa libre de grasa por m²; no es un índice muscular puro.</span></article><article class="scan-composition-card"><small>DISPERSIÓN ENTRE MÉTODOS</small><strong>${fmt(c.bodyFatLow,1)}–${fmt(c.bodyFatHigh,1)}%</strong><span>Rango entre salidas de ecuaciones/referencias; no es un intervalo de confianza.</span></article><article class="scan-composition-card"><small>CINTURA / ALTURA (VISUAL)</small><strong>${fmt(c.waistHeightRatio,3)}</strong><span>Relación calculada con la cintura estimada en las fotos; no aplicar umbrales clínicos.</span></article>${c.waistHipRatio !== null ? `<article class="scan-composition-card"><small>CINTURA / CADERA (VISUAL)</small><strong>${fmt(c.waistHipRatio,3)}</strong><span>Índice descriptivo basado en dos perímetros fotográficos experimentales.</span></article>` : ''}</div><div class="scan-composition-method"><strong>Cómo se obtuvo</strong><p>${escapeHTML(methodText)}</p><small>El porcentaje combina CUN-BAE (IMC, edad y referencia sexual) con RFM aplicado al perímetro elíptico visual de cintura. RFM fue desarrollado para cintura medida, no para esta aproximación fotográfica; por eso el resultado es exploratorio. El rango entre ecuaciones/referencias no es un intervalo de confianza.</small></div>${result.muscleSupplement ? `<div class="scan-muscle-note"><strong>Músculo esquelético apendicular · complemento con cinta</strong><span>≈ ${fmt(result.muscleSupplement.kg,1)} kg · índice ${fmt(result.muscleSupplement.indexKgM2,2)} kg/m²</span><small>Este dato procede de la ecuación antropométrica y de las medidas manuales de cinta de tu perfil, no de la imagen. Solo se habilita en el rango de edad estudiado y no equivale a músculo total.</small></div>` : `<div class="scan-muscle-note"><strong>Músculo esquelético</strong><span>No cuantificable con respaldo suficiente solo a partir de estas fotos.</span><small>FORMA no convierte masa libre de grasa en músculo. Para mostrar la estimación apendicular disponible se necesitan medidas de cintura y pantorrilla con cinta y cumplir el rango de edad de la ecuación.</small></div>`}</section>` : `<div class="notice notice-warning"><span class="notice-icon">!</span><p><strong>No se pudo calcular el porcentaje de grasa a partir de este escaneo.</strong> Comprueba que tu perfil incluya peso, altura, edad y una referencia sexual compatible con las ecuaciones. Si la escala entre vistas fue inconsistente, repite las fotos a la misma distancia y zoom.</p></div>`;
  const scaleLabel = result.captureQuality?.scaleSpreadPct <= 10 ? 'Consistente' : result.captureQuality?.scaleSpreadPct <= 25 ? 'Variable' : 'Inconsistente';
  root.innerHTML = `${compositionMarkup}<div class="scan-measures-heading"><h3>Medidas visuales de la silueta</h3><small>Perímetros elípticos proxy, no cinta métrica</small></div><div class="scan-measure-grid">${rows.map(([label,item]) => `<div class="scan-measure"><small>${label.toUpperCase()} · PROXY VISUAL</small><strong>≈ ${fmt(item.circumferenceCm,1)} cm</strong><span>Anchura frontal ${fmt(item.frontWidthCm,1)} cm · profundidad lateral ${fmt(item.sideDepthCm,1)} cm</span></div>`).join('')}</div><div class="notice notice-warning"><span class="notice-icon">!</span><p><strong>Limitación importante.</strong> El escáner usa máscaras de silueta y escala aproximada a partir de la altura declarada. No es un modelo de IA entrenado directamente contra DXA. La perspectiva, distancia, lente, postura y ropa pueden alterar el resultado. Usa ropa ceñida y no volumétrica, el móvil estable y el mismo zoom/distancia para todas las vistas.</p></div><div class="scan-quality-row"><span>Consistencia de escala entre fotos</span><strong>${scaleLabel} · ${fmt(result.captureQuality?.scaleSpreadPct ?? 0,1)}%</strong><small>Esto mide consistencia geométrica entre capturas, no precisión corporal.</small></div><ul class="scan-warnings">${(result.warnings || []).map(x => `<li>${escapeHTML(x)}</li>`).join('')}</ul><small class="muted">Vistas utilizadas: ${escapeHTML((result.viewsUsed || []).join(', '))}. Escaneo realizado: ${escapeHTML(dateFmt(result.createdAt.slice(0,10)))}</small>`;
  renderScanValidation();
}

async function analyzeCapture(kind, image, sequence) {
  const status = $(`#pose-${kind}`);
  if (!poseConsent.checked) {
    poseResults[kind] = null;
    drawFeedback(kind, null);
    status.className = 'pose-feedback';
    status.textContent = 'Captura guardada. Activa la revisión automática para analizar los puntos anatómicos.';
    updatePosePairSummary();
    return;
  }
  status.className = 'pose-feedback';
  status.textContent = 'Preparando el detector de postura en este dispositivo…';
  $('#capture-status').textContent = 'Descargando o iniciando el motor de visión. La primera ejecución requiere conexión y puede tardar un poco.';
  try {
    const detector = await createPoseLandmarker();
    if (sequence !== captureSequence[kind] || !poseConsent.checked) return;
    await image.decode();
    const analysis = detectPoseInImage(detector, image, kind);
    if (sequence !== captureSequence[kind]) return;
    poseResults[kind] = analysis;
    renderPoseFeedback(kind, analysis);
    drawFeedback(kind, analysis.landmarks);
    $('#capture-status').textContent = 'Revisión de postura completada localmente. Las fotografías siguen solo en memoria y no se han enviado.';
    updatePosePairSummary();
  } catch (error) {
    if (sequence !== captureSequence[kind]) return;
    poseResults[kind] = null;
    status.className = 'pose-feedback review';
    status.innerHTML = '<strong>No se pudo ejecutar el análisis</strong><small>Comprueba tu conexión y vuelve a intentarlo. La captura sigue disponible, pero no ha sido validada.</small>';
    $('#capture-status').textContent = 'No se pudo iniciar el motor de visión. Puedes repetir el intento o continuar con medidas manuales.';
    updatePosePairSummary();
  }
}

$$('[data-capture]').forEach(input => input.addEventListener('change', async () => {
  const file = input.files?.[0]; if (!file) return;
  if (!file.type.startsWith('image/')) { toast('Selecciona un archivo de imagen.'); input.value = ''; return; }
  if (file.size > 12 * 1024 * 1024) { toast('La imagen supera el máximo de 12 MB.'); input.value=''; return; }
  const kind = input.dataset.capture;
  captureSequence[kind] += 1;
  const sequence = captureSequence[kind];
  poseResults[kind] = null;
  state.scanResult = null;
  saveState();
  renderScanResult();
  if (capturedUrls[kind]) URL.revokeObjectURL(capturedUrls[kind]);
  capturedUrls[kind] = URL.createObjectURL(file);
  const slot = $(`#slot-${kind}`);
  const img = $('img', slot);
  const canvas = $('canvas', slot);
  const ctx = canvas.getContext('2d');
  if (ctx) ctx.clearRect(0, 0, canvas.width, canvas.height);
  canvas.classList.remove('visible');
  img.src = capturedUrls[kind];
  img.classList.remove('hidden');
  $('.capture-outline', slot).classList.add('hidden');
  const viewLabels = { front: 'frontal', side: 'perfil derecho', back: 'posterior', side2: 'perfil izquierdo' };
  $('#capture-status').textContent = `Captura ${viewLabels[kind]} cargada. Se conserva solo en memoria mientras esta pantalla permanezca abierta.`;
  try { await img.decode(); } catch { toast('No se pudo leer la imagen. Prueba con otra fotografía.'); return; }
  if (sequence !== captureSequence[kind]) return;
  await analyzeCapture(kind, img, sequence);
}));

poseConsent.addEventListener('change', () => {
  if (!poseConsent.checked) {
    VIEW_KEYS.forEach(kind => {
      captureSequence[kind] += 1;
      poseResults[kind] = null;
      drawFeedback(kind, null);
      const node = $(`#pose-${kind}`);
      node.className = 'pose-feedback';
      node.textContent = capturedUrls[kind] ? 'Captura guardada sin análisis.' : 'Sin analizar.';
    });
    $('#capture-status').textContent = 'Revisión automática desactivada. Las fotografías capturadas no se han guardado ni enviado.';
    updatePosePairSummary();
    return;
  }
  VIEW_KEYS.forEach(kind => {
    if (!capturedUrls[kind]) return;
    const image = $('img', $(`#slot-${kind}`));
    captureSequence[kind] += 1;
    analyzeCapture(kind, image, captureSequence[kind]);
  });
  updatePosePairSummary();
});

$('#clear-captures').addEventListener('click', () => {
  VIEW_KEYS.forEach(kind => {
    captureSequence[kind] += 1;
    if (capturedUrls[kind]) URL.revokeObjectURL(capturedUrls[kind]);
    capturedUrls[kind] = null;
    poseResults[kind] = null;
    const slot = $(`#slot-${kind}`);
    $('img',slot).removeAttribute('src'); $('img',slot).classList.add('hidden');
    $('.capture-outline',slot).classList.remove('hidden');
    const canvas = $('canvas', slot); const ctx = canvas.getContext('2d');
    if (ctx) ctx.clearRect(0, 0, canvas.width, canvas.height);
    canvas.classList.remove('visible');
    $('input',slot).value='';
    const feedback = $(`#pose-${kind}`); feedback.className = 'pose-feedback'; feedback.textContent = 'Sin analizar.';
  });
  $('#capture-status').textContent = 'Capturas eliminadas de la sesión.';
  state.scanResult = null; saveState(); renderScanResult();
  updatePosePairSummary();
});

function buildWorkout(p) {
  const library = {
    home: {
      fullA: [['Sentadilla a silla','2–3 × 8–12'],['Flexión inclinada','2–3 × 6–10'],['Puente de glúteos','2–3 × 10–15'],['Bird-dog','2 × 8 por lado']],
      fullB: [['Zancada asistida','2 × 8 por lado'],['Flexión en pared','2–3 × 8–12'],['Bisagra de cadera','2–3 × 10–12'],['Dead bug','2 × 8 por lado']],
      upper: [['Flexión inclinada','2–3 × 6–10'],['Remo con banda','2–3 × 10–12'],['Press de hombro con banda','2 × 10'],['Plancha adaptada','2 × 15–30 s']],
      lower: [['Sentadilla a silla','2–3 × 8–12'],['Puente de glúteos','2–3 × 10–15'],['Step-up bajo','2 × 8 por lado'],['Elevación de talones','2 × 12–15']]
    },
    basic: {
      fullA: [['Sentadilla goblet','2–3 × 8–12'],['Remo con mancuerna','2–3 × 8–12'],['Peso muerto rumano ligero','2–3 × 8–10'],['Press de suelo','2–3 × 8–12']],
      fullB: [['Zancada asistida','2–3 × 8 por lado'],['Remo con banda/mancuerna','2–3 × 10'],['Press de hombro ligero','2 × 8–10'],['Puente de glúteos','2–3 × 12']],
      upper: [['Press de suelo','2–3 × 8–12'],['Remo con mancuerna','2–3 × 8–12'],['Press de hombro','2 × 8–10'],['Curl ligero','2 × 10–12']],
      lower: [['Sentadilla goblet','2–3 × 8–12'],['Peso muerto rumano ligero','2–3 × 8–10'],['Zancada asistida','2 × 8 por lado'],['Elevación de talones','2 × 12–15']]
    },
    gym: {
      fullA: [['Prensa o sentadilla guiada','2–3 × 8–12'],['Jalón al pecho','2–3 × 8–12'],['Peso muerto rumano','2–3 × 8–10'],['Press de pecho','2–3 × 8–12']],
      fullB: [['Sentadilla goblet o prensa','2–3 × 8–12'],['Remo sentado','2–3 × 8–12'],['Curl femoral','2–3 × 10–12'],['Press de hombro','2 × 8–10']],
      upper: [['Press de pecho','2–3 × 8–12'],['Jalón al pecho','2–3 × 8–12'],['Remo sentado','2–3 × 8–12'],['Press de hombro','2 × 8–10']],
      lower: [['Prensa','2–3 × 8–12'],['Peso muerto rumano','2–3 × 8–10'],['Curl femoral','2–3 × 10–12'],['Elevación de talones','2 × 12–15']]
    }
  };
  const count = Math.max(2, Math.min(5, p.sessions));
  const schedule = count === 2
    ? [['Lunes','Cuerpo completo A','fullA'],['Jueves','Cuerpo completo B','fullB']]
    : count === 3
      ? [['Lunes','Cuerpo completo A','fullA'],['Miércoles','Cuerpo completo B','fullB'],['Viernes','Cuerpo completo A','fullA']]
      : count === 4
        ? [['Lunes','Tren superior','upper'],['Martes','Tren inferior','lower'],['Jueves','Tren superior','upper'],['Viernes','Tren inferior','lower']]
        : [['Lunes','Tren superior','upper'],['Martes','Tren inferior','lower'],['Miércoles','Movilidad y caminata','recovery'],['Viernes','Tren superior','upper'],['Sábado','Tren inferior','lower']];
  return schedule.map(([day,title,kind]) => ({
    day, title,
    items: kind === 'recovery' ? [['Caminata cómoda','20–30 min'],['Movilidad suave','8–10 min'],['Respiración/pausas','5 min']] : library[p.equipment][kind],
    note: kind === 'recovery' ? 'Día ligero; no es una sesión de fuerza.' : p.experience === 'beginner' ? 'Prioriza técnica, control y terminar con energía suficiente.' : 'Ajusta cargas para mantener la técnica y varias repeticiones en reserva.'
  }));
}
function renderPlan() {
  const p = state.profile;
  $('#plan-empty').classList.toggle('hidden', !!p);
  $('#plan-content').classList.toggle('hidden', !p);
  if (!p) return;
  const capabilities = ageCapabilities(p.age);
  if (capabilities.isMinor) {
    const movementText = p.age < 2
      ? 'Para lactantes no se prescriben rutinas. El movimiento y las etapas del desarrollo deben acompañarse según la orientación pediátrica y siempre con supervisión.'
      : p.age < 5
        ? 'Prioriza juego libre, movimiento cotidiano y exploración segura apropiados para la etapa; no se asignan series, cargas ni objetivos de composición corporal.'
        : 'Prioriza juego activo, deportes que disfrute, caminar, bailar y actividades variadas. La actividad debe ser apropiada para su desarrollo, no centrada en peso o apariencia y supervisada por un adulto responsable.';
    const pediatricFat = profileBodyFatDetails(p);
    $('#plan-summary').innerHTML = `<article class="summary-tile"><small>MODO DE PERFIL</small><strong>Bienestar y crecimiento</strong><span>Perfil menor de 18 años · tutor confirmado</span></article><article class="summary-tile"><small>GRASA CORPORAL · ESTIMACIÓN</small><strong>${pediatricFat ? `≈ ${fmt(pediatricFat.percent,1)}%` : 'No estimada'}</strong><span>${pediatricFat ? `${pediatricFat.methods[0].name}. RMSE de estudio: ${fmt(pediatricFat.studyRmsePercentagePoints,2)} puntos a nivel de grupo; no es margen individual.` : (p.age >= 8 ? 'Requiere edad 8–17, referencia sexual compatible y cintura medida con cinta.' : 'No hay una ecuación validada integrada para esta etapa.')}</span></article><article class="summary-tile"><small>MÚSCULO</small><strong>No estimado</strong><span>No aplicamos ecuaciones adultas ni confundimos masa libre de grasa con músculo.</span></article><article class="summary-tile"><small>REFERENCIA DE CRECIMIENTO</small><strong>${capabilities.pediatricGrowthReference ? 'OMS / CDC por edad' : 'Valoración pediátrica'}</strong><span>Los percentiles no se calculan en esta versión.</span></article>`;
    $('#workout-plan').innerHTML = `<div class="notice notice-neutral"><span class="notice-icon">i</span><p>${movementText}</p></div><p class="muted tiny">FORMA no recomienda entrenamiento de fuerza adulto, pérdida de peso ni objetivos estéticos para menores.</p>`;
    $('#nutrition-plan').innerHTML = `<div class="notice notice-neutral"><span class="notice-icon">i</span><p>La alimentación en la infancia y adolescencia debe apoyar el crecimiento. Mantén horarios y variedad de alimentos, agua disponible y un entorno positivo; evita dietas restrictivas, conteo de calorías o suplementos sin indicación profesional. Consulta con pediatría/dietista pediátrico para necesidades específicas.</p></div>`;
    return;
  }
  const bmi = calculateBMI(p.weight, p.height);
  const safe = p.safety === 'no';
  const energy = safe && capabilities.mifflinEnergy ? calculateEnergyEstimate({ weightKg:p.weight, heightCm:p.height, age:p.age, equation:p.equation, activity:p.activity }) : null;
  const macro = energy ? calculateMacroGuide({ weightKg:p.weight, goal:p.goal }) : null;
  const maintenance = energy?.maintenance || null;
  const labelGoal = { fatloss:'Pérdida de grasa', muscle:'Fuerza y músculo', recomp:'Composición y hábitos', maintain:'Mantenimiento' }[p.goal];
  const calories = maintenance ? (p.goal === 'fatloss' ? { low:maintenance.low-300, high:maintenance.high-200 } : p.goal === 'muscle' ? { low:maintenance.low+100, high:maintenance.high+200 } : maintenance) : null;
  const activityText = `${p.sessions} sesiones por semana · ${p.experience === 'beginner' ? 'principiante' : p.experience === 'intermediate' ? 'intermedio' : 'avanzado'}`;
  const maintenanceText = maintenance ? (Math.abs(maintenance.high - maintenance.low) < 1 ? `≈ ${fmt(maintenance.low)}` : `${fmt(maintenance.low)}–${fmt(maintenance.high)}`) : 'No disponible para esta edad o contexto';
  const fatDetails = profileBodyFatDetails(p);
  const circumferenceEstimate = fatDetails?.percent ?? null;
  const composition = safe && circumferenceEstimate !== null ? calculateCompositionEstimate({weightKg:p.weight, bodyFatPercent:circumferenceEstimate, heightCm:p.height}) : null;
  const muscleEstimate = safe ? profileAppendicularMuscle(p) : null;
  const tapeFields = ['waist','neck','hip','chest','armLeft','armRight','forearmLeft','forearmRight','thighLeft','thighRight','calfLeft','calfRight'];
  const tapeCount = tapeFields.filter(key => Number.isFinite(p[key])).length;
  const tapeCompletenessTile = `<article class="summary-tile"><small>MEDIDAS COMPLEMENTARIAS</small><strong>${tapeCount}/12</strong><span>${tapeCount ? 'Medidas registradas; las ecuaciones solo utilizan los perímetros que requieren.' : 'No añadiste perímetros opcionales. El IMC puede aportar una estimación poblacional básica, con mayor incertidumbre.'}</span></article>`;
  const methodsText = fatDetails?.methods.map(item => item.name).join(' + ') || '';
  const spreadText = fatDetails?.count > 1 ? `Variación entre ecuaciones: ${fmt(fatDetails.low,1)}–${fmt(fatDetails.high,1)}% (no es intervalo de confianza).` : 'Solo hay una ecuación disponible; la incertidumbre individual puede ser amplia.';
  const bodyFatTile = safe ? `<article class="summary-tile"><small>GRASA CORPORAL · ESTIMACIÓN HÍBRIDA</small><strong>${circumferenceEstimate !== null ? `≈ ${fmt(circumferenceEstimate,1)}%` : 'Sin estimación'}</strong><span>${circumferenceEstimate !== null ? `${methodsText}. ${spreadText} Las ecuaciones poblacionales pueden variar según la población; no equivalen a DXA.` : (p.equation === 'range' ? 'Selecciona una referencia sexual compatible con las ecuaciones poblacionales para calcular este índice.' : 'Revisa edad, peso y altura para obtener una estimación basada en IMC.')}</span></article>${composition ? `<article class="summary-tile"><small>MASA GRASA ESTIMADA</small><strong>${fmt(composition.fatMassKg,1)} kg</strong><span>Derivada del porcentaje estimado.</span></article><article class="summary-tile"><small>MASA LIBRE DE GRASA</small><strong>${fmt(composition.fatFreeMassKg,1)} kg</strong><span>No equivale a músculo esquelético. FFMI derivado: ${fmt(composition.ffmi,1)}.</span></article>` : ''}<article class="summary-tile"><small>MÚSCULO ESQUELÉTICO APENDICULAR</small><strong>${muscleEstimate ? `≈ ${fmt(muscleEstimate.kg,1)} kg` : 'No estimado'}</strong><span>${muscleEstimate ? `Índice ASM/altura²: ${fmt(muscleEstimate.indexKgM2,2)} kg/m² · error estándar del estudio: 1,2 kg; la validez puede variar por población.` : (p.age < 40 || p.age > 87) ? 'La ecuación DXA seleccionada se estudió en adultos de 40–87 años; no extrapolamos fuera de ese rango.' : p.equation === 'range' ? 'Se necesita una referencia sexual compatible con la ecuación.' : 'Para calcularlo se necesitan cintura y al menos una pantorrilla medidas con cinta.'}</span></article>` : '';
  $('#plan-summary').innerHTML = `<article class="summary-tile"><small>OBJETIVO</small><strong>${labelGoal}</strong><span>${activityText}</span></article><article class="summary-tile"><small>IMC DE REFERENCIA</small><strong>${safe ? fmt(bmi,1) : 'No mostrado'}</strong><span>${safe ? `${classifyBMI(bmi)} · no estima grasa` : 'Oculto por contexto de seguridad'}</span></article><article class="summary-tile"><small>GASTO DE MANTENIMIENTO</small><strong>${safe && maintenance ? maintenanceText : 'No calculado'}</strong><span>${maintenance ? 'kcal/día · estimación inicial' : 'Fuera del rango Mifflin o restringido por seguridad'}</span></article>${bodyFatTile}${tapeCompletenessTile}`;
  if (state.scanResult?.measurements) { const sm=state.scanResult.measurements; const sc=state.scanResult.composition; $('#plan-summary').insertAdjacentHTML('beforeend', `<article class="summary-tile"><small>ESCÁNER · RESULTADO FOTOGRÁFICO</small><strong>${sc ? (sc.bodyFatPercent === null ? `${fmt(sc.bodyFatLow,1)}–${fmt(sc.bodyFatHigh,1)}% grasa` : `≈ ${fmt(sc.bodyFatPercent,1)}% grasa`) : `${fmt(sm.waist.circumferenceCm,1)} cm cintura visual`}</strong><span>Estimación exploratoria basada en la cintura extraída de las fotos. No equivale a DXA.</span></article>`); }
  const workouts = buildWorkout(p);
  $('#workout-plan').innerHTML = safe ? `<div class="workout-intro">${p.sessions} sesiones propuestas · comienza con cargas cómodas y aumenta gradualmente.</div>${workouts.map((day,i)=>{ const workoutId = `${today()}-${i}-${day.title}`; const done = state.completedWorkouts.includes(workoutId); return `<div class="workout-day"><div class="workout-day-head"><span class="day-index">${String(i+1).padStart(2,'0')}</span><div><strong>${day.day}</strong><small>${day.title}</small></div><button class="day-status workout-toggle" data-workout-id="${escapeHTML(workoutId)}">${done ? 'COMPLETADA ✓' : 'MARCAR HECHA'}</button></div><ul>${day.items.map(it=>`<li><span>${it[0]}</span><b>${it[1]}</b></li>`).join('')}</ul><p class="workout-note">${day.note}</p></div>`; }).join('')}<p class="muted tiny">Incluye calentamiento suave de 5–10 minutos. Suspende si aparece dolor agudo, mareo, dolor torácico o falta de aire inusual y busca atención adecuada.</p>` : `<div class="notice notice-warning"><span class="notice-icon">!</span><p>Por las respuestas de seguridad, no generamos una rutina individual automáticamente. Consulta con un profesional sanitario o del ejercicio que conozca tu situación antes de comenzar.</p></div>`;
  $$('[data-workout-id]').forEach(button => button.addEventListener('click', () => { const id = button.dataset.workoutId; state.completedWorkouts = state.completedWorkouts || []; state.completedWorkouts = state.completedWorkouts.includes(id) ? state.completedWorkouts.filter(x => x !== id) : [...state.completedWorkouts, id]; saveState(); renderPlan(); toast('Entrenamiento actualizado.'); }));
  const nutrition = safe && maintenance && calories ? `<div class="calorie-box"><small>MANTENIMIENTO ESTIMADO</small><strong>${maintenanceText}</strong><span>kcal/día · intervalo aproximado</span></div><div class="calorie-box secondary-calorie"><small>REFERENCIA INICIAL PARA TU OBJETIVO</small><strong>${Math.abs(calories.high-calories.low)<1 ? `≈ ${fmt(calories.low)}` : `${fmt(calories.low)}–${fmt(calories.high)}`}</strong><span>kcal/día · no es prescripción</span></div>` : `<div class="notice notice-warning"><span class="notice-icon">!</span><p>${safe ? 'No calculamos calorías fuera del rango de edad de Mifflin disponible.' : 'Por las respuestas de seguridad, no calculamos un objetivo calórico ni un déficit automático.'} Consulta con un profesional sanitario o dietista-nutricionista.</p></div>`;
  const macroMarkup = safe && macro ? `<div class="macro-row"><div><small>PROTEÍNA · REFERENCIA</small><strong>${macro.proteinGrams} g/día</strong><span>Rango orientativo ${macro.proteinRange[0]}–${macro.proteinRange[1]} g</span></div><div class="macro-mark">P</div></div><p class="muted tiny">La proteína es una referencia general basada en peso corporal; puede no ser apropiada en algunas condiciones médicas. ${escapeHTML(p.diet || 'Ajustar a preferencias y tolerancia alimentaria.')}</p>` : '';
  $('#nutrition-plan').innerHTML = `${nutrition}${macroMarkup}${safe ? `<div class="meal-ideas"><h3>Tu estructura diaria de alimentación</h3><p><strong>Desayuno:</strong> avena (40–60 g), yogur natural o alternativa y una fruta. Si evitas lácteos, usa bebida/alternativa enriquecida.</p><p><strong>Almuerzo:</strong> legumbres, pollo, pescado, huevo o tofu (una porción del tamaño de la palma), arroz/patata (un puño) y verduras (medio plato).</p><p><strong>Merienda:</strong> fruta y yogur, o pan integral con una fuente de proteína.</p><p><strong>Cena:</strong> proteína (una palma), verduras (medio plato) y cereal integral/patata (un puño), ajustando la porción al hambre y actividad.</p><p><strong>Tu preferencia registrada:</strong> ${escapeHTML(p.diet || 'Sin restricciones indicadas')}</p><small>Plantilla práctica adaptable, no un menú clínico ni una dieta calculada por una foto. Para personalizar cantidades exactas se necesita seguimiento de ingesta y evolución; no se asumen alergias no declaradas.</small></div>` : ''}<div class="nutrition-reminder"><strong>Revisa la tendencia, no un número aislado.</strong><p>Compara el promedio de peso, medidas, energía, hambre y rendimiento durante varias semanas antes de ajustar.</p></div>`;
}

function renderDiet() {
  const p=state.profile;
  $('#diet-empty').classList.toggle('hidden',!!p);
  $('#diet-content').classList.toggle('hidden',!p);
  if(!p) return;
  const capabilities = ageCapabilities(p.age);
  if (capabilities.isMinor) {
    $('#diet-summary').innerHTML = `<article class="summary-tile"><small>PERFIL</small><strong>Crecimiento</strong><span>Sin objetivos calóricos, macros ni reducción de peso.</span></article><article class="summary-tile"><small>ORIENTACIÓN</small><strong>Alimentación variada</strong><span>Las necesidades se valoran según crecimiento y situación individual.</span></article>`;
    $('#diet-menu').innerHTML = `<div class="notice notice-neutral"><span class="notice-icon">i</span><p>Ofrece comidas variadas y regulares, agua y un ambiente tranquilo y positivo. No cuentes calorías ni restrinjas alimentos para modificar peso o apariencia. Para alergias, crecimiento, selectividad alimentaria o condiciones de salud, consulta con un profesional pediátrico.</p></div>`;
    return;
  }
  const safe=p.safety==='no';
  const energy= safe && capabilities.mifflinEnergy ? calculateEnergyEstimate({weightKg:p.weight,heightCm:p.height,age:p.age,equation:p.equation,activity:p.activity}) : null;
  const maintenance=energy?.maintenance;
  let target=maintenance ? (p.goal==='fatloss'?{low:maintenance.low-250,high:maintenance.high-150}:p.goal==='muscle'?{low:maintenance.low+100,high:maintenance.high+200}:maintenance) : null;
  if (target && target.low < 1000) target = null;
  const macro=energy ? calculateMacroGuide({weightKg:p.weight,goal:p.goal}) : null;
  const macroTargets=target && macro ? calculateMacroTargets({weightKg:p.weight,calories:(target.low+target.high)/2,goal:p.goal}) : null;
  const calorieText=target ? (Math.abs(target.high-target.low)<1?`≈ ${fmt(target.low)}`:`${fmt(target.low)}–${fmt(target.high)}`) : 'No calculado';
  const fatDetails=profileBodyFatDetails(p);
  const muscleEstimate=profileAppendicularMuscle(p);
  $('#diet-summary').innerHTML=`<article class="summary-tile"><small>ENERGÍA DIARIA ORIENTATIVA</small><strong>${safe&&energy?calorieText:'No calculado'}</strong><span>kcal/día · objetivo ${({fatloss:'déficit moderado',muscle:'superávit pequeño',recomp:'recomposición',maintain:'mantenimiento'})[p.goal]}</span></article><article class="summary-tile"><small>PROTEÍNA DE REFERENCIA</small><strong>${safe&&macro?macro.proteinGrams+' g':'No calculada'}</strong><span>Proteína: ${safe&&macroTargets?macroTargets.proteinGrams+' g':''} · Grasas: ${safe&&macroTargets?macroTargets.fatGrams+' g':''} · Carbohidratos: ${safe&&macroTargets?macroTargets.carbohydrateGrams+' g':''} aprox.</span></article><article class="summary-tile"><small>GRASA CORPORAL</small><strong>${safe&&fatDetails?`≈ ${fmt(fatDetails.percent,1)}%`:'Sin estimación'}</strong><span>${fatDetails?`Modelos: ${fatDetails.methods.map(item=>item.name).join(' + ')}. Orientativo; no equivale a DXA.`:'Selecciona una referencia sexual compatible para estimarla con IMC/edad.'}</span></article><article class="summary-tile"><small>MÚSCULO APENDICULAR</small><strong>${safe&&muscleEstimate?`≈ ${fmt(muscleEstimate.kg,1)} kg`:'No estimado'}</strong><span>${muscleEstimate?'Ecuación antropométrica estudiada frente a DXA en adultos de 40 años o más.':'No se extrapola a edades fuera del estudio ni se confunde masa magra con músculo.'}</span></article>`;
  const pref=(p.diet||'').toLowerCase();
  const vegetarian=/vegetar|vegano|vegan/.test(pref), vegan=/vegano|vegan/.test(pref);
  const breakfast=vegan?'Avena con bebida de soja enriquecida, fruta y semillas.':vegetarian?'Avena con yogur o queso fresco, fruta y semillas.':'Avena con yogur natural, fruta y semillas.';
  const lunch=vegan?'Lentejas o tofu, arroz y verduras variadas.':vegetarian?'Garbanzos, huevo o tofu, arroz y verduras.':'Pollo, pescado o legumbres, arroz/patata y verduras.';
  const snack=vegan?'Fruta y un puñado pequeño de frutos secos o yogur de soja.':'Fruta y yogur, queso fresco o frutos secos.';
  const dinner=vegan?'Tofu o legumbres, patata/cereal integral y ensalada.':vegetarian?'Tortilla o tofu, patata/cereal integral y ensalada.':'Pescado, huevos, pollo o legumbres, patata/cereal integral y ensalada.';
  $('#diet-menu').innerHTML=safe&&energy?`<div class="diet-target"><strong>${calorieText} kcal/día</strong><span>Intervalo inicial para ${p.goal==='fatloss'?'pérdida gradual de grasa':p.goal==='muscle'?'ganancia de fuerza y masa':p.goal==='maintain'?'mantenimiento':'recomposición y hábitos'}.</span></div><div class="diet-meal"><small>DESAYUNO</small><p>${breakfast}</p><span>Incluye una fuente de proteína, carbohidrato y fruta.</span></div><div class="diet-meal"><small>ALMUERZO</small><p>${lunch}</p><span>Prioriza verduras y una fuente de proteína en cada comida principal.</span></div><div class="diet-meal"><small>MERIENDA</small><p>${snack}</p><span>Ajusta o elimina según hambre y horarios.</span></div><div class="diet-meal"><small>CENA</small><p>${dinner}</p><span>Adapta las porciones a tu apetito, actividad y registro de peso.</span></div><div class="notice notice-neutral"><span class="notice-icon">i</span><p>La dieta se personaliza con tu objetivo y preferencias (${escapeHTML(p.diet||'sin restricciones indicadas')}). Para ajustar porciones con precisión, registra alimentos y revisa la tendencia durante 2–4 semanas. El escáner visual no se utiliza para inventar calorías ni músculo; sus perímetros no están validados para alimentar las ecuaciones.</p></div>`:`<div class="notice notice-warning"><span class="notice-icon">!</span><p>${safe ? 'No calculamos objetivos calóricos fuera del rango de edad de la ecuación metabólica disponible.' : 'Por las respuestas de seguridad no se genera un objetivo calórico automático.'} Puedes utilizar esta sección como orientación general y consultar a un profesional sanitario o dietista-nutricionista.</p></div>`;
}

$('#log-form').elements.date.value = today();
$('#log-form').elements.date.max = today();
$('#log-form').addEventListener('submit', event => {
  event.preventDefault(); const form = new FormData(event.currentTarget);
  const weight = form.get('weight') ? Number(form.get('weight')) : null;
  const waist = form.get('waist') ? Number(form.get('waist')) : null;
  if (weight === null && waist === null) { $('#log-message').textContent = 'Introduce al menos peso o cintura.'; return; }
  state.logs.push({ date:form.get('date'), weight, waist, note:form.get('note').trim(), createdAt:new Date().toISOString() });
  state.logs.sort((a,b)=>a.date.localeCompare(b.date)); saveState(); event.currentTarget.reset(); event.currentTarget.elements.date.value=today(); event.currentTarget.elements.date.max=today(); $('#log-message').textContent='Registro guardado.'; renderHistory(); renderDashboard(); toast('Progreso guardado.');
});
function renderHistory() {
  const logs = [...state.logs].sort((a,b)=>b.date.localeCompare(a.date));
  $('#history-count').textContent = `${logs.length} ${logs.length === 1 ? 'registro' : 'registros'}`;
  $('#history-empty').classList.toggle('hidden', logs.length > 0);
  $('#history-list').innerHTML = logs.map(log=>`<div class="history-row"><div class="history-date"><strong>${escapeHTML(dateFmt(log.date))}</strong><small>${escapeHTML(log.note || 'Sin nota')}</small></div><div class="history-values">${log.weight ? `<span>${fmt(log.weight,1)} <small>kg</small></span>` : ''}${log.waist ? `<span>${fmt(log.waist,1)} <small>cm cintura</small></span>` : ''}</div><button class="delete-log" data-delete-log="${escapeHTML(log.createdAt)}" title="Eliminar registro">×</button></div>`).join('');
  $$('[data-delete-log]').forEach(button=>button.addEventListener('click',()=>{ state.logs=state.logs.filter(x=>x.createdAt!==button.dataset.deleteLog); saveState(); renderHistory(); renderDashboard(); }));
}

function coachReply(message) {
  const q = message.toLowerCase();
  const profile = state.profile;
  const scan = state.scanResult?.measurements;
  if (profile && profile.age < 18) { const pediatric = profileBodyFatDetails(profile); return `Este perfil está en modo de crecimiento. ${pediatric ? `La estimación exploratoria RFM es ${fmt(pediatric.percent,1)}%; solo se habilita con cintura medida con cinta y tutor confirmado, y no es una clasificación clínica.` : 'No hay una estimación de grasa aplicable con los datos o la edad actuales.'} No calculo músculo, IMC adulto, calorías ni objetivos de pérdida de peso. Puedo orientar sobre juego activo, movimiento divertido y hábitos generales con supervisión de un adulto. Para interpretar talla y peso se usan curvas de crecimiento por edad y sexo con apoyo de pediatría.`; }
  if (profile && /mi esc[aá]ner|mis medidas|mi cintura|mi f[ií]sico|mi composici[oó]n/.test(q)) {
    const scanText = scan ? ` El último escaneo visual experimental estimó una cintura de ${fmt(scan.waist.circumferenceCm,1)} cm; su precisión es baja y debes confirmarla con cinta.` : ' Todavía no hay un escaneo corporal completo guardado.';
    const fat = profileBodyFatDetails(profile);
    const asm = profileAppendicularMuscle(profile);
    return `Según tu perfil: ${profile.weight} kg, ${profile.height} cm y objetivo ${({fatloss:'pérdida de grasa',muscle:'fuerza y músculo',recomp:'recomposición',maintain:'mantenimiento'})[profile.goal] || profile.goal}.${fat ? ` El porcentaje de grasa estimado es ${fmt(fat.percent,1)}% mediante ${fat.methods.map(item=>item.name).join(' + ')}; la variación entre ecuaciones no es un intervalo clínico.` : ' No hay suficientes datos o una referencia compatible para calcular porcentaje de grasa.'}${asm ? ` La masa muscular esquelética apendicular estimada es ${fmt(asm.kg,1)} kg, basada en una ecuación estudiada en adultos de 40 años o más.` : ' No hay una estimación de masa muscular apendicular aplicable con los datos actuales.'}${scanText} La masa libre de grasa no equivale a músculo esquelético.`;
  }
  if (/dolor|lesi[oó]n|mareo|desmayo|pecho|embaraz|enfermedad|medicaci[oó]n|trastorno aliment/.test(q)) return 'Por seguridad, no puedo valorar ni tratar síntomas o condiciones médicas. Evita el ejercicio que provoca síntomas y consulta con un profesional sanitario. Si hay dolor torácico, desmayo, dificultad respiratoria intensa o síntomas graves, busca atención urgente.';
  if (/calor[ií]a|energ[ií]a|metabol/.test(q)) return 'FORMA estima el metabolismo en reposo con Mifflin–St Jeor y aplica un factor de actividad para aproximar el mantenimiento. Es un punto de partida: contrasta la tendencia de peso, actividad, hambre y bienestar durante 2–4 semanas. El gasto real puede diferir.';
  if (/prote[ií]na|macro/.test(q)) return 'La proteína ayuda a mantener y desarrollar tejido muscular cuando se combina con entrenamiento de fuerza. Esta versión ofrece una referencia general por kilogramo, no una prescripción. Si tienes enfermedad renal u otra condición médica, consulta antes de cambiar la ingesta.';
  if (/rutina|entren|m[uú]sculo|fuerza/.test(q)) return 'Empieza con movimientos que puedas controlar, 2–3 sesiones semanales de cuerpo completo, calentamiento y progresión gradual. Aprende la técnica antes de aumentar cargas. Deja recuperación entre sesiones y adapta el esfuerzo a tu experiencia.';
  if (/grasa|imc|esc[aá]ner|porcentaje|dxa/.test(q)) return 'El IMC no mide grasa. El escáner de FORMA obtiene perímetros elípticos experimentales de la silueta y usa la cintura visual junto con datos del perfil para una estimación exploratoria de grasa corporal. No es un modelo de IA validado contra DXA. La masa libre de grasa no equivale a músculo; el escáner no cuantifica directamente músculo esquelético.';
  if (/comida|dieta|aliment|nutric/.test(q)) return 'Prioriza un patrón sostenible con variedad de verduras y frutas, fuentes de proteína, legumbres o cereales integrales y grasas saludables. Ajusta cantidades a tu contexto, preferencias y salud. No necesitas eliminar grupos de alimentos ni seguir dietas extremas.';
  return 'Puedo explicar las estimaciones de FORMA, el seguimiento, las bases de entrenamiento y la nutrición general. Esta versión utiliza respuestas guiadas, no una IA generativa conectada. Prueba una pregunta sobre calorías, proteína, entrenamiento o escaneo.';
}
function addMessage(text, type) { const node=document.createElement('div'); node.className=`chat-bubble ${type==='user'?'user-bubble':'coach-bubble'}`; node.textContent=text; $('#chat-messages').append(node); $('#chat-messages').scrollTop=$('#chat-messages').scrollHeight; }

function renderScanValidation() {
  const root = $('#scan-validation-history');
  if (!root) return;
  const entries = state.scanValidations || [];
  if (!entries.length) { root.innerHTML = '<p class="muted">Todavía no has comparado el escáner con una cinta métrica.</p>'; return; }
  root.innerHTML = entries.slice(-5).reverse().map(entry => {
    const rows = entry.measurements.map(item => `<div class="validation-row"><span>${escapeHTML(({chest:'Pecho',waist:'Cintura',hip:'Cadera'})[item.level] || item.level)}</span><strong>${fmt(item.absoluteErrorCm,1)} cm de diferencia</strong><small>Escáner ${fmt(item.estimatedCm,1)} cm · cinta ${fmt(item.measuredCm,1)} cm (${fmt(item.errorPercent,1)}%)</small></div>`).join('');
    return `<article class="validation-entry"><small>${escapeHTML(dateFmt(entry.createdAt.slice(0,10)))}</small>${rows}<strong class="validation-mae">Error absoluto medio de esta comparación: ${fmt(entry.meanAbsoluteErrorCm,1)} cm</strong></article>`;
  }).join('');
}

$('#scan-check-form').addEventListener('submit', event => {
  event.preventDefault();
  if (!state.scanResult?.measurements) { $('#scan-check-message').textContent = 'Primero completa un escaneo con la vista frontal y al menos un perfil.'; return; }
  try {
    const values = new FormData(event.currentTarget);
    const tape = { chest: values.get('chest') ? Number(values.get('chest')) : null, waist: values.get('waist') ? Number(values.get('waist')) : null, hip: values.get('hip') ? Number(values.get('hip')) : null };
    const comparison = compareScanToTape(state.scanResult.measurements, tape);
    const entry = { ...comparison, id: idForEntry(), createdAt: new Date().toISOString() };
    state.scanValidations = [...(state.scanValidations || []), entry].slice(-500);
    saveState();
    $('#scan-check-message').textContent = 'Comparación guardada localmente. Esta prueba individual no valida la precisión general del modelo.';
    renderScanValidation();
    toast('Comparación guardada.');
  } catch (error) { $('#scan-check-message').textContent = error.message; }
});

function renderDiary() {
  const minor = Boolean(state.profile && state.profile.age < 18);
  $('#minor-diary-notice').classList.toggle('hidden', !minor);
  $('#minor-activity-panel').classList.toggle('hidden', !minor);
  ['adult-diary-layout','adult-diary-summary','adult-diary-history'].forEach(id => $(`#${id}`).classList.toggle('hidden', minor));
  const selectedDate = (minor ? $('#activity-date-filter').value : $('#diary-date').value) || today();
  if (minor) {
    const rows = dailyActivityEntries(state.activityEntries || [], selectedDate).sort((a,b) => String(b.createdAt).localeCompare(String(a.createdAt)));
    $('#activity-history').innerHTML = rows.length ? rows.map(item => `<div class="diary-row"><div><strong>${escapeHTML(item.activity)}</strong><small>${fmt(item.durationMin)} min · ${escapeHTML(item.note || 'Sin nota')}</small></div></div>`).join('') : '<p class="muted">Todavía no hay actividades registradas para esta fecha.</p>';
    return;
  }
  const meals = dailyFoodEntries(state.foodEntries || [], selectedDate);
  const exercises = dailyExerciseEntries(state.exerciseEntries || [], selectedDate);
  const totals = calculateFoodTotals(meals);
  $('#diary-totals').innerHTML = `<div class="diary-total"><small>Comidas</small><strong>${totals.items}</strong></div><div class="diary-total"><small>Calorías registradas</small><strong>${fmt(totals.calories)} kcal</strong></div><div class="diary-total"><small>Proteína</small><strong>${fmt(totals.protein,1)} g</strong></div><div class="diary-total"><small>Carbohidratos / grasas</small><strong>${fmt(totals.carbs,1)} / ${fmt(totals.fat,1)} g</strong></div><div class="diary-total"><small>Ejercicios</small><strong>${exercises.length}</strong></div>`;
  $('#food-history').innerHTML = meals.length ? meals.map(item => `<div class="diary-row"><div><strong>${escapeHTML(item.name)}</strong><small>${escapeHTML(({breakfast:'Desayuno',lunch:'Almuerzo',dinner:'Cena',snack:'Merienda'})[item.mealType] || item.mealType)}</small></div><span>${Number.isFinite(item.calories) ? `${fmt(item.calories)} kcal` : 'Sin calorías'}</span></div>`).join('') : '<p class="muted">No hay comidas registradas para esta fecha.</p>';
  $('#exercise-history').innerHTML = exercises.length ? exercises.map(item => `<div class="diary-row"><div><strong>${escapeHTML(item.exercise)}</strong><small>${item.sets} × ${item.reps} · ${fmt(item.loadKg,1)} kg${item.rpe ? ` · RPE ${item.rpe}` : ''}</small></div></div>`).join('') : '<p class="muted">No hay ejercicios registrados para esta fecha.</p>';
}

$('#food-form').elements.date.max = today();
$('#exercise-entry-form').elements.date.value = today();
$('#exercise-entry-form').elements.date.max = today();
$('#diary-date').value = today();
$('#activity-entry-form').elements.date.value = today();
$('#activity-entry-form').elements.date.max = today();
$('#activity-date-filter').value = today();
$('#activity-date-filter').max = today();
$('#food-form').addEventListener('submit', event => {
  event.preventDefault();
  try {
    const values = new FormData(event.currentTarget);
    const entry = validateFoodEntry({ name: values.get('name'), mealType: values.get('mealType'), date: values.get('date'), calories: values.get('calories'), protein: values.get('protein'), carbs: values.get('carbs'), fat: values.get('fat') });
    state.foodEntries.push({ ...entry, id: idForEntry(), createdAt: new Date().toISOString() });
    saveState(); event.currentTarget.reset(); event.currentTarget.elements.date.value = today(); event.currentTarget.elements.date.max = today();
    $('#food-message').textContent = 'Comida guardada en este dispositivo.'; renderDiary(); toast('Comida registrada.');
  } catch (error) { $('#food-message').textContent = error.message; }
});
$('#exercise-entry-form').addEventListener('submit', event => {
  event.preventDefault();
  try {
    const values = new FormData(event.currentTarget);
    const entry = validateExerciseEntry({ exercise: values.get('exercise'), date: values.get('date'), sets: values.get('sets'), reps: values.get('reps'), loadKg: values.get('loadKg'), rpe: values.get('rpe'), note: values.get('note') });
    state.exerciseEntries.push({ ...entry, id: idForEntry(), createdAt: new Date().toISOString() });
    saveState(); event.currentTarget.reset(); event.currentTarget.elements.date.value = today(); event.currentTarget.elements.date.max = today();
    $('#exercise-message').textContent = 'Ejercicio guardado en este dispositivo.'; renderDiary(); toast('Ejercicio registrado.');
  } catch (error) { $('#exercise-message').textContent = error.message; }
});
$('#activity-entry-form').addEventListener('submit', event => {
  event.preventDefault();
  if (!state.profile || state.profile.age >= 18) { $('#activity-message').textContent = 'La bitácora de actividad sencilla está disponible solo en modo menor.'; return; }
  try {
    const values = new FormData(event.currentTarget);
    const entry = validateActivityEntry({ activity: values.get('activity'), date: values.get('date'), durationMin: values.get('durationMin'), note: values.get('note') });
    state.activityEntries = state.activityEntries || [];
    state.activityEntries.push({ ...entry, id: idForEntry(), createdAt: new Date().toISOString() });
    saveState(); event.currentTarget.reset(); event.currentTarget.elements.date.value = today(); event.currentTarget.elements.date.max = today();
    $('#activity-message').textContent = 'Actividad guardada en este dispositivo.'; renderDiary(); toast('Actividad registrada.');
  } catch (error) { $('#activity-message').textContent = error.message; }
});

$('#diary-date').addEventListener('change', renderDiary);
$('#activity-date-filter').addEventListener('change', renderDiary);

$('#import-data-file').addEventListener('change', async event => {
  const fileInput = event.currentTarget;
  const file = fileInput.files?.[0];
  if (!file) return;
  try {
    if (file.size > 5 * 1024 * 1024) throw new Error('El respaldo supera el máximo de 5 MB.');
    const backup = normalizeBackup(JSON.parse(await file.text()));
    if (!confirm('Restaurar este respaldo reemplazará los datos locales actuales. ¿Deseas continuar?')) return;
    state = backup;
    saveState();
    $('#profile-form').reset(); populateForm();
    renderDashboard(); renderHistory(); renderPlan(); renderDiet(); renderDiary(); renderScanResult(); renderScanValidation();
    toast('Respaldo restaurado.');
  } catch (error) { toast(error.message || 'No se pudo restaurar el respaldo.'); }
  finally { fileInput.value = ''; }
});

$('#export-data').addEventListener('click',()=>{ const blob=new Blob([JSON.stringify({exportedAt:new Date().toISOString(),...state},null,2)],{type:'application/json'}); const url=URL.createObjectURL(blob); const a=document.createElement('a'); a.href=url; a.download=`forma-datos-${today()}.json`; a.click(); window.setTimeout(()=>URL.revokeObjectURL(url),1000); toast('Copia de datos exportada.'); });
$('#delete-data').addEventListener('click',()=>{ if(!confirm('¿Eliminar la evaluación, comidas, ejercicios y registros guardados en este dispositivo? Los datos se eliminan únicamente de este dispositivo. Esta acción no se puede deshacer.'))return; localStorage.removeItem(STORAGE_KEY); state={profile:null,scanResult:null,scanValidations:[],logs:[],completedWorkouts:[],foodEntries:[],exerciseEntries:[],activityEntries:[]}; $('#profile-form').reset(); renderDashboard(); renderHistory(); renderPlan(); renderDiet(); renderDiary(); renderScanResult(); renderScanValidation(); toast('Tus datos locales se han eliminado.'); go('inicio'); });

populateForm(); renderScanResult(); renderScanValidation(); renderDashboard(); renderHistory(); renderPlan(); renderDiet(); renderDiary();
if ('serviceWorker' in navigator && location.protocol.startsWith('http')) navigator.serviceWorker.register('./service-worker.js').catch(()=>{});
const initial = location.hash.replace('#',''); if (['inicio','evaluacion','escaner','plan','dieta','progreso','diario','coach'].includes(initial)) go(initial);
