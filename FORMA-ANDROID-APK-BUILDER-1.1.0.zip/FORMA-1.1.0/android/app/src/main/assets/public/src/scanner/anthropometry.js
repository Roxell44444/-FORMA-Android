/**
 * Experimental multi-view body-shape proxy (two required, two optional).
 * A per-pose MediaPipe confidence mask is sampled around anatomical landmarks.
 * Pixel scale still comes from declared height and perspective is not solved.
 * This is NOT validated anthropometry, DXA, body-fat, or skeletal-muscle analysis.
 */
function maskBounds(mask) {
  const { data, width, height } = mask || {};
  if (!data || !Number.isInteger(width) || !Number.isInteger(height) || data.length !== width * height) {
    throw new TypeError('La máscara corporal no es válida.');
  }
  let minX = width, maxX = -1, minY = height, maxY = -1, count = 0;
  for (let y = 0; y < height; y++) for (let x = 0; x < width; x++) {
    if (data[y * width + x] > 0) {
      count++; minX = Math.min(minX, x); maxX = Math.max(maxX, x); minY = Math.min(minY, y); maxY = Math.max(maxY, y);
    }
  }
  if (maxX < minX || maxY < minY) throw new Error('No se pudo separar la silueta de la persona.');
  const bounds = { minX, maxX, minY, maxY, width: maxX - minX + 1, height: maxY - minY + 1 };
  bounds.fillRatio = count / (bounds.width * bounds.height);
  bounds.imageCoverage = count / (width * height);
  if (bounds.fillRatio < 0.12) throw new Error('La máscara tiene demasiados fragmentos o ruido. Mejora la luz y utiliza un fondo despejado.');
  return bounds;
}

function torsoGeometry(landmarks) {
  if (!Array.isArray(landmarks) || landmarks.length < 29) throw new Error('Faltan puntos anatómicos para ubicar el torso.');
  const ids = [11, 12, 23, 24];
  if (ids.some(i => !Number.isFinite(landmarks[i]?.x) || !Number.isFinite(landmarks[i]?.y))) {
    throw new Error('No se detectaron hombros y caderas con claridad.');
  }
  const shoulder = { x: (landmarks[11].x + landmarks[12].x) / 2, y: (landmarks[11].y + landmarks[12].y) / 2 };
  const hip = { x: (landmarks[23].x + landmarks[24].x) / 2, y: (landmarks[23].y + landmarks[24].y) / 2 };
  if (hip.y <= shoulder.y + 0.08) throw new Error('La orientación corporal no permite ubicar el torso.');
  return {
    chest: { y: shoulder.y + (hip.y - shoulder.y) * 0.28, t: 0.28 },
    waist: { y: shoulder.y + (hip.y - shoulder.y) * 0.66, t: 0.66 },
    hip: { y: hip.y, t: 1 },
    shoulder, hipCenter: hip
  };
}

function median(values) {
  if (!values.length) return null;
  const sorted = [...values].sort((a, b) => a - b);
  const mid = Math.floor(sorted.length / 2);
  return sorted.length % 2 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2;
}

function rowRuns(mask, y, minX, maxX) {
  const runs = [];
  let start = -1;
  for (let x = minX; x <= maxX + 1; x++) {
    const foreground = x <= maxX && mask.data[y * mask.width + x] > 0;
    if (foreground && start < 0) start = x;
    if (!foreground && start >= 0) { runs.push({ left: start, right: x - 1, width: x - start }); start = -1; }
  }
  return runs;
}

/** Robust band sampler: median of several rows, tracking the torso center at each height. */
function sampleTorsoBand(mask, bounds, landmarks, level) {
  const geometry = torsoGeometry(landmarks);
  const target = geometry[level];
  const centerXNorm = geometry.shoulder.x + (geometry.hipCenter.x - geometry.shoulder.x) * target.t;
  const targetY = Math.round(target.y * (mask.height - 1));
  const centerX = centerXNorm * (mask.width - 1);
  const radiusY = Math.max(2, Math.round(mask.height * 0.012));
  const minX = Math.max(bounds.minX, Math.floor(centerX - bounds.width * 0.42));
  const maxX = Math.min(bounds.maxX, Math.ceil(centerX + bounds.width * 0.42));
  const widths = [];
  for (let y = Math.max(bounds.minY, targetY - radiusY); y <= Math.min(bounds.maxY, targetY + radiusY); y++) {
    const runs = rowRuns(mask, y, minX, maxX).filter(run => run.width >= Math.max(3, bounds.width * 0.035));
    if (!runs.length) continue;
    const centerRun = runs.find(run => run.left <= centerX && run.right >= centerX);
    const selected = centerRun || runs.sort((a, b) => {
      const da = Math.abs((a.left + a.right) / 2 - centerX);
      const db = Math.abs((b.left + b.right) / 2 - centerX);
      return da - db;
    })[0];
    if (selected) widths.push(selected.width);
  }
  const px = median(widths);
  if (!px || widths.length < Math.max(2, Math.ceil((radiusY * 2 + 1) * 0.35))) {
    throw new Error(`No se pudo medir la banda de ${level}. Revisa que los brazos no oculten el torso y repite la captura.`);
  }
  return { pixels: px, rowsUsed: widths.length, rowsAvailable: radiusY * 2 + 1, normalizedY: target.y, centerXNorm };
}

function ellipsePerimeterProxy(frontWidthCm, sideDepthCm) {
  if (!(frontWidthCm > 0 && sideDepthCm > 0)) return null;
  const a = frontWidthCm / 2, b = sideDepthCm / 2;
  return Math.PI * (3 * (a + b) - Math.sqrt((3 * a + b) * (a + 3 * b)));
}

function viewWidth(mask, landmarks, level, heightCm) {
  const bounds = maskBounds(mask);
  if (bounds.height < mask.height * 0.58 || bounds.minY < mask.height * 0.015 || bounds.maxY > mask.height * 0.985) {
    throw new Error('La silueta está cortada o ocupa muy poca altura. Repite la captura con cabeza y pies visibles.');
  }
  if (bounds.imageCoverage < 0.04 || bounds.imageCoverage > 0.82) throw new Error('La máscara ocupa una proporción anómala de la imagen. Ajusta la distancia y el encuadre.');
  const sample = sampleTorsoBand(mask, bounds, landmarks, level);
  // Approximate scale from declared height. Camera perspective and lens distortion remain unresolved.
  const pxPerCm = bounds.height / heightCm;
  return {
    cm: sample.pixels / pxPerCm,
    px: sample.pixels,
    pxPerCm,
    rowsUsed: sample.rowsUsed,
    rowsAvailable: sample.rowsAvailable,
    maskFillRatio: bounds.fillRatio,
    silhouetteHeightPx: bounds.height
  };
}

export function estimateTwoViewAnthropometry({ frontMask, sideMask, frontLandmarks, sideLandmarks, backMask = null, backLandmarks = null, side2Mask = null, side2Landmarks = null, heightCm }) {
  if (!Number.isFinite(heightCm) || heightCm < 130 || heightCm > 230) throw new RangeError('Introduce una altura válida en tu perfil (130–230 cm).');
  const measurements = {};
  const diagnostics = {};
  const viewsUsed = ['frontal', 'perfil'];
  const allScaleSamples = [];
  const front = viewWidth(frontMask, frontLandmarks, 'waist', heightCm);
  const side = viewWidth(sideMask, sideLandmarks, 'waist', heightCm);
  allScaleSamples.push(front.pxPerCm, side.pxPerCm);
  const hasBack = Boolean(backMask && backLandmarks);
  const hasSide2 = Boolean(side2Mask && side2Landmarks);
  let validBack = null;
  let validSide2 = null;
  if (hasBack) {
    try { validBack = viewWidth(backMask, backLandmarks, 'waist', heightCm); allScaleSamples.push(validBack.pxPerCm); viewsUsed.push('posterior'); }
    catch { /* optional view is excluded when its mask is unsuitable */ }
  }
  if (hasSide2) {
    try { validSide2 = viewWidth(side2Mask, side2Landmarks, 'waist', heightCm); allScaleSamples.push(validSide2.pxPerCm); viewsUsed.push('perfil contrario'); }
    catch { /* optional view is excluded when its mask is unsuitable */ }
  }
  const scaleMedian = median(allScaleSamples);
  const scaleSpreadPct = scaleMedian > 0
    ? Number(((Math.max(...allScaleSamples) - Math.min(...allScaleSamples)) / scaleMedian * 100).toFixed(1))
    : 0;
  const scaleConsistency = scaleSpreadPct <= 10 ? 'consistente' : scaleSpreadPct <= 25 ? 'variable' : 'inconsistente';

  for (const level of ['chest', 'waist', 'hip']) {
    const frontLevel = level === 'waist' ? front : viewWidth(frontMask, frontLandmarks, level, heightCm);
    const sideLevel = level === 'waist' ? side : viewWidth(sideMask, sideLandmarks, level, heightCm);
    const frontSamples = [frontLevel];
    const sideSamples = [sideLevel];
    if (validBack) {
      try { frontSamples.push(viewWidth(backMask, backLandmarks, level, heightCm)); } catch { /* optional view is excluded for this band */ }
    }
    if (validSide2) {
      try { sideSamples.push(viewWidth(side2Mask, side2Landmarks, level, heightCm)); } catch { /* optional view is excluded for this band */ }
    }
    const frontWidthCm = Number(median(frontSamples.map(x => x.cm)).toFixed(1));
    const sideDepthCm = Number(median(sideSamples.map(x => x.cm)).toFixed(1));
    const circumferenceCm = Number(ellipsePerimeterProxy(frontWidthCm, sideDepthCm).toFixed(1));
    measurements[level] = { frontWidthCm, sideDepthCm, circumferenceCm };
    diagnostics[level] = {
      frontRowsUsed: frontLevel.rowsUsed, sideRowsUsed: sideLevel.rowsUsed,
      frontViewsUsed: frontSamples.length, sideViewsUsed: sideSamples.length,
      frontMaskFillRatio: Number(frontLevel.maskFillRatio.toFixed(3)),
      sideMaskFillRatio: Number(sideLevel.maskFillRatio.toFixed(3))
    };
  }
  const warnings = [
    'Estimación geométrica experimental; no validada frente a cinta métrica, escáner 3D ni DXA.',
    'Las vistas adicionales permiten contrastar capturas, pero no eliminan errores de perspectiva, distancia, inclinación, postura ni distorsión de lente.',
    'El perímetro es un proxy elíptico a partir de anchuras 2D; la sección corporal real no es necesariamente una elipse.',
    'Las medidas opcionales introducidas por la persona se conservan separadas; solo las medidas compatibles con una ecuación validada se utilizan para esa ecuación.',
    'No usar estos resultados para diagnóstico, prescripción médica ni para afirmar masa muscular o porcentaje de grasa como medición clínica.'
  ];
  if (scaleSpreadPct > 25) warnings.push(`La escala entre las vistas varía ${scaleSpreadPct.toFixed(1)}%. Repite las fotos con el teléfono a la misma distancia, altura y zoom; no se generará una estimación de grasa basada en estas imágenes.`);
  else if (scaleSpreadPct > 10) warnings.push(`La escala entre las vistas varía ${scaleSpreadPct.toFixed(1)}%. La comparación de perímetros y la estimación de grasa tienen incertidumbre adicional.`);
  return {
    measurements,
    viewsUsed,
    method: 'MediaPipe Pose Landmarker; bandas de silueta en frontal y perfil; mediana de vistas posteriores opuestas cuando están disponibles; escala aproximada por altura declarada; perímetro elíptico proxy',
    confidence: 'experimental-low',
    captureQuality: { scaleSpreadPct, scaleConsistency, scaleSamples: allScaleSamples.length },
    diagnostics,
    warnings
  };
}
