/** Age-aware feature gates. These gates prevent adult equations from being
 * silently applied to children or outside the studied age ranges. */
export function classifyAge(age) {
  if (!Number.isFinite(age) || age < 0 || age > 130) throw new RangeError('La edad debe estar entre 0 y 130 años.');
  if (age < 2) return 'infant';
  if (age < 5) return 'early-childhood';
  if (age < 18) return 'minor';
  return 'adult';
}

export function ageCapabilities(age) {
  const group = classifyAge(age);
  return {
    group,
    isMinor: group !== 'adult',
    pediatricGrowthReference: age >= 5 && age <= 19,
    bodyFatEquations: age >= 18 && age <= 80,
    mifflinEnergy: age >= 19 && age <= 78,
    appendicularMuscleEquation: age >= 40 && age <= 87,
    bodyPhotoScanner: group === 'adult'
  };
}
