const CACHE = 'forma-1.1.0-shell';
const FILES = [
  '', 'index.html', 'manifest.webmanifest', 'src/ui/styles.css', 'src/app.js',
  'src/core/age.js', 'src/core/metrics.js', 'src/core/diary.js', 'src/core/backup.js', 'src/scanner/pose.js', 'src/scanner/anthropometry.js', 'src/scanner/validation.js',
  'public/icon.svg'
];
const urls = FILES.map(path => new URL(path, self.registration.scope).href);

self.addEventListener('install', event => event.waitUntil(
  caches.open(CACHE).then(cache => cache.addAll(urls)).then(() => self.skipWaiting())
));
self.addEventListener('activate', event => event.waitUntil(
  caches.keys().then(keys => Promise.all(keys.filter(key => key.startsWith('forma-') && key !== CACHE).map(key => caches.delete(key))))
    .then(() => self.clients.claim())
));
self.addEventListener('fetch', event => {
  if (event.request.method !== 'GET') return;
  const requestUrl = new URL(event.request.url);
  if (requestUrl.origin !== self.location.origin) return;
  event.respondWith(caches.match(event.request).then(cached => {
    if (cached) return cached;
    return fetch(event.request).then(response => {
      if (response.ok) caches.open(CACHE).then(cache => cache.put(event.request, response.clone()));
      return response;
    }).catch(() => caches.match(new URL('index.html', self.registration.scope).href));
  }));
});
