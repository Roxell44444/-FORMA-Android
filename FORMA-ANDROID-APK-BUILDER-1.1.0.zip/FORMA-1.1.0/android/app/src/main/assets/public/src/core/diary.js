const MEAL_TYPES = new Set(['breakfast', 'lunch', 'dinner', 'snack']);

function optionalNumber(value, min, max, label) {
  if (value === null || value === undefined || value === '') return null;
  const number = Number(value);
  if (!Number.isFinite(number) || number < min || number > max) {
    throw new RangeError(`${label}: introduce un valor entre ${min} y ${max}.`);
  }
  return number;
}

export function validateFoodEntry(input) {
  const name = String(input.name || '').trim();
  if (name.length < 2 || name.length > 80) throw new RangeError('El alimento o plato debe tener entre 2 y 80 caracteres.');
  if (!MEAL_TYPES.has(input.mealType)) throw new RangeError('Tipo de comida no válido.');
  if (!/^\d{4}-\d{2}-\d{2}$/.test(input.date || '')) throw new RangeError('Fecha no válida.');
  const calories = optionalNumber(input.calories, 0, 5000, 'Calorías');
  const protein = optionalNumber(input.protein, 0, 300, 'Proteína');
  const carbs = optionalNumber(input.carbs, 0, 500, 'Carbohidratos');
  const fat = optionalNumber(input.fat, 0, 300, 'Grasas');
  if ([calories, protein, carbs, fat].every(value => value === null)) throw new RangeError('Añade al menos calorías o un macronutriente.');
  return { name, mealType: input.mealType, date: input.date, calories, protein, carbs, fat };
}

export function calculateFoodTotals(entries = []) {
  const totals = { calories: 0, protein: 0, carbs: 0, fat: 0, items: entries.length };
  for (const entry of entries) {
    for (const key of ['calories', 'protein', 'carbs', 'fat']) {
      if (Number.isFinite(entry[key])) totals[key] += entry[key];
    }
  }
  for (const key of ['calories', 'protein', 'carbs', 'fat']) totals[key] = Number(totals[key].toFixed(1));
  return totals;
}

export function validateExerciseEntry(input) {
  const exercise = String(input.exercise || '').trim();
  if (exercise.length < 2 || exercise.length > 80) throw new RangeError('El ejercicio debe tener entre 2 y 80 caracteres.');
  if (!/^\d{4}-\d{2}-\d{2}$/.test(input.date || '')) throw new RangeError('Fecha no válida.');
  const sets = optionalNumber(input.sets, 1, 20, 'Series');
  const reps = optionalNumber(input.reps, 1, 100, 'Repeticiones');
  const loadKg = optionalNumber(input.loadKg, 0, 500, 'Carga');
  const rpe = optionalNumber(input.rpe, 1, 10, 'Esfuerzo percibido');
  if (sets === null || reps === null || loadKg === null) throw new RangeError('Indica series, repeticiones y carga (usa 0 kg para peso corporal).');
  return { exercise, date: input.date, sets, reps, loadKg, rpe, note: String(input.note || '').trim().slice(0, 140) };
}

export function dailyFoodEntries(entries = [], date) {
  return entries.filter(entry => entry.date === date);
}

export function dailyExerciseEntries(entries = [], date) {
  return entries.filter(entry => entry.date === date);
}


/** Simple movement journal for child profiles; it deliberately has no calories,
 * body-weight targets, exercise loads or effort scores. */
export function validateActivityEntry(input) {
  const activity = String(input.activity || '').trim();
  if (activity.length < 2 || activity.length > 80) throw new RangeError('La actividad debe tener entre 2 y 80 caracteres.');
  if (!/^\d{4}-\d{2}-\d{2}$/.test(input.date || '')) throw new RangeError('Fecha no válida.');
  const durationMin = optionalNumber(input.durationMin, 1, 600, 'Duración (minutos)');
  if (durationMin === null) throw new RangeError('Indica la duración de la actividad.');
  return { activity, date: input.date, durationMin, note: String(input.note || '').trim().slice(0, 140) };
}

export function dailyActivityEntries(entries = [], date) {
  return entries.filter(entry => entry.date === date);
}
