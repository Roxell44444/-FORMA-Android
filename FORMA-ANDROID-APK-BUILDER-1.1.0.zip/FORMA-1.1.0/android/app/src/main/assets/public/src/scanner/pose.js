/**
 * FORMA scanner: pose landmarks and capture quality gates.
 * MediaPipe Pose Landmarker detects pose only; it does NOT measure body fat,
 * skeletal muscle, circumference, or metric body dimensions.
 */
export const MEDIAPIPE_VERSION = '1.2.3';
export const POSE_MODEL_URL = 'https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_lite/float16/1/pose_landmarker_lite.task';
const WASM_URL = `https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@${MEDIAPIPE_VERSION}/wasm`;
const BUNDLE_URL = `https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@${MEDIAPIPE_VERSION}/vision_bundle.mjs`;

let landmarkerPromise = null;

/** Reject a model initialization that stalls indefinitely (for example, offline/CDN DNS failure). */
export function withTimeout(promise, timeoutMs = 45000) {
  if (!Number.isFinite(timeoutMs) || timeoutMs <= 0) throw new RangeError('El tiempo límite debe ser positivo.');
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error('La descarga o inicialización del modelo tardó demasiado. Comprueba la conexión e inténtalo de nuevo.')), timeoutMs);
    Promise.resolve(promise).then(
      value => { clearTimeout(timer); resolve(value); },
      error => { clearTimeout(timer); reject(error); }
    );
  });
}

export async function createPoseLandmarker() {
  if (!landmarkerPromise) {
    landmarkerPromise = withTimeout((async () => {
      const { FilesetResolver, PoseLandmarker } = await import(BUNDLE_URL);
      const vision = await FilesetResolver.forVisionTasks(WASM_URL);
      const options = {
        runningMode: 'IMAGE',
        numPoses: 1,
        minPoseDetectionConfidence: 0.55,
        minPosePresenceConfidence: 0.55,
        minTrackingConfidence: 0.5,
        outputSegmentationMasks: true
      };
      try {
        return await PoseLandmarker.createFromOptions(vision, {
          ...options,
          baseOptions: { modelAssetPath: POSE_MODEL_URL, delegate: 'GPU' }
        });
      } catch (gpuError) {
        // Some browsers/devices cannot initialize the GPU delegate. CPU is the safe fallback.
        try {
          return await PoseLandmarker.createFromOptions(vision, {
            ...options,
            baseOptions: { modelAssetPath: POSE_MODEL_URL, delegate: 'CPU' }
          });
        } catch (cpuError) {
          const error = new Error('No se pudo iniciar el detector de postura en este dispositivo.');
          error.cause = cpuError || gpuError;
          throw error;
        }
      }
    })(), 45000).catch(error => {
      landmarkerPromise = null; // Allow retry after a timeout, network, or initialization error.
      throw error;
    });
  }
  return landmarkerPromise;
}

export function resetPoseLandmarkerForTests() {
  landmarkerPromise = null;
}

const REQUIRED = [0, 11, 12, 13, 14, 15, 16, 23, 24, 25, 26, 27, 28];
const KEY = {
  nose: 0,
  leftShoulder: 11, rightShoulder: 12,
  leftElbow: 13, rightElbow: 14,
  leftWrist: 15, rightWrist: 16,
  leftHip: 23, rightHip: 24,
  leftKnee: 25, rightKnee: 26,
  leftAnkle: 27, rightAnkle: 28
};

const confidenceOf = point => {
  if (!point) return 0;
  const values = [point.visibility, point.presence].filter(Number.isFinite);
  return values.length ? Math.min(...values) : 1;
};
const midpoint = (a, b) => ({ x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 });
const distancePx = (a, b, width, height) => Math.hypot((a.x - b.x) * width, (a.y - b.y) * height);

/**
 * Deterministic quality checks used both by the UI and unit tests.
 * View orientation is advisory because a monocular 2D pose estimate cannot
 * guarantee a true 90-degree body rotation for every body shape/camera.
 */
export function evaluatePoseLandmarks(landmarks, imageWidth, imageHeight, view = 'front') {
  if (!['front', 'side', 'back', 'side2'].includes(view)) throw new RangeError('Vista de escaneo no reconocida.');
  if (!Array.isArray(landmarks) || landmarks.length < 29) {
    return { status: 'rejected', title: 'No se detectó el cuerpo completo', reasons: ['No se encontraron suficientes puntos anatómicos.'], warnings: [], score: 0, orientation: 'unknown' };
  }
  if (![imageWidth, imageHeight].every(v => Number.isFinite(v) && v > 0)) {
    throw new RangeError('Las dimensiones de la imagen no son válidas.');
  }
  // front/back share frontal geometry; side/side2 share profile geometry.

  const reasons = [];
  const warnings = [];
  const points = REQUIRED.map(index => landmarks[index]);
  const missing = REQUIRED.filter(index => !landmarks[index] || !Number.isFinite(landmarks[index].x) || !Number.isFinite(landmarks[index].y));
  if (missing.length) {
    return { status: 'rejected', title: 'No se detectó el cuerpo completo', reasons: ['Faltan puntos de cabeza, brazos, caderas o piernas. Repite la fotografía.'], warnings: [], score: 0, orientation: 'unknown' };
  }

  const lowConfidence = REQUIRED.filter(index => confidenceOf(landmarks[index]) < 0.45);
  const mediumConfidence = REQUIRED.filter(index => confidenceOf(landmarks[index]) < 0.6);
  if (lowConfidence.length >= 3) reasons.push('Hay demasiados puntos anatómicos ocultos o poco visibles. Mejora la luz y despeja el fondo.');
  else if (mediumConfidence.length) warnings.push('Algunos puntos se detectaron con confianza limitada. Comprueba que no haya ropa o sombras ocultándolos.');

  const minX = Math.min(...points.map(p => p.x));
  const maxX = Math.max(...points.map(p => p.x));
  const minY = Math.min(...points.map(p => p.y));
  const maxY = Math.max(...points.map(p => p.y));
  if (minX < 0.015 || maxX > 0.985 || minY < 0.015 || maxY > 0.985) {
    reasons.push('Parte del cuerpo está demasiado cerca del borde o fuera del encuadre. Aléjate un poco y deja espacio alrededor.');
  }

  const bodyHeightCoverage = Math.max(0, Math.min(1, maxY - minY));
  if (bodyHeightCoverage < 0.48) reasons.push('La persona ocupa muy poca altura de la imagen. Aleja la cámara lo necesario para incluir el cuerpo completo, sin superar la distancia recomendada por el modelo.');
  else if (bodyHeightCoverage < 0.62) warnings.push('El cuerpo ocupa poco espacio en la imagen. Acércate ligeramente sin cortar cabeza ni pies.');

  const leftShoulder = landmarks[KEY.leftShoulder], rightShoulder = landmarks[KEY.rightShoulder];
  const leftHip = landmarks[KEY.leftHip], rightHip = landmarks[KEY.rightHip];
  const shoulderMid = midpoint(leftShoulder, rightShoulder);
  const hipMid = midpoint(leftHip, rightHip);
  const torsoLength = distancePx(shoulderMid, hipMid, imageWidth, imageHeight);
  const shoulderSpan = distancePx(leftShoulder, rightShoulder, imageWidth, imageHeight);
  const hipSpan = distancePx(leftHip, rightHip, imageWidth, imageHeight);
  const shoulderRatio = torsoLength > 0 ? shoulderSpan / torsoLength : 0;
  const hipRatio = torsoLength > 0 ? hipSpan / torsoLength : 0;
  let orientation = 'uncertain';
  if (shoulderRatio >= 0.58 && hipRatio >= 0.25) orientation = 'front-likely';
  else if (shoulderRatio <= 0.48 && hipRatio <= 0.28) orientation = 'side-likely';

  if (['front', 'back'].includes(view) && orientation === 'side-likely') warnings.push('La imagen parece más lateral que frontal. Gira el torso hacia la cámara para la vista frontal.');
  if (['side', 'side2'].includes(view) && orientation === 'front-likely') warnings.push('La imagen parece más frontal que lateral. Gira aproximadamente 90° para la vista lateral.');
  if (orientation === 'uncertain') warnings.push('No podemos confirmar el ángulo de la vista con suficiente confianza. Revisa la posición indicada.');

  // Avoid false precision: this score is a capture-quality heuristic, not body-measurement confidence.
  let score = 100 - (lowConfidence.length * 5) - (mediumConfidence.length - lowConfidence.length) * 2;
  if (bodyHeightCoverage < 0.62) score -= 8;
  if (orientation === 'uncertain') score -= 8;
  if ((['front', 'back'].includes(view) && orientation === 'side-likely') || (['side', 'side2'].includes(view) && orientation === 'front-likely')) score -= 10;
  score = Math.max(0, Math.min(100, Math.round(score)));

  const status = reasons.length ? 'rejected' : warnings.length ? 'review' : 'ready';
  const title = status === 'ready' ? 'Captura apta para revisión de postura' : status === 'review' ? 'Captura detectada; revisa las indicaciones' : 'Repite esta captura';
  return {
    status, title, reasons, warnings, score, orientation,
    diagnostics: {
      visibleLandmarks: REQUIRED.length - lowConfidence.length,
      requiredLandmarks: REQUIRED.length,
      bodyHeightCoverage: Number(bodyHeightCoverage.toFixed(3)),
      shoulderToTorsoRatio: Number(shoulderRatio.toFixed(3)),
      hipToTorsoRatio: Number(hipRatio.toFixed(3))
    }
  };
}

/** Copy the per-pose confidence mask before MediaPipe releases its result. */
export function copyPersonSegmentationMask(mask, threshold = 0.5) {
  if (!mask || !Number.isInteger(mask.width) || !Number.isInteger(mask.height) || mask.width < 2 || mask.height < 2) return null;
  if (!Number.isFinite(threshold) || threshold < 0 || threshold > 1) throw new RangeError('El umbral de segmentación debe estar entre 0 y 1.');
  let source;
  let sourceScale = 1;
  try {
    if (typeof mask.getAsFloat32Array === 'function') source = mask.getAsFloat32Array();
  } catch { source = null; }
  if (!source && typeof mask.getAsUint8Array === 'function') {
    try {
      source = mask.getAsUint8Array();
      let max = 0; for (let i = 0; i < source.length; i++) if (source[i] > max) max = source[i];
      sourceScale = max > 1 ? 255 : 1;
    } catch { return null; }
  }
  if (!source || source.length !== mask.width * mask.height) return null;
  // MediaPipe Pose Landmarker returns a per-pixel person-confidence mask.
  const data = new Uint8Array(source.length);
  let foreground = 0;
  for (let i = 0; i < source.length; i++) {
    if (source[i] / sourceScale >= threshold) { data[i] = 1; foreground++; }
  }
  return { data, width: mask.width, height: mask.height, threshold, foregroundRatio: foreground / source.length, source: 'mediapipe-pose-person-mask' };
}

export function detectPoseInImage(landmarker, image, view = 'front') {
  if (!landmarker || typeof landmarker.detect !== 'function') throw new TypeError('El detector de postura no está inicializado.');
  if (!image || !image.naturalWidth || !image.naturalHeight) throw new TypeError('La imagen no está lista para analizar.');
  const result = landmarker.detect(image);
  try {
    const landmarks = result?.landmarks?.[0];
    const quality = evaluatePoseLandmarks(landmarks, image.naturalWidth, image.naturalHeight, view);
    const personMask = copyPersonSegmentationMask(result?.segmentationMasks?.[0]);
    const warnings = [...quality.warnings];
    if (!personMask) warnings.push('MediaPipe no devolvió una máscara corporal utilizable. Repite la captura o utiliza las medidas con cinta.');
    const status = quality.status === 'rejected' ? 'rejected' : warnings.length ? 'review' : 'ready';
    const title = status === 'ready' ? quality.title : status === 'review' ? 'Captura detectada; revisa las indicaciones' : quality.title;
    return { ...quality, status, title, warnings, landmarks: landmarks || null, personMask };
  } finally {
    // PoseLandmarkerResult owns segmentation resources; the plain arrays above are copied.
    result?.close?.();
  }
}

const CONNECTIONS = [
  [11,12],[11,13],[13,15],[12,14],[14,16],[11,23],[12,24],[23,24],
  [23,25],[25,27],[24,26],[26,28],[0,11],[0,12]
];

export function drawPoseOverlay(canvas, image, landmarks, personMask = null) {
  if (!canvas || !image || !Array.isArray(landmarks)) return;
  const width = image.naturalWidth, height = image.naturalHeight;
  if (!width || !height) return;
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d');
  if (!ctx) return;
  ctx.clearRect(0, 0, width, height);
  if (personMask?.data?.length === personMask.width * personMask.height) {
    const maskCanvas = document.createElement('canvas');
    maskCanvas.width = personMask.width; maskCanvas.height = personMask.height;
    const maskCtx = maskCanvas.getContext('2d');
    if (maskCtx) {
      const pixels = maskCtx.createImageData(personMask.width, personMask.height);
      for (let i = 0; i < personMask.data.length; i++) {
        const offset = i * 4;
        if (personMask.data[i]) { pixels.data[offset] = 181; pixels.data[offset + 1] = 242; pixels.data[offset + 2] = 109; pixels.data[offset + 3] = 62; }
      }
      maskCtx.putImageData(pixels, 0, 0);
      ctx.drawImage(maskCanvas, 0, 0, width, height);
    }
  }
  ctx.lineWidth = Math.max(2, width * 0.003);
  ctx.strokeStyle = '#b5f26d';
  ctx.fillStyle = '#f1ffd8';
  for (const [a, b] of CONNECTIONS) {
    const p = landmarks[a], q = landmarks[b];
    if (!p || !q || confidenceOf(p) < 0.35 || confidenceOf(q) < 0.35) continue;
    ctx.beginPath();
    ctx.moveTo(p.x * width, p.y * height);
    ctx.lineTo(q.x * width, q.y * height);
    ctx.stroke();
  }
  for (const index of REQUIRED) {
    const p = landmarks[index];
    if (!p || confidenceOf(p) < 0.35) continue;
    ctx.beginPath();
    ctx.arc(p.x * width, p.y * height, Math.max(3, width * 0.006), 0, Math.PI * 2);
    ctx.fill();
  }
}
