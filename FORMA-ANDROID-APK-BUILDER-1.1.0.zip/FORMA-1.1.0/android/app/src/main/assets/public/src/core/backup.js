import { validateFoodEntry, validateExerciseEntry, validateActivityEntry } from './diary.js';

const isObject = value => value !== null && typeof value === 'object' && !Array.isArray(value);
const isDate = value => typeof value === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(value) && Number.isFinite(Date.parse(`${value}T12:00:00Z`));
const finiteIn = (value, min, max) => Number.isFinite(value) && value >= min && value <= max;

function optionalMetric(value, min, max) {
  return value === null || value === undefined || value === '' ? null : finiteIn(Number(value), min, max) ? Number(value) : null;
}

function normalizeProfile(profile) {
  if (profile === null || profile === undefined) return null;
  if (!isObject(profile)) throw new TypeError('El perfil del respaldo no tiene un formato válido.');
  const age = Number(profile.age);
  const valid = finiteIn(age, 0, 130)
    && finiteIn(profile.height, 40, 230) && finiteIn(profile.weight, 2, 300)
    && ['male', 'female', 'range'].includes(profile.equation)
    && [1.2, 1.375, 1.55, 1.725, 1.9].includes(Number(profile.activity))
    && ['recomp', 'fatloss', 'muscle', 'maintain'].includes(profile.goal)
    && ['beginner', 'intermediate', 'advanced'].includes(profile.experience)
    && [2, 3, 4, 5].includes(Number(profile.sessions))
    && ['home', 'basic', 'gym'].includes(profile.equipment)
    && ['no', 'yes', 'unsure'].includes(profile.safety)
    && ['tape', 'other'].includes(profile.measureMethod)
    && (age >= 18 || profile.guardianConfirmed === true);
  if (!valid) throw new TypeError('El perfil del respaldo contiene valores incompatibles.');
  const isMinor = age < 18;
  const pediatricWaistAllowed = isMinor && age >= 8 && profile.measureMethod === 'tape';
  const waist = isMinor ? (pediatricWaistAllowed ? optionalMetric(profile.waist, 40, 150) : null) : optionalMetric(profile.waist, 40, 200);
  const neck = isMinor ? null : optionalMetric(profile.neck, 20, 80);
  const hip = isMinor ? null : optionalMetric(profile.hip, 50, 220);
  const extraRanges = { chest:[50,180], armLeft:[15,80], armRight:[15,80], forearmLeft:[12,55], forearmRight:[12,55], thighLeft:[25,100], thighRight:[25,100], calfLeft:[20,65], calfRight:[20,65] };
  const extraMeasures = Object.fromEntries(Object.entries(extraRanges).map(([key, range]) => [key, isMinor ? null : optionalMetric(profile[key], ...range)]));
  for (const [key, original, normalized] of [['waist', profile.waist, waist], ['neck', profile.neck, neck], ['hip', profile.hip, hip], ...Object.keys(extraRanges).map(key => [key, profile[key], extraMeasures[key]])]) {
    const pediatricMeasure = isMinor && key === 'waist' && pediatricWaistAllowed;
    if ((!isMinor || pediatricMeasure) && original !== null && original !== undefined && original !== '' && normalized === null) throw new TypeError(`La medida ${key} del respaldo no es válida.`);
  }
  return {
    age, height: profile.height, weight: profile.weight, equation: profile.equation,
    waist, neck, hip, ...extraMeasures, measureMethod: profile.measureMethod, activity: Number(profile.activity),
    goal: profile.goal, experience: profile.experience, sessions: Number(profile.sessions),
    equipment: profile.equipment, diet: String(profile.diet || '').slice(0, 120),
    safety: profile.safety, guardianConfirmed: isMinor ? true : false, createdAt: typeof profile.createdAt === 'string' ? profile.createdAt.slice(0, 40) : null
  };
}

function normalizeLogs(logs) {
  if (!Array.isArray(logs)) return [];
  return logs.filter(isObject).filter(item => isDate(item.date)).map(item => {
    const weight = optionalMetric(item.weight, 2, 300);
    const waist = optionalMetric(item.waist, 40, 200);
    return {
      date: item.date, weight, waist, note: String(item.note || '').slice(0, 120),
      createdAt: typeof item.createdAt === 'string' ? item.createdAt.slice(0, 50) : `${item.date}T12:00:00.000Z`
    };
  }).filter(item => item.weight !== null || item.waist !== null);
}



function normalizeScanValidations(entries) {
  if (!Array.isArray(entries)) return [];
  return entries.filter(isObject).flatMap(entry => {
    if (!Array.isArray(entry.measurements)) return [];
    const measurements = entry.measurements.flatMap(item => {
      if (!isObject(item) || !['chest', 'waist', 'hip'].includes(item.level)) return [];
      const estimatedCm = optionalMetric(item.estimatedCm, 20, 220);
      const measuredCm = optionalMetric(item.measuredCm, 20, 220);
      if (estimatedCm === null || measuredCm === null) return [];
      const signedErrorCm = Number((estimatedCm - measuredCm).toFixed(1));
      const absoluteErrorCm = Number(Math.abs(signedErrorCm).toFixed(1));
      return [{ level: item.level, estimatedCm, measuredCm, signedErrorCm, absoluteErrorCm, errorPercent: Number((absoluteErrorCm / measuredCm * 100).toFixed(1)) }];
    });
    if (!measurements.length) return [];
    const meanAbsoluteErrorCm = Number((measurements.reduce((sum, item) => sum + item.absoluteErrorCm, 0) / measurements.length).toFixed(1));
    const createdAt = typeof entry.createdAt === 'string' && Number.isFinite(Date.parse(entry.createdAt)) ? entry.createdAt.slice(0, 50) : new Date(0).toISOString();
    return [{ id: String(entry.id || '').slice(0, 100), createdAt, measurements, meanAbsoluteErrorCm, sampleCount: measurements.length, method: 'Comparación individual exploratoria importada' }];
  }).slice(-500);
}

export function normalizeBackup(backup) {
  if (!isObject(backup) || !['profile', 'logs', 'completedWorkouts', 'foodEntries', 'exerciseEntries'].some(key => key in backup)) {
    throw new TypeError('El archivo no parece un respaldo válido de FORMA.');
  }
  const foodEntries = Array.isArray(backup.foodEntries) ? backup.foodEntries.flatMap(item => {
    try { return [{ ...validateFoodEntry(item), id: String(item.id || '').slice(0, 100), createdAt: String(item.createdAt || '').slice(0, 50) }]; }
    catch { return []; }
  }).slice(-1000) : [];
  const exerciseEntries = Array.isArray(backup.exerciseEntries) ? backup.exerciseEntries.flatMap(item => {
    try { return [{ ...validateExerciseEntry(item), id: String(item.id || '').slice(0, 100), createdAt: String(item.createdAt || '').slice(0, 50) }]; }
    catch { return []; }
  }).slice(-1000) : [];
  const activityEntries = Array.isArray(backup.activityEntries) ? backup.activityEntries.flatMap(item => {
    try { return [{ ...validateActivityEntry(item), id: String(item.id || '').slice(0, 100), createdAt: String(item.createdAt || '').slice(0, 50) }]; }
    catch { return []; }
  }).slice(-1000) : [];
  const normalizedProfile = normalizeProfile(backup.profile ?? null);
  const isMinorProfile = normalizedProfile && normalizedProfile.age < 18;
  const rawScan = !isMinorProfile && isObject(backup.scanResult) && isObject(backup.scanResult.measurements) ? backup.scanResult : null;
  const scanResult = rawScan ? (() => {
    const levels = ['chest','waist','hip'];
    const measurements = {};
    for (const level of levels) {
      const item = rawScan.measurements[level];
      if (!isObject(item) || !finiteIn(Number(item.frontWidthCm),1,150) || !finiteIn(Number(item.sideDepthCm),1,100) || !finiteIn(Number(item.circumferenceCm),10,250)) return null;
      measurements[level] = { frontWidthCm:Number(item.frontWidthCm), sideDepthCm:Number(item.sideDepthCm), circumferenceCm:Number(item.circumferenceCm) };
    }
    return { measurements, method:'Escaneo 2D experimental importado', confidence:'experimental-low', warnings:Array.isArray(rawScan.warnings) ? rawScan.warnings.map(x=>String(x).slice(0,240)).slice(0,8) : [], createdAt:typeof rawScan.createdAt==='string'?rawScan.createdAt.slice(0,50):new Date(0).toISOString() };
  })() : null;
  return {
    profile: normalizedProfile,
    scanResult,
    logs: normalizeLogs(backup.logs).slice(-1000),
    completedWorkouts: Array.isArray(backup.completedWorkouts) ? backup.completedWorkouts.filter(value => typeof value === 'string').map(value => value.slice(0, 120)).slice(-500) : [],
    foodEntries, exerciseEntries, activityEntries,
    scanValidations: isMinorProfile ? [] : normalizeScanValidations(backup.scanValidations)
  };
}
