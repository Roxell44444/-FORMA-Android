const ACTIVITY_FACTORS = new Set([1.2, 1.375, 1.55, 1.725, 1.9]);

export function calculateBMI(weightKg, heightCm) {
  if (!Number.isFinite(weightKg) || !Number.isFinite(heightCm) || weightKg <= 0 || heightCm <= 0) {
    throw new RangeError('El peso y la altura deben ser números positivos.');
  }
  const heightM = heightCm / 100;
  return weightKg / (heightM * heightM);
}

export function calculateMifflinRMR({ weightKg, heightCm, age, equation = 'range' }) {
  if (![weightKg, heightCm, age].every(Number.isFinite) || weightKg <= 0 || heightCm <= 0 || (age < 19 || age > 78)) {
    throw new RangeError('Se requieren peso, altura y edad adulta válidos.');
  }
  const base = 10 * weightKg + 6.25 * heightCm - 5 * age;
  const female = base - 161;
  const male = base + 5;
  if (equation === 'female') return { low: female, high: female, method: 'Mifflin–St Jeor · ecuación femenina' };
  if (equation === 'male') return { low: male, high: male, method: 'Mifflin–St Jeor · ecuación masculina' };
  if (equation === 'range') return { low: Math.min(female, male), high: Math.max(female, male), method: 'Rango de las dos ecuaciones Mifflin–St Jeor' };
  throw new RangeError('Referencia metabólica no reconocida.');
}

export function calculateEnergyEstimate(profile) {
  const factor = Number(profile.activity);
  if (!ACTIVITY_FACTORS.has(factor)) throw new RangeError('Factor de actividad no válido.');
  const rmr = calculateMifflinRMR(profile);
  return {
    rmr,
    maintenance: { low: rmr.low * factor, high: rmr.high * factor },
    note: 'Estimación inicial; calibrar con tendencias de 2–4 semanas, actividad real y bienestar.'
  };
}

function log10(value) { return Math.log(value) / Math.LN10; }

// U.S. Navy circumference equations. Values are converted from cm to inches.
// This is a population estimate, not a clinical measurement.
export function estimateBodyFatNavy({ equation, heightCm, waistCm, neckCm, hipCm }) {
  const values = [heightCm, waistCm, neckCm];
  if (!values.every(Number.isFinite) || values.some(v => v <= 0)) return null;
  if (heightCm < 130 || heightCm > 230 || waistCm < 40 || waistCm > 200 || neckCm < 20 || neckCm > 80) return null;
  const inch = value => value / 2.54;
  const height = inch(heightCm);
  const waist = inch(waistCm);
  const neck = inch(neckCm);
  let estimate;
  if (equation === 'male') {
    if (waist <= neck) return null;
    estimate = 86.010 * log10(waist - neck) - 70.041 * log10(height) + 36.76;
  } else if (equation === 'female') {
    if (!Number.isFinite(hipCm) || hipCm < 50 || hipCm > 220) return null;
    const hip = inch(hipCm);
    if (waist + hip <= neck) return null;
    estimate = 163.205 * log10(waist + hip - neck) - 97.684 * log10(height) - 78.387;
  } else {
    return null;
  }
  if (!Number.isFinite(estimate) || estimate < 2 || estimate > 60) return null;
  return estimate;
}



/**
 * Relative Fat Mass (RFM). Requires a sex-reference and a waist measured with tape.
 * Equation: 64 - 20 * height/waist + 12 * sex (male=0, female=1).
 */
export function estimateBodyFatRFM({ equation, heightCm, waistCm }) {
  if (!['male', 'female'].includes(equation) || ![heightCm, waistCm].every(Number.isFinite)) return null;
  if (heightCm < 130 || heightCm > 230 || waistCm < 40 || waistCm > 200) return null;
  const sexCode = equation === 'female' ? 1 : 0;
  const estimate = 64 - 20 * (heightCm / waistCm) + 12 * sexCode;
  return Number.isFinite(estimate) && estimate >= 2 && estimate <= 60 ? estimate : null;
}

/**
 * CUN-BAE body-fat estimate from BMI, age and sex-reference.
 * Developed/validated in adult cohorts; it is a population equation, not an individual measurement.
 */
export function estimateBodyFatCUNBAE({ equation, bmi, age }) {
  if (!['male', 'female'].includes(equation) || ![bmi, age].every(Number.isFinite)) return null;
  if (bmi < 12 || bmi > 60 || age < 18 || age > 80) return null;
  const sex = equation === 'female' ? 1 : 0;
  const bmi2 = bmi * bmi;
  const estimate = -44.988 + 0.503 * age + 10.689 * sex + 3.172 * bmi - 0.026 * bmi2
    + 0.181 * bmi * sex - 0.02 * bmi * age - 0.005 * bmi2 * sex + 0.00021 * bmi2 * age;
  return Number.isFinite(estimate) && estimate >= 2 && estimate <= 60 ? estimate : null;
}

function median(values) {
  const sorted = [...values].sort((a, b) => a - b);
  const middle = Math.floor(sorted.length / 2);
  return sorted.length % 2 ? sorted[middle] : (sorted[middle - 1] + sorted[middle]) / 2;
}


/** Pediatric Relative Fat Mass (RFMp/RFM), derived from DXA-referenced NHANES data.
 * Only supported for ages 8–17 in this app. Requires a tape-measured waist and
 * the study's male/female equation code. It is not a diagnostic threshold. */
export function estimatePediatricBodyFatRFM({ age, equation, heightCm, waistCm, measureMethod = 'other' }) {
  if (measureMethod !== 'tape' || !Number.isFinite(age) || age < 8 || age >= 18) return null;
  if (!['male', 'female'].includes(equation) || ![heightCm, waistCm].every(Number.isFinite)) return null;
  if (heightCm < 100 || heightCm > 220 || waistCm < 40 || waistCm > 150) return null;
  const sex = equation === 'female' ? 1 : 0;
  const estimate = age < 15
    ? 74 - (22 * (heightCm / waistCm)) + (5 * sex)
    : 64 - (20 * (heightCm / waistCm)) + (12 * sex);
  if (!Number.isFinite(estimate) || estimate < 2 || estimate > 60) return null;
  return {
    percent: Number(estimate.toFixed(1)),
    method: age < 15 ? 'RFMp pediátrica · 8–14 años' : 'RFM · adolescentes 15–19 años',
    studyRmsePercentagePoints: age < 15 ? 3.83 : (equation === 'male' ? 3.35 : 3.45),
    note: age < 15
      ? 'Ecuación transversal contrastada con DXA en NHANES; RMSE de grupo publicado 3,83 puntos. No es un margen de error individual.'
      : 'RFM contrastada con DXA en adolescentes 15–19; el rendimiento varió por sexo y fue menos preciso que IMC en chicas. No es un margen de error individual.'
  };
}

/**
 * Multi-equation body-fat estimate. Tape-dependent equations are deliberately
 * excluded unless the user confirms that circumferences were taken with a tape.
 * The min/max is the spread between formula outputs, NOT a confidence interval.
 */
/**
 * Photo-assisted body-fat estimate for the scan report.
 * CUN-BAE uses declared profile data; RFM is applied to the scanner's
 * ellipse-derived waist proxy. Because RFM was not validated on this image
 * proxy, the combined result is explicitly exploratory and is NOT a validated
 * photo-AI model or a DXA-equivalent measurement.
 */
export function estimatePhotoAssistedComposition({ profile, measurements, captureQuality = null }) {
  if (!profile || !measurements?.waist) return null;
  if (Number.isFinite(captureQuality?.scaleSpreadPct) && captureQuality.scaleSpreadPct > 25) return null;
  const { age, weight, height, equation } = profile;
  const waistPhotoCm = Number(measurements.waist.circumferenceCm);
  if (![age, weight, height, waistPhotoCm].every(Number.isFinite)) return null;
  if (age < 18 || age > 80 || weight <= 0 || height < 130 || height > 230 || waistPhotoCm < 40 || waistPhotoCm > 200) return null;

  const bmi = calculateBMI(weight, height);
  const references = ['male', 'female'].includes(equation) ? [equation]
    : equation === 'range' ? ['male', 'female'] : [];
  if (!references.length) return null;

  const byReference = references.map(reference => {
    const cunbae = estimateBodyFatCUNBAE({ equation: reference, bmi, age });
    const rfmPhoto = estimateBodyFatRFM({ equation: reference, heightCm: height, waistCm: waistPhotoCm });
    const methods = [];
    if (cunbae !== null) methods.push({ name: 'CUN-BAE · perfil', value: cunbae, basis: 'Peso, altura, edad y referencia sexual' });
    if (rfmPhoto !== null) methods.push({ name: 'RFM · cintura del escáner', value: rfmPhoto, basis: 'Altura y perímetro elíptico visual de cintura; aplicación experimental' });
    if (!methods.length) return null;
    const values = methods.map(item => item.value);
    const center = median(values);
    return {
      reference,
      percent: center,
      low: Math.min(...values),
      high: Math.max(...values),
      methods: methods.map(item => ({ ...item, value: Number(item.value.toFixed(1)) }))
    };
  }).filter(Boolean);
  if (!byReference.length) return null;

  const low = Math.min(...byReference.map(item => item.low));
  const high = Math.max(...byReference.map(item => item.high));
  const selected = byReference.length === 1 ? byReference[0] : null;
  const percent = selected ? selected.percent : null;
  const fatMassLowKg = weight * low / 100;
  const fatMassHighKg = weight * high / 100;
  const fatFreeMassLowKg = weight - fatMassHighKg;
  const fatFreeMassHighKg = weight - fatMassLowKg;
  const heightM = height / 100;
  const fatMassIndexLow = fatMassLowKg / (heightM * heightM);
  const fatMassIndexHigh = fatMassHighKg / (heightM * heightM);
  const fatFreeMassIndexLow = fatFreeMassLowKg / (heightM * heightM);
  const fatFreeMassIndexHigh = fatFreeMassHighKg / (heightM * heightM);
  const waistHeightRatio = waistPhotoCm / height;
  const hipPhotoCm = Number(measurements.hip?.circumferenceCm);
  const waistHipRatio = Number.isFinite(hipPhotoCm) && hipPhotoCm > 0 ? waistPhotoCm / hipPhotoCm : null;
  const methods = byReference.flatMap(item => item.methods.map(method => ({ ...method, reference: item.reference })));

  return {
    source: 'photo-assisted-experimental',
    bodyFatPercent: percent === null ? null : Number(percent.toFixed(1)),
    bodyFatLow: Number(low.toFixed(1)),
    bodyFatHigh: Number(high.toFixed(1)),
    fatMassKg: percent === null ? null : Number((weight * percent / 100).toFixed(1)),
    fatMassLowKg: Number(fatMassLowKg.toFixed(1)),
    fatMassHighKg: Number(fatMassHighKg.toFixed(1)),
    fatFreeMassKg: percent === null ? null : Number((weight * (1 - percent / 100)).toFixed(1)),
    fatFreeMassLowKg: Number(fatFreeMassLowKg.toFixed(1)),
    fatFreeMassHighKg: Number(fatFreeMassHighKg.toFixed(1)),
    fatMassIndex: percent === null ? null : Number(((weight * percent / 100) / (heightM * heightM)).toFixed(1)),
    fatMassIndexLow: Number(fatMassIndexLow.toFixed(1)),
    fatMassIndexHigh: Number(fatMassIndexHigh.toFixed(1)),
    fatFreeMassIndex: percent === null ? null : Number(((weight * (1 - percent / 100)) / (heightM * heightM)).toFixed(1)),
    fatFreeMassIndexLow: Number(fatFreeMassIndexLow.toFixed(1)),
    fatFreeMassIndexHigh: Number(fatFreeMassIndexHigh.toFixed(1)),
    bmi: Number(bmi.toFixed(1)),
    waistPhotoCm: Number(waistPhotoCm.toFixed(1)),
    waistHeightRatio: Number(waistHeightRatio.toFixed(3)),
    waistHipRatio: waistHipRatio === null ? null : Number(waistHipRatio.toFixed(3)),
    methods,
    references: byReference.map(item => ({ reference: item.reference, percent: Number(item.percent.toFixed(1)), low: Number(item.low.toFixed(1)), high: Number(item.high.toFixed(1)) })),
    methodSpreadIsConfidenceInterval: false,
    note: 'Estimación exploratoria: combina CUN-BAE del perfil con RFM aplicado a una cintura derivada de una máscara fotográfica. La ecuación RFM no fue validada con este perímetro visual. La masa libre de grasa incluye músculo, agua, huesos y órganos; no equivale a masa muscular.'
  };
}

export function estimateBodyFatHybrid({ equation, age, weightKg, heightCm, waistCm, neckCm, hipCm, measureMethod = 'other' }) {
  if (![age, weightKg, heightCm].every(Number.isFinite) || weightKg <= 0 || heightCm <= 0) return null;
  // CUN-BAE, RFM and Navy references in this product are adult equations.
  if (age < 18 || age > 80 || !['male', 'female'].includes(equation)) return null;
  const bmi = calculateBMI(weightKg, heightCm);
  const methods = [];
  const cun = estimateBodyFatCUNBAE({ equation, bmi, age });
  if (cun !== null) methods.push({ name: 'CUN-BAE', value: cun, basis: 'IMC + edad + referencia sexual' });
  if (measureMethod === 'tape') {
    const rfm = estimateBodyFatRFM({ equation, heightCm, waistCm });
    if (rfm !== null) methods.push({ name: 'RFM', value: rfm, basis: 'cintura + altura + referencia sexual' });
    const navy = estimateBodyFatNavy({ equation, heightCm, waistCm, neckCm, hipCm });
    if (navy !== null) methods.push({ name: 'U.S. Navy', value: navy, basis: 'perímetros compatibles + altura' });
  }
  if (!methods.length) return null;
  const values = methods.map(item => item.value);
  return {
    percent: Number(median(values).toFixed(1)),
    low: Number(Math.min(...values).toFixed(1)),
    high: Number(Math.max(...values).toFixed(1)),
    methods: methods.map(item => ({ ...item, value: Number(item.value.toFixed(1)) })),
    count: methods.length,
    spreadIsConfidenceInterval: false,
    confidenceLabel: methods.length >= 3 ? 'Tres ecuaciones disponibles; su acuerdo no demuestra exactitud individual' : methods.length === 2 ? 'Dos ecuaciones disponibles; contraste exploratorio' : 'Una ecuación poblacional; incertidumbre individual alta',
    disagreementPercentagePoints: Number((Math.max(...values) - Math.min(...values)).toFixed(1)),
    note: 'La mediana combina ecuaciones poblacionales adultas. La dispersión entre ellas no es un intervalo de confianza ni una validación contra DXA.'
  };
}

/**
 * Kawakami et al. DXA-derived appendicular skeletal muscle mass equation.
 * Validated in adults aged 40–87 in the WASEDA-derived population; only calculate with tape waist and calf values.
 * ASM is appendicular skeletal muscle, not total-body skeletal muscle.
 */
export function estimateAppendicularMuscle({ equation, age, weightKg, heightCm, waistCm, calfLeftCm, calfRightCm, measureMethod = 'other' }) {
  if (measureMethod !== 'tape' || !['male', 'female'].includes(equation)) return null;
  if (![age, weightKg, heightCm, waistCm].every(Number.isFinite) || age < 40 || age > 87 || weightKg <= 0 || heightCm < 130 || heightCm > 230 || waistCm < 40 || waistCm > 200) return null;
  const calves = [calfLeftCm, calfRightCm].filter(value => Number.isFinite(value) && value >= 20 && value <= 65);
  if (!calves.length) return null;
  const calfCm = calves.reduce((sum, value) => sum + value, 0) / calves.length;
  const sex = equation === 'male' ? 1 : 0;
  const asmKg = 2.955 * sex + 0.255 * weightKg - 0.130 * waistCm + 0.308 * calfCm + 0.081 * heightCm - 11.897;
  if (!Number.isFinite(asmKg) || asmKg <= 0 || asmKg > weightKg * 0.7) return null;
  const heightM = heightCm / 100;
  return {
    kg: Number(asmKg.toFixed(1)),
    indexKgM2: Number((asmKg / (heightM * heightM)).toFixed(2)),
    calfUsedCm: Number(calfCm.toFixed(1)),
    calfSidesUsed: calves.length,
    standardErrorKg: 1.2,
    method: 'Kawakami et al. · ecuación antropométrica contrastada con DXA',
    populationNote: 'Estudiada en 1.262 adultos de 40 años o más; no debe usarse para diagnosticar sarcopenia ni asumirse válida para todas las poblaciones.'
  };
}

export function calculateMacroGuide({ weightKg, goal = 'recomp' }) {
  if (!Number.isFinite(weightKg) || weightKg <= 0) throw new RangeError('Peso no válido.');
  const proteinPerKg = goal === 'muscle' || goal === 'fatloss' ? 1.6 : 1.4;
  return {
    proteinGrams: Math.round(weightKg * proteinPerKg),
    proteinRange: [Math.round(weightKg * 1.2), Math.round(weightKg * 2.0)],
    basis: `${proteinPerKg.toFixed(1)} g/kg como referencia general provisional; ajustar individualmente.`
  };
}


/**
 * Derives fat mass and fat-free mass from a circumference-based body-fat estimate.
 * Fat-free mass is NOT skeletal muscle mass. No photo-derived muscle estimate is made.
 */
export function calculateCompositionEstimate({ weightKg, bodyFatPercent, heightCm }) {
  if (![weightKg, bodyFatPercent, heightCm].every(Number.isFinite) || weightKg <= 0 || heightCm <= 0 || bodyFatPercent < 2 || bodyFatPercent > 60) {
    throw new RangeError('Datos de composición no válidos.');
  }
  const fatMassKg = weightKg * bodyFatPercent / 100;
  const fatFreeMassKg = weightKg - fatMassKg;
  const heightM = heightCm / 100;
  return {
    bodyFatPercent,
    fatMassKg: Number(fatMassKg.toFixed(1)),
    fatFreeMassKg: Number(fatFreeMassKg.toFixed(1)),
    ffmi: Number((fatFreeMassKg / (heightM * heightM)).toFixed(1)),
    label: 'Derivado de estimación por perímetros; no equivale a masa muscular esquelética ni a DXA.'
  };
}

export function classifyBMI(bmi) {
  if (!Number.isFinite(bmi)) return 'Sin datos';
  if (bmi < 18.5) return 'Por debajo del rango de referencia';
  if (bmi < 25) return 'Rango de referencia';
  if (bmi < 30) return 'Por encima del rango de referencia';
  return 'Rango alto';
}

/** Practical macro split for an estimated energy target; not a clinical prescription. */
export function calculateMacroTargets({ weightKg, calories, goal = 'recomp' }) {
  if (![weightKg, calories].every(Number.isFinite) || weightKg <= 0 || calories < 800 || calories > 10000) throw new RangeError('Peso o energía no válidos para calcular macronutrientes.');
  const proteinFactor = goal === 'fatloss' || goal === 'muscle' ? 1.6 : 1.4;
  const proteinGrams = Math.round(weightKg * proteinFactor);
  const fatGrams = Math.round(weightKg * 0.8);
  const carbohydrateGrams = Math.max(0, Math.round((calories - proteinGrams * 4 - fatGrams * 9) / 4));
  return { calories: Math.round(calories), proteinGrams, fatGrams, carbohydrateGrams, basis: 'Distribución orientativa: proteína por kg, grasa aproximada de 0,8 g/kg y carbohidratos como energía restante.' };
}
