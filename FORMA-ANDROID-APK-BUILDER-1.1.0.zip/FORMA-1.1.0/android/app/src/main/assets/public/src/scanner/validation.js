const VALID_LEVELS = ['chest', 'waist', 'hip'];

function validCircumference(value) {
  return Number.isFinite(value) && value >= 20 && value <= 220;
}

/** Compare one scan's geometric proxy with tape measurements entered by the user. */
export function compareScanToTape(estimatedMeasurements, tapeMeasurements) {
  if (!estimatedMeasurements || typeof estimatedMeasurements !== 'object') throw new TypeError('No hay resultados de escaneo para comparar.');
  if (!tapeMeasurements || typeof tapeMeasurements !== 'object') throw new TypeError('Introduce al menos una medida con cinta métrica.');
  const measurements = [];
  for (const level of VALID_LEVELS) {
    const raw = tapeMeasurements[level];
    if (raw === null || raw === undefined || raw === '') continue;
    const measuredCm = Number(raw);
    const estimatedCm = Number(estimatedMeasurements[level]?.circumferenceCm);
    if (!validCircumference(measuredCm)) throw new RangeError(`La medida de ${level} debe estar entre 20 y 220 cm.`);
    if (!validCircumference(estimatedCm)) throw new TypeError(`El escáner no contiene un valor válido para ${level}.`);
    const signedErrorCm = estimatedCm - measuredCm;
    const absoluteErrorCm = Math.abs(signedErrorCm);
    measurements.push({
      level,
      estimatedCm: Number(estimatedCm.toFixed(1)),
      measuredCm: Number(measuredCm.toFixed(1)),
      signedErrorCm: Number(signedErrorCm.toFixed(1)),
      absoluteErrorCm: Number(absoluteErrorCm.toFixed(1)),
      errorPercent: Number((absoluteErrorCm / measuredCm * 100).toFixed(1))
    });
  }
  if (!measurements.length) throw new TypeError('Introduce al menos una medida con cinta métrica.');
  const meanAbsoluteErrorCm = measurements.reduce((sum, item) => sum + item.absoluteErrorCm, 0) / measurements.length;
  return {
    method: 'Comparación individual exploratoria contra cinta métrica; no valida el modelo de forma general',
    measurements,
    meanAbsoluteErrorCm: Number(meanAbsoluteErrorCm.toFixed(1)),
    sampleCount: measurements.length
  };
}
