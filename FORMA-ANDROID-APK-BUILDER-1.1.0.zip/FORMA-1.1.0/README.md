# FORMA 1.1.0 — escáner fotográfico con composición exploratoria

FORMA es una PWA gratuita y local para seguimiento de bienestar, estimaciones antropométricas orientativas, entrenamiento de adultos, nutrición general y escáner experimental de silueta. No requiere cuenta, API key, pago por escaneo ni backend. Se puede usar con perfiles de 0 a 130 años, pero las funciones cambian por edad para no extrapolar fórmulas adultas a menores.

## Funciones principales

- Perfil y registro local con edad 0–130, altura/longitud y peso.
- Modo menor con confirmación de padre/madre/tutor, bitácora simple de movimiento, sin conteo de calorías, macros, objetivos estéticos, pérdida de peso ni fórmulas adultas.
- RFMp/RFM para estimación exploratoria de grasa en 8–17 años, solo con cintura medida con cinta, altura y referencia sexual compatible.
- Adultos 18–80: estimación de grasa por mediana de CUN-BAE; RFM y U.S. Navy se añaden cuando hay perímetros compatibles tomados con cinta.
- ASM (masa muscular esquelética apendicular) solo entre 40–87 años y con cintura + pantorrilla medidas con cinta. No es masa muscular total.
- Escáner local MediaPipe de hasta cuatro vistas. En adultos 18–80, combina CUN-BAE del perfil con RFM aplicado a la cintura proxy calculada desde frontal + perfil para mostrar una composición fotográfica exploratoria: porcentaje de grasa, masa grasa, masa libre de grasa, FMI, FFMI y relaciones de perímetros. La adaptación de RFM a un perímetro fotográfico no ha sido validada; no es un modelo entrenado contra DXA y no estima músculo directamente.
- Plan de entrenamiento adulto, guía nutricional orientativa, diario de comidas/ejercicios, seguimiento, respuestas educativas locales, exportación/importación y borrado.

## Límites esenciales

- Perfil disponible no significa composición corporal calculable para todas las edades. No hay una ecuación de grasa/músculo científicamente respaldada para todas las edades.
- Para 0–7 años, FORMA guarda datos bajo supervisión, pero no calcula composición corporal. Para 8–17 años, RFMp/RFM requiere cinta métrica y tutor; no calcula músculo.
- FORMA 1.1.0 todavía no calcula percentiles ni puntuaciones z OMS/CDC. Los perfiles infantiles deben interpretarse con curvas oficiales y profesional sanitario.
- Las ecuaciones adultas son aproximaciones poblacionales; no sustituyen DXA. La dispersión entre fórmulas no es intervalo de confianza.
- El escáner visual y la composición fotográfica son experimentales: el perímetro de máscara 2D se usa como proxy dentro de RFM, sin validación propia frente a DXA/cinta. No identifica tejido corporal ni estima músculo desde imágenes.
- El coach es un motor local de respuestas guiadas, no un LLM generativo.
- Los datos se guardan en `localStorage` sin cifrado. No es una versión lista para producción con datos sensibles hasta añadir cifrado, consentimiento y revisión de privacidad.

## Ejecutar localmente

Requisitos: Node.js 18+ y Python 3.

```bash
npm run check
npm test
npm run build
npm run serve
```

Abre `http://localhost:4173`. Para PWA/cámara en Android, publicar en un hosting estático gratuito con HTTPS (por ejemplo, GitHub Pages, Cloudflare Pages o Netlify free tier; la disponibilidad y los límites pueden cambiar). El escáner descarga MediaPipe y el modelo en la primera ejecución, por lo que necesita conexión inicial; la inferencia de las fotos se realiza en el dispositivo.

## Validar el reanálisis del estudio

Al adjuntar/descomprimir el conjunto ICPSR 101343, ejecuta:

```bash
python3 scripts/validate_icpsr_cunbae.py /ruta/ICPSR_101343-V1.1/SixPreds.csv
```

Los resultados de la reanálisis quedan en `research/ICPSR_101343_CUNBAE_REANALYSIS.txt`. Este análisis compara CUN-BAE recalculado con DXA y con predicciones fotográficas ya existentes del estudio. No valida las fotos ni el escáner propio de FORMA.

## Archivos importantes

- `src/core/metrics.js`: ecuaciones de grasa y ASM.
- `src/core/age.js`: puertas por etapa de edad.
- `src/core/diary.js`: registros de comidas, ejercicio y actividad simple.
- `src/scanner/`: MediaPipe Pose, validación de capturas, consistencia de escala y geometría experimental que alimenta la estimación fotográfica.
- `docs/BODY_COMPOSITION_RESEARCH_DECISION.md`: ecuaciones, rangos, evidencia y límites.
- `docs/ANDROID_SCANNER_FIELD_TEST.md`: protocolo para prueba física en teléfonos.
- `QA_REPORT_1.1.0.md`: resultados de esta versión.
