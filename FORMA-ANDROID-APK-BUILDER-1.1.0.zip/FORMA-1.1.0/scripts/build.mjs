import { cp, mkdir, rm } from 'node:fs/promises';
import { resolve } from 'node:path';

const root = process.cwd();
const output = resolve(root, 'dist');
const assets = ['index.html', 'manifest.webmanifest', 'service-worker.js', 'src', 'public'];

await rm(output, { recursive: true, force: true });
await mkdir(output, { recursive: true });
for (const asset of assets) {
  await cp(resolve(root, asset), resolve(output, asset), { recursive: true });
}
process.stdout.write(`FORMA estática compilada en ${output} (sin backend ni secretos).\n`);
