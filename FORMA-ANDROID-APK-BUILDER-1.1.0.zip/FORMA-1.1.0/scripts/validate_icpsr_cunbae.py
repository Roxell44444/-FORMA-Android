#!/usr/bin/env python3
"""Reproduce an adult-only CUN-BAE comparison for ICPSR 101343 SixPreds.csv.

Usage:
  python3 scripts/validate_icpsr_cunbae.py /path/to/ICPSR_101343-V1.1/SixPreds.csv

This is a secondary re-analysis of de-identified predictions and DXA values.
It is not a prospective validation of FORMA or a substitute for the article's CV.
"""
from __future__ import annotations
import csv
import math
import statistics
import sys
from pathlib import Path


def number(row: dict[str, str], key: str) -> float:
    return float(row[key])


def cun_bae(bmi: float, age: float, is_female: bool) -> float:
    sex = 1.0 if is_female else 0.0
    bmi2 = bmi * bmi
    return (-44.988 + 0.503 * age + 10.689 * sex + 3.172 * bmi
            - 0.026 * bmi2 + 0.181 * bmi * sex - 0.02 * bmi * age
            - 0.005 * bmi2 * sex + 0.00021 * bmi2 * age)


def summarize(label: str, predicted: list[float], reference: list[float]) -> dict[str, float | str]:
    errors = [p - r for p, r in zip(predicted, reference)]
    mae = statistics.mean(abs(x) for x in errors)
    rmse = math.sqrt(statistics.mean(x * x for x in errors))
    bias = statistics.mean(errors)
    sd = statistics.stdev(errors) if len(errors) > 1 else 0.0
    return {
        "model": label, "n": len(errors), "MAE_pp": mae, "RMSE_pp": rmse,
        "bias_pp": bias, "LoA_low_pp": bias - 1.96 * sd, "LoA_high_pp": bias + 1.96 * sd,
    }


def correlation(x: list[float], y: list[float]) -> float:
    mx, my = statistics.mean(x), statistics.mean(y)
    sx, sy = statistics.stdev(x), statistics.stdev(y)
    return sum((a - mx) * (b - my) for a, b in zip(x, y)) / ((len(x) - 1) * sx * sy)


def main() -> int:
    if len(sys.argv) != 2:
        print(__doc__)
        return 2
    path = Path(sys.argv[1])
    with path.open(newline="", encoding="utf-8-sig") as handle:
        rows = list(csv.DictReader(handle))
    required = {"IDs", "SEX", "Age", "BMI", "DXA", "B1VS", "B2VS"}
    if not rows or not required.issubset(rows[0]):
        raise SystemExit(f"CSV no compatible. Columnas requeridas: {sorted(required)}")

    # ICPSR replication R script splits the study cohort at ID 4000:
    # IDs < 4000 = children; IDs >= 4000 = adults. Its Bland-Altman code
    # identifies SEX==1 as male, so SEX==2 is treated as female here.
    adult = [r for r in rows if number(r, "IDs") >= 4000]
    age_min, age_max = min(number(r, "Age") for r in adult), max(number(r, "Age") for r in adult)
    adult = [r for r in adult if 18 <= number(r, "Age") <= 80]
    if len(adult) < 10:
        raise SystemExit("No hay suficientes adultos en la franja 18–80.")

    reference = [number(r, "DXA") for r in adult]
    pred_cun = [cun_bae(number(r, "BMI"), number(r, "Age"), number(r, "SEX") == 2) for r in adult]
    models = {
        "CUN-BAE (recalculado; sin fotos)": pred_cun,
        "B1VS (volumen + forma fotográficos; predicción publicada)": [number(r, "B1VS") for r in adult],
        "B2VS (volumen + forma fotográficos; predicción publicada)": [number(r, "B2VS") for r in adult],
    }
    print(f"ICPSR 101343 · n={len(adult)} adultos · edades originales del grupo: {age_min:.0f}–{age_max:.0f}")
    print("SEX: el código del estudio identifica 1 como masculino; se usa 2 como femenino.")
    for label, values in models.items():
        result = summarize(label, values, reference)
        result["r_DXA"] = correlation(values, reference)
        print(" | ".join(f"{k}={v:.3f}" if isinstance(v, float) else f"{k}={v}" for k, v in result.items()))
    print("NOTA: MAE/RMSE/bias están en puntos porcentuales. Los límites son Bland–Altman aproximados (bias ± 1.96 SD).")
    print("No valida el escáner de FORMA: el CSV contiene predicciones del artículo, no fotografías ni pesos del modelo.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
