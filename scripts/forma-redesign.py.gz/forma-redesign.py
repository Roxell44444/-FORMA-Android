from pathlib import Path
import re, shutil

HERE = Path(__file__).resolve().parent
ROOT = next((candidate for candidate in [HERE / 'FORMA-1.1.0', HERE / 'project' / 'FORMA-1.1.0', HERE.parent / 'FORMA-1.1.0'] if candidate.exists()), HERE / 'FORMA-1.1.0')

def replace_once(path, old, new, label):
    text = path.read_text(encoding='utf-8')
    if old not in text:
        raise SystemExit(f'No se encontró el bloque para: {label}')
    path.write_text(text.replace(old, new, 1), encoding='utf-8')

# ------------------------------------------------------------
# 1. Interfaz: menos texto, jerarquía clara y flujo guiado.
# ------------------------------------------------------------
index = ROOT / 'index.html'
html = index.read_text(encoding='utf-8')
html = html.replace('<meta name="description" content="FORMA: seguimiento de bienestar, composición corporal orientativa, escáner experimental y planes de entrenamiento." />', '<meta name="description" content="FORMA: bienestar, entrenamiento y seguimiento personal." />')
html = html.replace('<title>FORMA 1.0 — progreso con criterio</title>', '<title>FORMA — bienestar que avanza</title>')
html = html.replace('<span class="brand-mark">F</span>', '<span class="brand-mark"><img src="public/icon.webp" alt="" /></span>')
html = html.replace('<span><strong>FORMA</strong><small>PROGRESO CON CRITERIO</small></span>', '<span><strong>FORMA</strong><small>BIENESTAR EN MOVIMIENTO</small></span>')
html = html.replace('<div class="privacy-note"><span class="privacy-dot"></span><div><strong>Datos en este dispositivo</strong><small>Perfil e historial guardados localmente sin cifrar. No se envían fotos, preguntas ni medidas a terceros.</small></div></div>', '')
html = html.replace('<div class="topbar-right"><span class="local-pill">● DATOS LOCALES</span><div class="avatar" id="avatar-initial">U</div></div>', '<div class="topbar-right"><div class="avatar" id="avatar-initial">U</div></div>')
html = html.replace('<div class="notice notice-neutral"><span class="notice-icon">i</span><p><strong>Transparencia primero.</strong> FORMA distingue mediciones introducidas por ti de estimaciones. En adultos, el escáner ofrece una estimación exploratoria de grasa corporal combinando tu perfil con una cintura proxy extraída de las fotos. No mide directamente tejido adiposo ni músculo; en menores el escáner está desactivado.</p></div>', '<div class="notice notice-neutral"><span class="notice-icon">✦</span><p>Un espacio sencillo para conocer tu punto de partida, crear un plan y seguir tus avances.</p></div>')
html = html.replace('Completa tu evaluación para preparar un plan orientativo y hacer seguimiento.', 'Añade tus datos, realiza el análisis y recibe recomendaciones para tu objetivo.')
html = html.replace('<div class="eyebrow">EVALUACIÓN INICIAL</div><h1>Conoce tu punto de partida.</h1><p class="muted">Introduce datos medidos, no los que te gustaría tener. Podrás actualizarlos cuando quieras.</p>', '<div class="eyebrow">PASO 1 DE 3</div><h1>Cuéntanos sobre ti.</h1><p class="muted">Tus datos nos ayudarán a preparar una recomendación adaptada a ti.</p>')
html = html.replace('<h2>Datos básicos</h2><p>El perfil admite desde recién nacidos hasta adultos; los cálculos disponibles se habilitan solo en las edades y situaciones para las que fueron estudiados.</p>', '<h2>Datos básicos</h2><p>Completa la información para personalizar tu experiencia.</p>')
html = html.replace('<h2>Medidas corporales</h2><p>Todas las medidas son opcionales. Si tienes una cinta métrica, introdúcelas sin apretar la piel; las medidas adicionales ayudan al seguimiento y a contrastar el análisis visual.</p>', '<h2>Medidas adicionales</h2><p>Opcional. Puedes añadirlas ahora o más adelante.</p>')
html = html.replace('<h2>Actividad y objetivo</h2><p>Para adaptar el punto de partida del plan.</p>', '<h2>Tu objetivo</h2><p>Así adaptamos tu plan a lo que buscas.</p>')
html = html.replace('<div class="eyebrow">ANTES DE GUARDAR</div><h3>La calidad empieza con los datos.</h3><ul><li>Mídete en condiciones similares.</li><li>Usa centímetros y kilogramos.</li><li>No cambies el dato para obtener un resultado deseado.</li><li>Las fórmulas son estimaciones de población.</li></ul>', '<div class="eyebrow">SIGUIENTE PASO</div><h3>Primero tus datos. Luego tu análisis.</h3><p class="muted">Al guardar, pasarás al escáner corporal.</p>')

# Rebuild the scanner section, preserving the IDs used by the app logic.
scanner = '''        <section class="view" id="view-escaner">
          <div class="page-heading"><div class="eyebrow">PASO 2 DE 3</div><h1>Analiza tu punto de partida.</h1><p class="muted">Sube una foto de frente y otra de perfil. Cuando estén listas, pulsa analizar.</p></div>
          <div class="notice notice-warning hidden" id="minor-scan-notice"><span class="notice-icon">!</span><p>El escáner corporal está disponible únicamente para perfiles adultos.</p></div>
          <div class="scan-grid" id="scan-grid">
            <article class="panel scan-instructions">
              <div class="panel-heading"><div><div class="eyebrow">PARA UN MEJOR RESULTADO</div><h2>Antes de fotografiarte</h2></div><span class="scan-icon">◎</span></div>
              <div class="scan-guides compact-guides">
                <div><b>01</b><span><strong>Buena iluminación</strong><small>Evita sombras fuertes.</small></span></div>
                <div><b>02</b><span><strong>Cuerpo completo</strong><small>Incluye cabeza y pies.</small></span></div>
                <div><b>03</b><span><strong>Postura natural</strong><small>Ropa cómoda y ajustada.</small></span></div>
              </div>
            </article>
            <article class="panel capture-panel">
              <div class="capture-head"><div><div class="eyebrow">TUS FOTOGRAFÍAS</div><h2>Dos vistas necesarias</h2></div></div>
              <div class="capture-slots primary-captures">
                <div class="capture-slot" id="slot-front"><div class="capture-preview"><span class="capture-outline">♙</span><img alt="Vista frontal capturada" class="hidden" /><canvas class="pose-overlay" aria-hidden="true"></canvas></div><strong>De frente</strong><small>Mira hacia la cámara.</small><label class="button button-secondary file-button">Añadir foto<input type="file" accept="image/*" capture="user" data-capture="front" /></label><div class="pose-feedback" id="pose-front" role="status">Pendiente</div></div>
                <div class="capture-slot" id="slot-side"><div class="capture-preview"><span class="capture-outline">♙</span><img alt="Vista de perfil capturada" class="hidden" /><canvas class="pose-overlay" aria-hidden="true"></canvas></div><strong>De perfil</strong><small>Gira aproximadamente 90°.</small><label class="button button-secondary file-button">Añadir foto<input type="file" accept="image/*" capture="user" data-capture="side" /></label><div class="pose-feedback" id="pose-side" role="status">Pendiente</div></div>
              </div>
              <details class="optional-views"><summary>Añadir vistas opcionales</summary><div class="capture-slots optional-captures">
                <div class="capture-slot" id="slot-back"><div class="capture-preview"><span class="capture-outline">♙</span><img alt="Vista posterior capturada" class="hidden" /><canvas class="pose-overlay" aria-hidden="true"></canvas></div><strong>De espaldas</strong><small>Vista posterior.</small><label class="button button-secondary file-button">Añadir foto<input type="file" accept="image/*" capture="user" data-capture="back" /></label><div class="pose-feedback" id="pose-back" role="status">Opcional</div></div>
                <div class="capture-slot" id="slot-side2"><div class="capture-preview"><span class="capture-outline">♙</span><img alt="Segundo perfil capturado" class="hidden" /><canvas class="pose-overlay" aria-hidden="true"></canvas></div><strong>Perfil contrario</strong><small>Gira hacia el otro lado.</small><label class="button button-secondary file-button">Añadir foto<input type="file" accept="image/*" capture="user" data-capture="side2" /></label><div class="pose-feedback" id="pose-side2" role="status">Opcional</div></div>
              </div></details>
              <button class="button button-primary full-width analyze-button" id="analyze-body-scan" disabled>Analizar mi físico</button>
              <div class="capture-status" id="capture-status" role="status">Añade las dos fotos para comenzar.</div>
              <div class="pose-pair-summary" id="pose-pair-summary" role="status">Necesitamos una foto frontal y otra de perfil.</div>
              <button class="button button-ghost full-width" id="clear-captures">Borrar fotos</button>
            </article>
          </div>
          <article class="panel provider-panel" id="adult-scan-results"><div class="panel-heading"><div><div class="eyebrow">TU RESULTADO</div><h2>Análisis corporal</h2></div></div><div id="scan-result"><p class="muted">Tu resultado aparecerá aquí después del análisis.</p></div><button class="button button-primary full-width hidden" id="view-personal-plan" data-go="plan">Ver mi plan personalizado →</button></article>
        </section>

'''
html, n = re.subn(r'        <section class="view" id="view-escaner">.*?        </section>\n\n        <section class="view" id="view-plan">', scanner + '        <section class="view" id="view-plan">', html, count=1, flags=re.S)
if n != 1: raise SystemExit('No se pudo sustituir la pantalla del escáner.')

# Replace the Coach panel with a clean conversation surface.
coach = '''        <section class="view" id="view-coach">
          <div class="page-heading"><div class="eyebrow">TU ACOMPAÑANTE</div><h1>Habla con FORMA.</h1><p class="muted">Pregunta sobre tu entrenamiento, alimentación, recuperación o tus resultados.</p></div>
          <div class="coach-layout"><article class="panel coach-panel"><div class="coach-header"><div class="coach-avatar">✦</div><div><strong>FORMA Coach</strong><small>Estoy aquí para ayudarte a avanzar.</small></div></div><div class="chat-messages" id="chat-messages"><div class="chat-bubble coach-bubble">¡Hola! Puedo ayudarte a entender tus resultados y organizar tus hábitos. ¿Qué te gustaría mejorar?</div></div><div class="suggested-prompts"><button data-prompt="Analiza mis resultados">Mis resultados</button><button data-prompt="Dame una rutina para mi objetivo">Mi entrenamiento</button><button data-prompt="Qué puedo comer para mi objetivo">Alimentación</button><button data-prompt="Cómo puedo mejorar mi progreso">Mi progreso</button></div><form id="chat-form" class="chat-input-row"><input type="text" name="message" placeholder="Escribe tu pregunta…" maxlength="500" required /><button class="send-button" type="submit" aria-label="Enviar pregunta">↑</button></form></article></div>
        </section>'''
html, n = re.subn(r'        <section class="view" id="view-coach">.*?        </section>', coach, html, count=1, flags=re.S)
if n != 1: raise SystemExit('No se pudo sustituir la pantalla del Coach.')

# Shorten the plan empty-state language; JS will change it based on the next step.
html = html.replace('<h2>Primero necesitamos conocerte</h2><p>Completa tu evaluación para generar una propuesta de entrenamiento y un marco nutricional inicial.</p><button class="button button-primary" data-go="evaluacion">Completar evaluación →</button>', '<h2>Completa los pasos iniciales</h2><p>Añade tus datos y realiza el análisis para preparar tu plan.</p><button class="button button-primary" data-go="evaluacion">Comenzar →</button>')

# Replace 8 cramped bottom items with 6 primary destinations.
mobile_nav = '''  <nav class="mobile-nav" aria-label="Navegación principal">
    <button class="mobile-nav-item active" data-view="inicio"><span>⌂</span><small>Inicio</small></button>
    <button class="mobile-nav-item" data-view="evaluacion"><span>◎</span><small>Datos</small></button>
    <button class="mobile-nav-item" data-view="escaner"><span>▣</span><small>Escáner</small></button>
    <button class="mobile-nav-item" data-view="plan"><span>▤</span><small>Plan</small></button>
    <button class="mobile-nav-item" data-view="progreso"><span>↗</span><small>Progreso</small></button>
    <button class="mobile-nav-item" data-view="coach"><span>✦</span><small>Coach</small></button>
  </nav>'''
html, n = re.subn(r'  <nav class="mobile-nav".*?</nav>', mobile_nav, html, count=1, flags=re.S)
if n != 1: raise SystemExit('No se pudo actualizar la navegación móvil.')
# Add useful links to Dieta/Diario without adding more bottom tabs.
html = html.replace('<div class="dashboard-grid">', '<div class="quick-links"><button class="button button-secondary" data-go="dieta">Mi alimentación</button><button class="button button-secondary" data-go="diario">Mi diario</button><button class="button button-secondary" data-go="coach">Hablar con Coach</button></div><div class="dashboard-grid">', 1)
# Put the single safety clarification outside the individual feature descriptions.
html = html.replace('      </div>\n    </main>', '        <footer class="app-disclaimer">FORMA es una herramienta de bienestar y seguimiento. No diagnostica ni sustituye la evaluación de profesionales.</footer>\n      </div>\n    </main>', 1)
index.write_text(html, encoding='utf-8')

# ------------------------------------------------------------
# 2. Escáner: captar primero, analizar al pulsar y usar recursos locales.
# ------------------------------------------------------------
app = ROOT / 'src/app.js'
js = app.read_text(encoding='utf-8')
js = js.replace('let scanBusy = false;\n', 'let scanBusy = false;\nconst analyzeButton = document.querySelector("#analyze-body-scan");\n')
js = js.replace("const poseConsent = $('#pose-consent');\n", '')
js = js.replace("  if (poseResults.front && poseResults.side) runBodyScan();\n  toast('Evaluación guardada.');\n  go('plan');", "  toast('Datos guardados. Ahora completa el análisis corporal.');\n  go(isMinor ? 'plan' : 'escaner');\n  updateScanButton();")
# Replace the profile-plan and diet access gating with a completed-scan requirement for adults.
js = js.replace("  $('#plan-empty').classList.toggle('hidden', !!p);\n  $('#plan-content').classList.toggle('hidden', !p);\n  if (!p) return;", "  const needsScan = Boolean(p && p.age >= 18 && !state.scanResult?.measurements);\n  $('#plan-empty').classList.toggle('hidden', Boolean(p) && !needsScan);\n  $('#plan-content').classList.toggle('hidden', !p || needsScan);\n  if (!p) return;\n  if (needsScan) { $('#plan-empty h2').textContent = 'Primero completa tu análisis'; $('#plan-empty p').textContent = 'Con tus datos y el análisis corporal prepararemos las recomendaciones.'; $('#plan-empty button').textContent = 'Ir al escáner →'; $('#plan-empty button').dataset.go = 'escaner'; return; }")
js = js.replace("  const p=state.profile;\n  $('#diet-empty').classList.toggle('hidden',!!p);\n  $('#diet-content').classList.toggle('hidden',!p);\n  if(!p) return;", "  const p=state.profile;\n  const needsScan = Boolean(p && p.age >= 18 && !state.scanResult?.measurements);\n  $('#diet-empty').classList.toggle('hidden', Boolean(p) && !needsScan);\n  $('#diet-content').classList.toggle('hidden', !p || needsScan);\n  if(!p) return;\n  if (needsScan) { $('#diet-empty h2').textContent = 'Completa primero tu análisis'; $('#diet-empty p').textContent = 'Después del escáner tendrás recomendaciones de alimentación adaptadas a tu objetivo.'; $('#diet-empty button').textContent = 'Ir al escáner →'; $('#diet-empty button').dataset.go = 'escaner'; return; }")

# Simplify the per-photo status and remove checkbox/automatic logic.
start = js.find('function updatePosePairSummary() {')
end = js.find('\nfunction buildWorkout(p)', start)
if start < 0 or end < 0: raise SystemExit('No se encontró el bloque de resumen del escáner.')
new_scan_logic = r'''function renderScanResult() {
  const root = $('#scan-result');
  if (!root) return;
  const result = state.scanResult;
  if (!result?.measurements) { root.innerHTML = '<p class="muted">Tu resultado aparecerá aquí después del análisis.</p>'; $('#view-personal-plan')?.classList.add('hidden'); return; }
  const m = result.measurements, c = result.composition;
  const fat = c ? (c.bodyFatPercent === null ? `${fmt(c.bodyFatLow,1)}–${fmt(c.bodyFatHigh,1)}%` : `≈ ${fmt(c.bodyFatPercent,1)}%`) : 'No disponible';
  const fatMass = c ? (c.fatMassKg === null ? `${fmt(c.fatMassLowKg,1)}–${fmt(c.fatMassHighKg,1)} kg` : `${fmt(c.fatMassKg,1)} kg`) : '—';
  const leanMass = c ? (c.fatFreeMassKg === null ? `${fmt(c.fatFreeMassLowKg,1)}–${fmt(c.fatFreeMassHighKg,1)} kg` : `${fmt(c.fatFreeMassKg,1)} kg`) : '—';
  root.innerHTML = `<div class="scan-result-grid"><article class="scan-result-card featured"><small>GRASA CORPORAL ESTIMADA</small><strong>${fat}</strong><span>Orientativo</span></article><article class="scan-result-card"><small>MASA GRASA</small><strong>${fatMass}</strong></article><article class="scan-result-card"><small>MASA LIBRE DE GRASA</small><strong>${leanMass}</strong></article><article class="scan-result-card"><small>CINTURA ESTIMADA</small><strong>${fmt(m.waist.circumferenceCm,1)} cm</strong></article><article class="scan-result-card"><small>PECHO ESTIMADO</small><strong>${fmt(m.chest.circumferenceCm,1)} cm</strong></article><article class="scan-result-card"><small>CADERA ESTIMADA</small><strong>${fmt(m.hip.circumferenceCm,1)} cm</strong></article></div><p class="scan-result-note">Estas cifras son aproximaciones. Puedes confirmar los perímetros con una cinta métrica.</p>`;
  $('#view-personal-plan')?.classList.remove('hidden');
}

function updateScanButton() {
  if (!analyzeButton) return;
  const ready = Boolean(state.profile && state.profile.age >= 18 && capturedUrls.front && capturedUrls.side);
  analyzeButton.disabled = !ready || scanBusy;
  analyzeButton.textContent = scanBusy ? 'Analizando…' : state.scanResult ? 'Volver a analizar' : 'Analizar mi físico';
}

function updatePosePairSummary() {
  const node = $('#pose-pair-summary');
  const front = poseResults.front;
  const side = poseResults.side;
  if (!capturedUrls.front || !capturedUrls.side) {
    node.textContent = 'Añade una foto frontal y otra de perfil para continuar.';
    return;
  }
  if (front?.status === 'rejected' || side?.status === 'rejected') {
    node.textContent = 'Una de las fotos necesita repetirse. Revisa las indicaciones de cada imagen.';
    return;
  }
  if (!front || !side) {
    node.textContent = 'Tus fotos están listas. Pulsa «Analizar mi físico» para comenzar.';
    return;
  }
  node.textContent = 'Fotos revisadas. Estamos preparando tu resultado.';
}

function runBodyScan() {
  if (state.profile && state.profile.age < 18) return;
  if (!poseResults.front || !poseResults.side || !capturedUrls.front || !capturedUrls.side) return;
  if (poseResults.front.status === 'rejected' || poseResults.side.status === 'rejected') return;
  if (!state.profile?.height) {
    $('#capture-status').textContent = 'Completa tu estatura en Datos para terminar el análisis.';
    return;
  }
  if (poseResults.front.orientation !== 'front-likely' || poseResults.side.orientation !== 'side-likely') {
    $('#pose-pair-summary').textContent = 'Las fotos no muestran claramente una vista frontal y otra de perfil. Repite las que sean necesarias.';
    $('#capture-status').textContent = 'No pudimos confirmar el ángulo de las fotos.';
    return;
  }
  if (!poseResults.front.personMask || !poseResults.side.personMask) {
    $('#capture-status').textContent = 'No pudimos separar tu silueta con suficiente claridad. Prueba con más luz y un fondo sencillo.';
    return;
  }
  try {
    const result = estimateTwoViewAnthropometry({
      frontMask: poseResults.front.personMask,
      sideMask: poseResults.side.personMask,
      frontLandmarks: poseResults.front.landmarks,
      sideLandmarks: poseResults.side.landmarks,
      backMask: poseResults.back?.status !== 'rejected' && poseResults.back?.orientation === 'front-likely' ? poseResults.back?.personMask : null,
      backLandmarks: poseResults.back?.status !== 'rejected' && poseResults.back?.orientation === 'front-likely' ? poseResults.back?.landmarks : null,
      side2Mask: poseResults.side2?.status !== 'rejected' && poseResults.side2?.orientation === 'side-likely' ? poseResults.side2?.personMask : null,
      side2Landmarks: poseResults.side2?.status !== 'rejected' && poseResults.side2?.orientation === 'side-likely' ? poseResults.side2?.landmarks : null,
      heightCm: Number(state.profile.height)
    });
    const composition = estimatePhotoAssistedComposition({ profile: state.profile, measurements: result.measurements, captureQuality: result.captureQuality });
    const muscleSupplement = profileAppendicularMuscle(state.profile);
    state.scanResult = { ...result, composition, muscleSupplement, createdAt: new Date().toISOString() };
    saveState();
    renderScanResult();
    renderPlan();
    renderDiet();
    $('#capture-status').textContent = 'Análisis completado. Ya puedes consultar tus recomendaciones.';
    $('#pose-pair-summary').textContent = 'Tu resultado está listo.';
    $('#view-personal-plan')?.classList.remove('hidden');
    toast('Análisis completado. Tu plan está preparado.');
  } catch (error) {
    console.error('FORMA body scan error:', error);
    state.scanResult = null;
    $('#capture-status').textContent = 'No pudimos completar el análisis. Revisa las fotos e inténtalo de nuevo.';
    $('#pose-pair-summary').textContent = 'Prueba con buena iluminación, el cuerpo completo y un fondo despejado.';
    renderScanResult();
    renderPlan();
    renderDiet();
  }
}

async function analyzeCapture(kind, image, sequence, detector) {
  const status = $(`#pose-${kind}`);
  status.className = 'pose-feedback';
  status.textContent = 'Analizando…';
  await image.decode();
  const analysis = detectPoseInImage(detector, image, kind);
  if (sequence !== captureSequence[kind]) return null;
  poseResults[kind] = analysis;
  renderPoseFeedback(kind, analysis);
  drawFeedback(kind, analysis.landmarks);
  return analysis;
}

async function startBodyAnalysis() {
  if (scanBusy) return;
  if (!state.profile) { toast('Completa primero tus datos.'); go('evaluacion'); return; }
  if (state.profile.age < 18) { toast('El escáner no está disponible para perfiles menores de 18 años.'); return; }
  if (!capturedUrls.front || !capturedUrls.side) { toast('Añade una foto frontal y otra de perfil.'); return; }
  scanBusy = true;
  updateScanButton();
  $('#capture-status').textContent = 'Estamos analizando tus fotos…';
  try {
    const detector = await createPoseLandmarker();
    for (const kind of VIEW_KEYS) {
      if (!capturedUrls[kind]) continue;
      const image = $('img', $(`#slot-${kind}`));
      await analyzeCapture(kind, image, captureSequence[kind], detector);
    }
    updatePosePairSummary();
    runBodyScan();
  } catch (error) {
    console.error('FORMA vision initialization error:', error);
    VIEW_KEYS.forEach(kind => {
      if (!capturedUrls[kind]) return;
      const node = $(`#pose-${kind}`);
      node.className = 'pose-feedback review';
      node.textContent = 'No se pudo analizar esta foto. Vuelve a intentarlo.';
    });
    $('#capture-status').textContent = 'No pudimos iniciar el análisis. Cierra y vuelve a abrir la app, e inténtalo de nuevo.';
    $('#pose-pair-summary').textContent = 'Tus fotos siguen disponibles. Puedes volver a intentarlo.';
  } finally {
    scanBusy = false;
    updateScanButton();
  }
}

if (analyzeButton) analyzeButton.addEventListener('click', startBodyAnalysis);

$$('[data-capture]').forEach(input => input.addEventListener('change', async () => {
  const file = input.files?.[0]; if (!file) return;
  if (!file.type.startsWith('image/')) { toast('Selecciona una imagen válida.'); input.value = ''; return; }
  if (file.size > 12 * 1024 * 1024) { toast('La imagen supera el máximo de 12 MB.'); input.value=''; return; }
  const kind = input.dataset.capture;
  captureSequence[kind] += 1;
  const sequence = captureSequence[kind];
  poseResults[kind] = null;
  state.scanResult = null;
  saveState();
  renderScanResult();
  $('#view-personal-plan')?.classList.add('hidden');
  if (capturedUrls[kind]) URL.revokeObjectURL(capturedUrls[kind]);
  capturedUrls[kind] = URL.createObjectURL(file);
  const slot = $(`#slot-${kind}`);
  const img = $('img', slot);
  const canvas = $('canvas', slot);
  const ctx = canvas.getContext('2d');
  if (ctx) ctx.clearRect(0, 0, canvas.width, canvas.height);
  canvas.classList.remove('visible');
  img.src = capturedUrls[kind];
  img.classList.remove('hidden');
  $('.capture-outline', slot).classList.add('hidden');
  $(`#pose-${kind}`).className = 'pose-feedback ready';
  $(`#pose-${kind}`).textContent = 'Foto añadida';
  try { await img.decode(); } catch { toast('No se pudo abrir la imagen. Prueba con otra foto.'); return; }
  if (sequence !== captureSequence[kind]) return;
  $('#capture-status').textContent = 'Fotos cargadas. Pulsa analizar cuando tengas las dos vistas.';
  updatePosePairSummary();
  updateScanButton();
}));

$('#clear-captures').addEventListener('click', () => {
  VIEW_KEYS.forEach(kind => {
    captureSequence[kind] += 1;
    if (capturedUrls[kind]) URL.revokeObjectURL(capturedUrls[kind]);
    capturedUrls[kind] = null;
    poseResults[kind] = null;
    const slot = $(`#slot-${kind}`);
    $('img',slot).removeAttribute('src'); $('img',slot).classList.add('hidden');
    $('.capture-outline',slot).classList.remove('hidden');
    const canvas = $('canvas', slot); const ctx = canvas.getContext('2d');
    if (ctx) ctx.clearRect(0, 0, canvas.width, canvas.height);
    canvas.classList.remove('visible');
    $('input',slot).value='';
    const feedback = $(`#pose-${kind}`); feedback.className = 'pose-feedback'; feedback.textContent = 'Pendiente';
  });
  $('#capture-status').textContent = 'Fotos eliminadas.';
  state.scanResult = null; saveState(); renderScanResult();
  $('#view-personal-plan')?.classList.add('hidden');
  renderPlan(); renderDiet(); updatePosePairSummary(); updateScanButton();
});
'''
js = js[:start] + new_scan_logic + js[end:]
# Simplify feedback: no engineering jargon or diagnostic score.
js = js.replace("  const message = notes.length ? notes.map(escapeHTML).join(' ') : 'Puntos principales visibles y sin alertas de encuadre.';\n  node.innerHTML = `<strong>${escapeHTML(analysis.title)}</strong><small>Calidad de captura: ${analysis.score}/100 · No es precisión de composición corporal.</small><small>${message}</small>`;", "  const message = notes.length ? notes.map(escapeHTML).join(' ') : 'La foto está lista.';\n  node.innerHTML = `<strong>${analysis.status === 'rejected' ? 'Repite esta foto' : 'Foto revisada'}</strong><small>${message}</small>`;")

# Coach implementation: attach the missing submit and suggestion handlers and use personalized context.
coach_logic = r'''function normalizeCoachText(value) {
  return String(value || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
}

function coachReply(message) {
  const q = normalizeCoachText(message);
  const p = state.profile;
  const scan = state.scanResult?.measurements;
  const goalName = ({ fatloss: 'mejorar composición corporal', muscle: 'ganar fuerza y músculo', recomp: 'mejorar composición y hábitos', maintain: 'mantener tu condición' })[p?.goal] || 'mejorar tu bienestar';
  const intro = p ? `Con tu perfil de ${p.age} años, ${p.height} cm y ${p.weight} kg, tu objetivo actual es ${goalName}. ` : 'Aún no tengo tus datos de perfil. ';
  if (/hola|buenos dias|buenas tardes|buenas noches|quien eres/.test(q)) return '¡Hola! Soy FORMA Coach. Puedo ayudarte a organizar tu entrenamiento, mejorar tus hábitos, entender tus resultados y revisar tu progreso. ¿Por dónde empezamos?';
  if (/mi resultado|mis resultados|mi escaner|mi fisico|mi composicion|mis medidas|analiza/.test(q)) {
    if (!p) return 'Primero completa tus datos en la sección Datos. Después realiza el análisis corporal y podré ayudarte a interpretar los resultados.';
    if (!scan) return `${intro}Todavía no hay un análisis corporal completo. Añade las fotos frontal y de perfil en Escáner y pulsa «Analizar mi físico».`;
    const c = state.scanResult.composition;
    const waist = fmt(scan.waist.circumferenceCm,1);
    const fat = c ? (c.bodyFatPercent === null ? `${fmt(c.bodyFatLow,1)}–${fmt(c.bodyFatHigh,1)}%` : `${fmt(c.bodyFatPercent,1)}%`) : 'no disponible';
    return `${intro}Tu último análisis estima una cintura de ${waist} cm y un porcentaje de grasa corporal de ${fat}. Son cifras orientativas, no un diagnóstico ni una medida directa del músculo. Compara los cambios en condiciones similares y confirma los perímetros con cinta.`;
  }
  if (/mi plan|plan de entrenamiento|rutina|entrenamiento|ejercicios|series|repeticiones|pesas|fuerza|musculo/.test(q)) {
    if (!p) return 'Completa primero tus datos para que podamos adaptar las recomendaciones a tu experiencia, objetivo y disponibilidad.';
    if (p.age < 18) return 'Para este perfil prioriza el juego activo, los deportes que disfrutes, caminar y moverte con variedad. Evita planes centrados en el peso o la apariencia y hazlo con supervisión adulta.';
    const sessions = Math.max(2,Math.min(5,p.sessions || 3));
    const equipment = ({ home: 'en casa', basic: 'con equipo básico', gym: 'en gimnasio' })[p.equipment] || 'con tu equipo disponible';
    const focus = p.goal === 'fatloss' ? 'Combina fuerza con caminatas cómodas y una progresión sostenible; no necesitas entrenar al máximo.' : p.goal === 'muscle' ? 'Prioriza movimientos principales, técnica controlada y aumenta poco a poco repeticiones o carga.' : p.goal === 'recomp' ? 'Mantén el trabajo de fuerza constante, sueño suficiente y hábitos de alimentación sostenibles.' : 'Mantén una rutina equilibrada que puedas sostener durante meses.';
    return `${intro}Tu perfil permite organizar ${sessions} sesiones por semana ${equipment}. ${focus} Empieza cada sesión con 5–10 minutos de calentamiento, deja tiempo de recuperación y registra las sesiones completadas en Mi plan. Allí tienes los ejercicios y días sugeridos.`;
  }
  if (/progreso|no avanzo|estancad|resultados no|bajar|subir de peso|perder peso|abdomen|barriga|grasa localizada/.test(q)) {
    if (!p) return 'Registra primero tus datos y comienza el seguimiento. Después podremos comparar las tendencias.';
    return `${intro}Para valorar el progreso, compara promedios y medidas cada 2–4 semanas, no cambios de un solo día. No es posible elegir de qué zona se pierde grasa. Si llevas varias semanas sin cambios, revisa primero la constancia, la recuperación, el sueño y tus registros antes de modificar el plan.`;
  }
  if (/caloria|calorias|metabolismo|energia|cuanto debo comer/.test(q)) {
    if (!p) return 'Completa tus datos básicos y tu actividad para mostrar una referencia inicial de energía en la sección Plan.';
    const bmi = calculateBMI(p.weight,p.height);
    const energy = p.safety === 'no' && ageCapabilities(p.age).mifflinEnergy ? calculateEnergyEstimate({ weightKg:p.weight,heightCm:p.height,age:p.age,equation:p.equation,activity:p.activity }) : null;
    if (!energy) return `${intro}No hay una referencia calórica automática adecuada para este perfil. Podemos trabajar con hábitos, regularidad y señales de bienestar sin fijar una cifra.`;
    return `${intro}La estimación inicial de mantenimiento de FORMA es de ${fmt(energy.maintenance.low)}–${fmt(energy.maintenance.high)} kcal al día. Es un punto de partida, no una cifra exacta. Observa energía, hambre, actividad y tendencia de peso durante varias semanas antes de hacer ajustes.`;
  }
  if (/proteina|proteinas|macro|carbohidrato|grasa saludable/.test(q)) {
    if (!p) return 'Completa tus datos para ajustar la orientación nutricional a tu perfil y objetivo.';
    const macro = calculateMacroGuide({ weightKg:p.weight,goal:p.goal });
    const protein = macro?.proteinGrams ? `${macro.proteinGrams} g diarios como referencia inicial para tu peso` : 'una fuente de proteína en las comidas principales';
    return `${intro}Una referencia útil es repartir la proteína a lo largo del día. Para tu peso, la guía inicial de FORMA sugiere ${protein}. Incluye también frutas, verduras, legumbres o cereales integrales y grasas saludables. Si tienes enfermedad renal u otra condición médica, consulta antes de cambiar mucho la ingesta.`;
  }
  if (/comer|comida|dieta|aliment|desayuno|almuerzo|cena|menu|receta/.test(q)) {
    if (!p) return 'Completa primero tu evaluación para tener en cuenta tus objetivos y preferencias de alimentación.';
    const pref = (p.diet || '').toLowerCase();
    const veg = /vegetar|vegano|vegan/.test(pref);
    const protein = veg ? 'huevos, yogur, tofu o legumbres' : 'pollo, pescado, huevos o legumbres';
    return `${intro}Prueba una estructura sencilla: desayuno con avena, yogur o alternativa y fruta; almuerzo con ${protein}, arroz o patata y verduras; merienda según tu hambre; cena con una fuente de proteína, vegetales y cereal o tubérculo. Ajusta las porciones a tu apetito y actividad. Tu preferencia registrada es: ${p.diet || 'sin restricciones indicadas'}.`;
  }
  if (/descanso|dormir|sueno|recuperacion|cansancio|fatiga/.test(q)) return 'La recuperación también forma parte del plan. Mantén horarios de sueño regulares, alterna sesiones exigentes con días ligeros y evita entrenar intensamente el mismo grupo muscular si sigue muy fatigado. Si el cansancio es persistente o inusual, consulta con un profesional.';
  if (/calentar|calentamiento|estirar|movilidad/.test(q)) return 'Antes de entrenar, dedica 5–10 minutos a caminar o pedalear suave y hacer movimientos dinámicos de las articulaciones que vas a utilizar. Después de la sesión puedes hacer movilidad suave; no fuerces un estiramiento doloroso.';
  if (/dolor|lesion|mareo|desmayo|pecho|embaraz|enfermedad|medicacion/.test(q)) return 'No puedo valorar síntomas ni tratar lesiones. Detén el ejercicio que provoca molestias y consulta con un profesional sanitario. Si aparece dolor en el pecho, desmayo, dificultad respiratoria intensa o síntomas graves, busca atención urgente.';
  if (/edad|altura|estatura|peso|objetivo|perfil|datos/.test(q)) return p ? `${intro}Puedes actualizar esos datos en la sección Datos. Si cambias la estatura, el peso, el objetivo o las preferencias, vuelve a revisar tu plan.` : 'Puedes añadir edad, estatura, peso, sexo de referencia y objetivo en la sección Datos. Con esa información podré darte recomendaciones más útiles.';
  return `${p ? intro : ''}Puedo ayudarte con tu rutina, ejercicios, alimentación, proteína, calorías, descanso, resultados y progreso. Cuéntame qué objetivo quieres trabajar y te daré una recomendación concreta.`;
}

function addMessage(text, type) {
  const node = document.createElement('div');
  node.className = `chat-bubble ${type === 'user' ? 'user-bubble' : 'coach-bubble'}`;
  node.textContent = text;
  $('#chat-messages').append(node);
  $('#chat-messages').scrollTop = $('#chat-messages').scrollHeight;
}

$('#chat-form').addEventListener('submit', event => {
  event.preventDefault();
  const field = event.currentTarget.elements.message;
  const message = String(field.value || '').trim();
  if (!message) return;
  addMessage(message, 'user');
  field.value = '';
  addMessage(coachReply(message), 'coach');
});

$$('[data-prompt]').forEach(button => button.addEventListener('click', () => {
  const message = button.dataset.prompt;
  addMessage(message, 'user');
  addMessage(coachReply(message), 'coach');
}));
'''
cs = js.find('function coachReply(message) {')
ce = js.find('\nfunction renderDiary()', cs)
if cs < 0 or ce < 0: raise SystemExit('No se encontró el bloque del Coach.')
js = js[:cs] + coach_logic + js[ce:]
# Ensure every route render uses the new gates and scan button state.
js = js.replace('populateForm(); renderScanResult(); renderDashboard(); renderHistory(); renderPlan(); renderDiet(); renderDiary();', 'populateForm(); renderScanResult(); renderDashboard(); renderHistory(); renderPlan(); renderDiet(); renderDiary(); updateScanButton();')
js = js.replace("renderScanResult(); renderScanValidation(); renderDashboard(); renderHistory(); renderPlan(); renderDiet(); renderDiary();", "renderScanResult(); renderDashboard(); renderHistory(); renderPlan(); renderDiet(); renderDiary(); updateScanButton();")
# Existing age mode toggles the scanner; button refreshes if age/profile changes.
js = js.replace("  $('#adult-progress-layout').classList.toggle('hidden', minor);", "  $('#adult-progress-layout').classList.toggle('hidden', minor);\n  updateScanButton?.();")
# `updateScanButton` is a function declaration, safe to invoke before its first call.
app.write_text(js, encoding='utf-8')

# ------------------------------------------------------------
# 3. Pose package & model are loaded from inside the APK.
# ------------------------------------------------------------
pose = ROOT / 'src/scanner/pose.js'
pjs = pose.read_text(encoding='utf-8')
pjs = pjs.replace("export const POSE_MODEL_URL = 'https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_lite/float16/1/pose_landmarker_lite.task';\nconst WASM_URL = `https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@${MEDIAPIPE_VERSION}/wasm`;\nconst BUNDLE_URL = `https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@${MEDIAPIPE_VERSION}/vision_bundle.mjs`;", "export const POSE_MODEL_URL = new URL('../../models/pose_landmarker_lite.task', import.meta.url).href;\nconst VISION_BASE = new URL('../../vendor/mediapipe/', import.meta.url);\nconst WASM_URL = new URL('wasm/', VISION_BASE).href;\nconst BUNDLE_URL = new URL('vision_bundle.mjs', VISION_BASE).href;")
# Use CPU first; CPU is more predictable in Android WebView, then try GPU as fallback.
pjs = pjs.replace("baseOptions: { modelAssetPath: POSE_MODEL_URL, delegate: 'GPU' }", "baseOptions: { modelAssetPath: POSE_MODEL_URL, delegate: 'CPU' }")
pjs = pjs.replace("baseOptions: { modelAssetPath: POSE_MODEL_URL, delegate: 'CPU' }\n          });\n        } catch (cpuError)", "baseOptions: { modelAssetPath: POSE_MODEL_URL, delegate: 'GPU' }\n          });\n        } catch (cpuError)")
pose.write_text(pjs, encoding='utf-8')

# Local package/model are included in both Android and PWA distributions.
build = ROOT / 'scripts/build.mjs'
build_text = build.read_text(encoding='utf-8').replace("'src', 'public'", "'src', 'public', 'vendor', 'models'")
build.write_text(build_text, encoding='utf-8')

# Update the service worker's cache key so older UI is replaced after a new install/update.
sw = ROOT / 'service-worker.js'
swt = sw.read_text(encoding='utf-8').replace("const CACHE = 'forma-1.1.0-shell';", "const CACHE = 'forma-1.2.0-shell';")
swt = swt.replace("'public/icon.svg'", "'public/icon.webp', 'vendor/mediapipe/vision_bundle.mjs', 'models/pose_landmarker_lite.task'")
sw.write_text(swt, encoding='utf-8')

# ------------------------------------------------------------
# 4. New visual identity: web icon + native Android adaptive icon.
# ------------------------------------------------------------
svg = '''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
<defs><linearGradient id="lime" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#e1ff77"/><stop offset=".55" stop-color="#a7ed4f"/><stop offset="1" stop-color="#56d89a"/></linearGradient><radialGradient id="bg"><stop stop-color="#183526"/><stop offset="1" stop-color="#07140f"/></radialGradient></defs>
<rect width="512" height="512" rx="116" fill="url(#bg)"/>
<path d="M104 334C38 292 74 167 206 123" fill="none" stroke="#37dca0" stroke-width="22" stroke-linecap="round"/>
<path d="M112 389C271 461 430 337 425 191" fill="none" stroke="url(#lime)" stroke-width="28" stroke-linecap="round"/>
<circle cx="256" cy="137" r="49" fill="url(#lime)"/>
<path d="M176 238c7-28 31-45 62-49l18 27 18-27c31 4 55 21 62 49l28 84-30 22-30-51-10 123c-1 17-14 29-31 29h-14c-17 0-30-12-31-29l-10-123-30 51-30-22z" fill="url(#lime)"/>
<path d="M220 296c13-13 25-18 36-18s23 5 36 18M224 333c11-8 21-12 32-12s21 4 32 12" fill="none" stroke="#17402b" stroke-width="12" stroke-linecap="round"/>
</svg>'''
(ROOT / 'public/icon.svg').write_text(svg, encoding='utf-8')

# Manifest uses high-quality maskable icon.
manifest = ROOT / 'manifest.webmanifest'
mt = manifest.read_text(encoding='utf-8')
mt = mt.replace('"description": "Escáner corporal experimental local, entrenamiento y nutrición con estimaciones transparentes."', '"description": "Bienestar, entrenamiento y seguimiento personal."')
mt = mt.replace('"src": "./public/icon.webp", "sizes": "512x512", "type": "image/webp", "purpose": "any maskable"', '"src": "./public/icon.webp", "sizes": "512x512", "type": "image/webp", "purpose": "any maskable"')
manifest.write_text(mt, encoding='utf-8')

android = ROOT / 'android/app/src/main'
manifest_android = android / 'AndroidManifest.xml'
amt = manifest_android.read_text(encoding='utf-8')
amt = amt.replace('<application\n        android:allowBackup="false"', '<application\n        android:icon="@drawable/forma_launcher"\n        android:roundIcon="@drawable/forma_launcher"\n        android:allowBackup="false"')
manifest_android.write_text(amt, encoding='utf-8')

app_gradle = ROOT / 'android/app/build.gradle'
ag = app_gradle.read_text(encoding='utf-8').replace('versionCode 110', 'versionCode 120').replace("versionName '1.1.0'", "versionName '1.2.0'")
app_gradle.write_text(ag, encoding='utf-8')

(android / 'res/values').mkdir(parents=True, exist_ok=True)
(android / 'res/drawable-nodpi').mkdir(parents=True, exist_ok=True)
# forma_launcher.webp is copied from the repository asset by the build workflow.
(android / 'res/values/colors.xml').write_text('''<resources><color name="forma_launcher_background">#07140F</color></resources>''', encoding='utf-8')
(android / 'res/drawable').mkdir(parents=True, exist_ok=True)
(android / 'res/drawable/forma_launcher_foreground.xml').write_text('''<vector xmlns:android="http://schemas.android.com/apk/res/android" android:width="108dp" android:height="108dp" android:viewportWidth="108" android:viewportHeight="108">
  <path android:fillColor="#B8F265" android:pathData="M54,15a12,12 0,1 0,0 24a12,12 0,1 0,0 -24"/>
  <path android:fillColor="#B8F265" android:pathData="M34,45c3,-7 9,-11 17,-12l3,7l3,-7c8,1 14,5 17,12l8,22l-9,6l-9,-13l-2,24c0,5 -4,8 -8,8h-1c-5,0 -8,-3 -8,-8l-2,-24l-9,13l-9,-6z"/>
  <path android:strokeColor="#2E6940" android:strokeWidth="3" android:strokeLineCap="round" android:fillColor="@android:color/transparent" android:pathData="M46,63q8,-8 16,0M48,72q6,-5 12,0"/>
  <path android:strokeColor="#45D69A" android:strokeWidth="3" android:strokeLineCap="round" android:fillColor="@android:color/transparent" android:pathData="M22,68C10,52 22,32 39,27"/>
  <path android:strokeColor="#B8F265" android:strokeWidth="4" android:strokeLineCap="round" android:fillColor="@android:color/transparent" android:pathData="M21,84C55,104 90,77 87,42"/>
</vector>''', encoding='utf-8')
for d in ['mipmap-anydpi-v26']:
    (android / 'res' / d).mkdir(parents=True, exist_ok=True)
for name in ['ic_launcher', 'ic_launcher_round']:
    (android / 'res/mipmap-anydpi-v26' / f'{name}.xml').write_text('''<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
  <background android:drawable="@color/forma_launcher_background"/>
  <foreground android:drawable="@drawable/forma_launcher_foreground"/>
</adaptive-icon>''', encoding='utf-8')

# ------------------------------------------------------------
# 5. Responsive visual polish: legible type, less crowding.
# ------------------------------------------------------------
css = ROOT / 'src/ui/styles.css'
css_text = css.read_text(encoding='utf-8')
css_text += r'''

/* FORMA 1.2 — simpler mobile experience */
.brand-mark img{width:100%;height:100%;display:block;object-fit:cover;border-radius:inherit}
.mobile-brand .brand-mark{overflow:hidden}
.quick-links{display:flex;flex-wrap:wrap;gap:8px;margin:0 0 16px}
.quick-links .button{font-size:11px;padding:10px 13px}
.app-disclaimer{margin:24px auto 8px;max-width:760px;text-align:center;color:#829287;font-size:11px;line-height:1.55}
.scan-instructions{align-self:start}
.compact-guides{display:grid;gap:13px}
.compact-guides>div{display:flex;align-items:center;gap:10px}
.compact-guides b{display:grid;place-items:center;width:27px;height:27px;border-radius:9px;background:#263a2a;color:var(--green);font-size:11px}
.compact-guides strong,.compact-guides small{display:block}
.compact-guides strong{font-size:12px}
.compact-guides small{font-size:10px;color:var(--muted);margin-top:3px}
.optional-views{margin:12px 0;border-top:1px solid var(--line);padding-top:12px}
.optional-views summary{cursor:pointer;color:#c5d8c4;font-size:12px;font-weight:650;padding:6px 0}
.optional-captures{margin-top:12px}
.analyze-button{margin:14px 0 4px;min-height:48px;font-size:14px}
.analyze-button:disabled{opacity:.42;cursor:not-allowed}
.capture-status,.pose-pair-summary{font-size:11px;line-height:1.55;padding:11px 12px;margin:8px 0;border-radius:10px;background:#17231b;color:#b9c9b9}
.pose-feedback{min-height:30px;font-size:10px;text-align:center;padding:7px;margin-top:7px}
.pose-feedback strong{font-size:10px}
.pose-feedback small{font-size:10px}
.scan-result-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px;margin:12px 0}
.scan-result-card{min-width:0;background:#111b15;border:1px solid var(--line);border-radius:12px;padding:14px}
.scan-result-card small,.scan-result-card strong,.scan-result-card span{display:block}
.scan-result-card small{font-size:9px;letter-spacing:.08em;color:var(--muted);line-height:1.4}
.scan-result-card strong{font-size:20px;margin:8px 0 3px;color:#eaf6e3}
.scan-result-card span{font-size:10px;color:var(--muted)}
.scan-result-card.featured{background:#1c2d20;border-color:#55723d}
.scan-result-card.featured strong{font-size:27px;color:#d5f49e}
.scan-result-note{font-size:11px;color:var(--muted);line-height:1.5;margin:10px 0 14px}
#view-personal-plan{margin-top:12px}
.coach-layout{grid-template-columns:minmax(0,1fr)}
.coach-header small{font-size:11px}
.chat-messages{height:min(54vh,480px);min-height:260px}
.chat-bubble{font-size:13px;line-height:1.6;max-width:90%}
.suggested-prompts button{font-size:10px;padding:9px 12px}
.chat-input-row{padding:12px}
.chat-input-row input{font-size:14px;min-height:46px}
.send-button{width:46px;min-height:46px}
@media(max-width:760px){
  .content-wrap{padding:24px 16px calc(94px + env(safe-area-inset-bottom))}
  h1{font-size:27px;line-height:1.15}
  h2{font-size:17px}
  .muted{font-size:13px;line-height:1.55}
  .eyebrow{font-size:9px;letter-spacing:.12em}
  .panel{padding:17px;border-radius:15px}
  .notice{padding:12px;margin-bottom:14px}
  .notice p{font-size:12px;line-height:1.5}
  .metrics-grid{grid-template-columns:repeat(2,minmax(0,1fr));gap:9px}
  .metric-card{min-height:94px;padding:12px}
  .metric-top{font-size:9px}
  .metric-value{font-size:23px;margin:10px 0 4px}
  .metric-foot{font-size:10px}
  .scan-grid{display:grid;grid-template-columns:1fr;gap:12px}
  .scan-instructions{padding:14px}
  .capture-panel{padding:14px}
  .primary-captures{grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}
  .capture-preview{height:170px;border-radius:13px}
  .capture-slot>strong{font-size:12px;margin-top:9px}
  .capture-slot>small{font-size:10px;line-height:1.4}
  .file-button{font-size:10px;padding:10px 6px;min-height:42px}
  .optional-captures{grid-template-columns:repeat(2,minmax(0,1fr))}
  .scan-result-grid{grid-template-columns:repeat(2,minmax(0,1fr));gap:8px}
  .scan-result-card{padding:12px}
  .scan-result-card strong{font-size:18px}
  .scan-result-card.featured strong{font-size:24px}
  .mobile-nav{grid-template-columns:repeat(6,minmax(0,1fr));padding:8px 5px calc(8px + env(safe-area-inset-bottom))}
  .mobile-nav-item{gap:4px;padding:5px 2px}
  .mobile-nav-item span{font-size:19px}
  .mobile-nav-item small{font-size:9px}
  .quick-links{display:grid;grid-template-columns:repeat(2,minmax(0,1fr))}
  .quick-links .button{font-size:10px;padding:10px 7px}
  .app-disclaimer{font-size:10px;margin:18px 8px 4px}
  .chat-messages{height:46vh;min-height:260px}
}
@media(max-width:390px){
  .primary-captures{grid-template-columns:1fr}
  .capture-preview{height:190px}
  .scan-result-grid{grid-template-columns:repeat(2,minmax(0,1fr))}
  .mobile-nav-item small{font-size:8px}
}
'''
css.write_text(css_text, encoding='utf-8')


# Tighten the remaining profile, plan and nutrition explanations; never surface implementation names.
js = js.replace("    ? (age < 2 ? 'Modo lactante: registra longitud y peso solo como datos de seguimiento con tutor. Esta versión no interpreta percentiles ni calcula composición corporal.' : age < 5 ? 'Modo infantil: registra datos bajo supervisión del tutor. No aplicamos IMC adulto, porcentajes de grasa/músculo ni objetivos dietéticos.' : age < 8 ? 'Modo crecimiento: entre 5 y 7 años no hay una ecuación de grasa incorporada. Se evita extrapolar fórmulas no validadas para esta edad.' : 'Modo crecimiento: para 8–14 y 15–17 existe una ecuación RFM pediátrica/adolescente publicada, pero solo se habilita con cintura medida con cinta y referencia sexual del estudio. Es una estimación exploratoria, no un diagnóstico.')\n    : 'Las ecuaciones adultas disponibles cubren grasa corporal entre 18–80 años; gasto Mifflin entre 19–78; músculo apendicular usa una ecuación estudiada desde los 40 años.';", "    ? (age < 2 ? 'Registra longitud y peso como seguimiento, siempre con supervisión de un tutor.' : age < 18 ? 'En esta etapa priorizamos crecimiento, hábitos saludables y acompañamiento profesional.' : 'Completa los datos para obtener estimaciones orientativas adecuadas a tu edad.')\n    : 'Completa tus datos para obtener una referencia inicial. Las estimaciones pueden variar entre personas.';")
js = js.replace("$('#equation-field').firstChild.textContent = minor ? 'Sexo de referencia (RFM pediátrica)' : 'Sexo de referencia para ecuaciones';", "$('#equation-field').firstChild.textContent = 'Sexo de referencia';")
js = js.replace("const methodsText = fatDetails?.methods.map(item => item.name).join(' + ') || '';\n  const spreadText = fatDetails?.count > 1 ? `Variación entre ecuaciones: ${fmt(fatDetails.low,1)}–${fmt(fatDetails.high,1)}% (no es intervalo de confianza).` : 'Solo hay una ecuación disponible; la incertidumbre individual puede ser amplia.';", "const methodsText = '';\n  const spreadText = 'Estimación orientativa; puede variar entre personas.';")
js = js.replace("${methodsText}. ${spreadText} Las ecuaciones poblacionales pueden variar según la población; no equivalen a DXA.", "${spreadText}")
js = js.replace("'Fuera del rango Mifflin o restringido por seguridad'", "'No disponible para este perfil'")
js = js.replace("'No calculamos calorías fuera del rango de edad de Mifflin disponible.'", "'No hay una estimación automática adecuada para este perfil.'")
js = js.replace("${fatDetails?'Estimación orientativa a partir de tus datos.':'Selecciona una referencia sexual compatible para estimarla con IMC/edad.'}", "${fatDetails?'Estimación orientativa a partir de tus datos.':'Completa tus datos para obtener una estimación.'}")
js = js.replace("'Ecuación antropométrica estudiada frente a DXA en adultos de 40 años o más.'", "'Estimación complementaria basada en medidas corporales introducidas por ti.'")
js = js.replace("'La ecuación DXA seleccionada se estudió en adultos de 40–87 años; no extrapolamos fuera de ese rango.'", "'No hay una estimación adecuada para este perfil.'")
js = js.replace("'Revisa edad, peso y altura para obtener una estimación basada en IMC.'", "'Revisa tus datos para obtener una estimación.'")
js = js.replace("'El IMC puede aportar una estimación poblacional básica, con mayor incertidumbre.'", "'Completa las medidas que tengas disponibles para mejorar el seguimiento.'")
js = js.replace("'La propuesta tiene en cuenta tu objetivo y tus preferencias (${escapeHTML(p.diet||'sin restricciones indicadas')}). Ajusta las porciones según hambre, actividad y evolución.'", "'La propuesta tiene en cuenta tu objetivo y tus preferencias (${escapeHTML(p.diet||'sin restricciones indicadas')}). Ajusta las porciones según hambre, actividad y evolución.'")
js = js.replace("'No se extrapola a edades fuera del estudio ni se confunde masa magra con músculo.'", "'No se muestra una cifra cuando los datos no permiten una estimación adecuada.'")
js = js.replace("'Las ecuaciones poblacionales pueden variar según la población; no equivalen a DXA.'", "'Es una estimación orientativa y puede variar entre personas.'")
js = js.replace("'Comparación guardada localmente. Esta prueba individual no valida la precisión general del modelo.'", "'Comparación guardada.'")
js = js.replace("renderDashboard(); renderHistory(); renderPlan(); renderDiet(); renderDiary(); renderScanResult(); renderScanValidation();", "renderDashboard(); renderHistory(); renderPlan(); renderDiet(); renderDiary(); renderScanResult(); updateScanButton();")
js = js.replace("renderScanResult(); renderScanValidation();", "renderScanResult();")
js = js.replace("renderScanValidation(); toast('Tus datos locales se han eliminado.');", "toast('Tus datos se han eliminado.');")
# A Coach profile for minors must never return adult calorie, macro or weight-loss targets.
js = js.replace("  const goalName = ({ fatloss: 'mejorar composición corporal', muscle: 'ganar fuerza y músculo', recomp: 'mejorar composición y hábitos', maintain: 'mantener tu condición' })[p?.goal] || 'mejorar tu bienestar';\n  const intro = p ? `Con tu perfil de ${p.age} años, ${p.height} cm y ${p.weight} kg, tu objetivo actual es ${goalName}. ` : 'Aún no tengo tus datos de perfil. ';", "  const goalName = ({ fatloss: 'mejorar composición corporal', muscle: 'ganar fuerza y músculo', recomp: 'mejorar composición y hábitos', maintain: 'mantener tu condición' })[p?.goal] || 'mejorar tu bienestar';\n  const intro = p ? `Con tu perfil de ${p.age} años, ${p.height} cm y ${p.weight} kg, tu objetivo actual es ${goalName}. ` : 'Aún no tengo tus datos de perfil. ';\n  if (p && p.age < 18 && /caloria|proteina|perder peso|bajar de peso|macro|grasa corporal/.test(q)) return 'Este perfil está en etapa de crecimiento. No damos objetivos de calorías ni de pérdida de peso. Prioriza comidas variadas, movimiento que disfrutes y el acompañamiento de un adulto y profesionales de salud.';")
app.write_text(js, encoding='utf-8')

# Remove leftover calls from the previous scanner panel if any.
js = app.read_text(encoding='utf-8').replace(' renderScanValidation();', '').replace('renderScanValidation();', '')
app.write_text(js, encoding='utf-8')

# Clean the profile form's implementation-heavy explanations.
html = index.read_text(encoding='utf-8')
html = html.replace('Se utiliza únicamente para seleccionar ecuaciones metabólicas y antropométricas. Puedes omitirlo usando el rango.', 'Ayuda a ajustar algunas estimaciones. Puedes elegir no indicarlo.')
html = html.replace('Las ecuaciones de composición corporal incluidas son para adultos y no se aplican a niños o adolescentes. Para menores, el seguimiento debe utilizar curvas de crecimiento por edad y sexo interpretadas por personal sanitario.', 'El perfil nos ayuda a adaptar las recomendaciones a tu etapa y tus objetivos.')
html = re.sub(r'<div class="inline-note">La estimación inicial CUN-BAE.*?</div>', '<div class="inline-note">Añade solo las medidas que conozcas. Son opcionales y sirven para completar tu seguimiento.</div>', html, count=1, flags=re.S)
html = re.sub(r'<div class="inline-note">La ecuación RFMp.*?</div>', '<div class="inline-note">En perfiles menores, la información se utiliza únicamente para seguimiento con acompañamiento de un tutor.</div>', html, count=1, flags=re.S)
# Collapse optional manual measurements so the first screen stays short.
match = re.search(r'<article class="panel form-panel" id="circumference-panel">(.*?)</article>', html, flags=re.S)
if match:
    inner = match.group(1)
    inner = inner.replace('<div class="section-heading"><span class="step-chip">02</span>', '<summary class="section-heading"><span class="step-chip">02</span>', 1)
    inner = inner.replace('</p></div></div>', '</p></div></summary>', 1)
    html = html[:match.start()] + '<details class="panel form-panel" id="circumference-panel">' + inner + '</details>' + html[match.end():]
index.write_text(html, encoding='utf-8')

# Update the build/version label and cache references for the refreshed app.
package = ROOT / 'package.json'
pkg = package.read_text(encoding='utf-8').replace('"version": "1.1.0"', '"version": "1.2.0"')
package.write_text(pkg, encoding='utf-8')


# Final visible-copy cleanup and actual PNG/WebP launcher icon references.
js = app.read_text(encoding='utf-8')
js = js.replace('Estimación exploratoria basada en la cintura extraída de las fotos. No equivale a DXA.', 'Este resultado se utiliza como referencia inicial junto con tus datos y objetivo.')
js = js.replace('Modelos: ${fatDetails.methods.map(item=>item.name).join(\' + \')}. Orientativo; no equivale a DXA.', 'Estimación orientativa a partir de tus datos.')
js = js.replace('No se extrapola a edades fuera del estudio ni se confunde masa magra con músculo.', 'No se muestra una cifra cuando los datos no permiten una estimación adecuada.')
js = js.replace('Medidas registradas; las ecuaciones solo utilizan los perímetros que requieren.', 'Medidas añadidas para completar tu seguimiento.')
js = js.replace('No añadiste perímetros opcionales. El IMC puede aportar una estimación poblacional básica, con mayor incertidumbre.', 'Puedes añadir medidas más adelante para completar tu seguimiento.')
js = js.replace('No equivale a músculo esquelético. FFMI derivado: ${fmt(composition.ffmi,1)}.', 'No representa una medida directa del músculo.')
js = js.replace('Índice ASM/altura²: ${fmt(muscleEstimate.indexKgM2,2)} kg/m² · error estándar del estudio: 1,2 kg; la validez puede variar por población.', 'Cifra orientativa basada en medidas corporales.')
js = js.replace('Modelos: ${fatDetails.methods.map(item=>item.name).join(\' + \')}. Orientativo; no equivale a DXA.', 'Estimación orientativa a partir de tus datos.')
js = js.replace('Los datos se eliminan únicamente de este dispositivo.', '')
js = js.replace('Tus datos locales se han eliminado.', 'Tus datos se han eliminado.')
app.write_text(js, encoding='utf-8')

manifest = ROOT / 'manifest.webmanifest'
mt = manifest.read_text(encoding='utf-8')
mt = mt.replace('"name": "FORMA — progreso con criterio"', '"name": "FORMA — bienestar y progreso"')
mt = mt.replace('{ "src": "./public/icon.svg", "sizes": "any", "type": "image/svg+xml", "purpose": "any maskable" }', '{ "src": "./public/icon.webp", "sizes": "512x512", "type": "image/webp", "purpose": "any maskable" }')
manifest.write_text(mt, encoding='utf-8')

index = ROOT / 'index.html'
html = index.read_text(encoding='utf-8').replace('Sexo de referencia para ecuaciones', 'Sexo de referencia')
index.write_text(html, encoding='utf-8')

# Keep the native asset mirror in sync; build workflow will also copy these freshly.
mirror = ROOT / 'android/app/src/main/assets/public'
mirror.mkdir(parents=True, exist_ok=True)
for rel in ['index.html','manifest.webmanifest','service-worker.js','src','public']:
    src = ROOT / rel
    dst = mirror / rel
    if src.is_dir():
        if dst.exists(): shutil.rmtree(dst)
        shutil.copytree(src, dst)
    else:
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)
print('Rediseño FORMA aplicado.')
